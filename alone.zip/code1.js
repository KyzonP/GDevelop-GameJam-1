gdjs.Level_321Code = {};
gdjs.Level_321Code.forEachIndex2 = 0;

gdjs.Level_321Code.forEachIndex3 = 0;

gdjs.Level_321Code.forEachIndex4 = 0;

gdjs.Level_321Code.forEachObjects2 = [];

gdjs.Level_321Code.forEachObjects3 = [];

gdjs.Level_321Code.forEachObjects4 = [];

gdjs.Level_321Code.forEachTemporary2 = null;

gdjs.Level_321Code.forEachTemporary3 = null;

gdjs.Level_321Code.forEachTemporary4 = null;

gdjs.Level_321Code.forEachTotalCount2 = 0;

gdjs.Level_321Code.forEachTotalCount3 = 0;

gdjs.Level_321Code.forEachTotalCount4 = 0;

gdjs.Level_321Code.repeatCount5 = 0;

gdjs.Level_321Code.repeatIndex5 = 0;

gdjs.Level_321Code.GDPlayerHeadObjects1= [];
gdjs.Level_321Code.GDPlayerHeadObjects2= [];
gdjs.Level_321Code.GDPlayerHeadObjects3= [];
gdjs.Level_321Code.GDPlayerHeadObjects4= [];
gdjs.Level_321Code.GDPlayerHeadObjects5= [];
gdjs.Level_321Code.GDPlayerHeadObjects6= [];
gdjs.Level_321Code.GDPlayerObjects1= [];
gdjs.Level_321Code.GDPlayerObjects2= [];
gdjs.Level_321Code.GDPlayerObjects3= [];
gdjs.Level_321Code.GDPlayerObjects4= [];
gdjs.Level_321Code.GDPlayerObjects5= [];
gdjs.Level_321Code.GDPlayerObjects6= [];
gdjs.Level_321Code.GDZambamboObjects1= [];
gdjs.Level_321Code.GDZambamboObjects2= [];
gdjs.Level_321Code.GDZambamboObjects3= [];
gdjs.Level_321Code.GDZambamboObjects4= [];
gdjs.Level_321Code.GDZambamboObjects5= [];
gdjs.Level_321Code.GDZambamboObjects6= [];
gdjs.Level_321Code.GDBulletObjects1= [];
gdjs.Level_321Code.GDBulletObjects2= [];
gdjs.Level_321Code.GDBulletObjects3= [];
gdjs.Level_321Code.GDBulletObjects4= [];
gdjs.Level_321Code.GDBulletObjects5= [];
gdjs.Level_321Code.GDBulletObjects6= [];
gdjs.Level_321Code.GDFakewallObjects1= [];
gdjs.Level_321Code.GDFakewallObjects2= [];
gdjs.Level_321Code.GDFakewallObjects3= [];
gdjs.Level_321Code.GDFakewallObjects4= [];
gdjs.Level_321Code.GDFakewallObjects5= [];
gdjs.Level_321Code.GDFakewallObjects6= [];
gdjs.Level_321Code.GDWallObjects1= [];
gdjs.Level_321Code.GDWallObjects2= [];
gdjs.Level_321Code.GDWallObjects3= [];
gdjs.Level_321Code.GDWallObjects4= [];
gdjs.Level_321Code.GDWallObjects5= [];
gdjs.Level_321Code.GDWallObjects6= [];
gdjs.Level_321Code.GDBarricadeShortGhostObjects1= [];
gdjs.Level_321Code.GDBarricadeShortGhostObjects2= [];
gdjs.Level_321Code.GDBarricadeShortGhostObjects3= [];
gdjs.Level_321Code.GDBarricadeShortGhostObjects4= [];
gdjs.Level_321Code.GDBarricadeShortGhostObjects5= [];
gdjs.Level_321Code.GDBarricadeShortGhostObjects6= [];
gdjs.Level_321Code.GDBarricadeShortObjects1= [];
gdjs.Level_321Code.GDBarricadeShortObjects2= [];
gdjs.Level_321Code.GDBarricadeShortObjects3= [];
gdjs.Level_321Code.GDBarricadeShortObjects4= [];
gdjs.Level_321Code.GDBarricadeShortObjects5= [];
gdjs.Level_321Code.GDBarricadeShortObjects6= [];
gdjs.Level_321Code.GDBarricadeSpikesGhostObjects1= [];
gdjs.Level_321Code.GDBarricadeSpikesGhostObjects2= [];
gdjs.Level_321Code.GDBarricadeSpikesGhostObjects3= [];
gdjs.Level_321Code.GDBarricadeSpikesGhostObjects4= [];
gdjs.Level_321Code.GDBarricadeSpikesGhostObjects5= [];
gdjs.Level_321Code.GDBarricadeSpikesGhostObjects6= [];
gdjs.Level_321Code.GDBarricadeSpikesObjects1= [];
gdjs.Level_321Code.GDBarricadeSpikesObjects2= [];
gdjs.Level_321Code.GDBarricadeSpikesObjects3= [];
gdjs.Level_321Code.GDBarricadeSpikesObjects4= [];
gdjs.Level_321Code.GDBarricadeSpikesObjects5= [];
gdjs.Level_321Code.GDBarricadeSpikesObjects6= [];
gdjs.Level_321Code.GDBarricadeGhostObjects1= [];
gdjs.Level_321Code.GDBarricadeGhostObjects2= [];
gdjs.Level_321Code.GDBarricadeGhostObjects3= [];
gdjs.Level_321Code.GDBarricadeGhostObjects4= [];
gdjs.Level_321Code.GDBarricadeGhostObjects5= [];
gdjs.Level_321Code.GDBarricadeGhostObjects6= [];
gdjs.Level_321Code.GDBarricadeObjects1= [];
gdjs.Level_321Code.GDBarricadeObjects2= [];
gdjs.Level_321Code.GDBarricadeObjects3= [];
gdjs.Level_321Code.GDBarricadeObjects4= [];
gdjs.Level_321Code.GDBarricadeObjects5= [];
gdjs.Level_321Code.GDBarricadeObjects6= [];
gdjs.Level_321Code.GDHealthObjects1= [];
gdjs.Level_321Code.GDHealthObjects2= [];
gdjs.Level_321Code.GDHealthObjects3= [];
gdjs.Level_321Code.GDHealthObjects4= [];
gdjs.Level_321Code.GDHealthObjects5= [];
gdjs.Level_321Code.GDHealthObjects6= [];
gdjs.Level_321Code.GDHealthTokenObjects1= [];
gdjs.Level_321Code.GDHealthTokenObjects2= [];
gdjs.Level_321Code.GDHealthTokenObjects3= [];
gdjs.Level_321Code.GDHealthTokenObjects4= [];
gdjs.Level_321Code.GDHealthTokenObjects5= [];
gdjs.Level_321Code.GDHealthTokenObjects6= [];
gdjs.Level_321Code.GDBuildObjects1= [];
gdjs.Level_321Code.GDBuildObjects2= [];
gdjs.Level_321Code.GDBuildObjects3= [];
gdjs.Level_321Code.GDBuildObjects4= [];
gdjs.Level_321Code.GDBuildObjects5= [];
gdjs.Level_321Code.GDBuildObjects6= [];
gdjs.Level_321Code.GDBuildTokenObjects1= [];
gdjs.Level_321Code.GDBuildTokenObjects2= [];
gdjs.Level_321Code.GDBuildTokenObjects3= [];
gdjs.Level_321Code.GDBuildTokenObjects4= [];
gdjs.Level_321Code.GDBuildTokenObjects5= [];
gdjs.Level_321Code.GDBuildTokenObjects6= [];
gdjs.Level_321Code.GDLightObjects1= [];
gdjs.Level_321Code.GDLightObjects2= [];
gdjs.Level_321Code.GDLightObjects3= [];
gdjs.Level_321Code.GDLightObjects4= [];
gdjs.Level_321Code.GDLightObjects5= [];
gdjs.Level_321Code.GDLightObjects6= [];
gdjs.Level_321Code.GDSpawnPointObjects1= [];
gdjs.Level_321Code.GDSpawnPointObjects2= [];
gdjs.Level_321Code.GDSpawnPointObjects3= [];
gdjs.Level_321Code.GDSpawnPointObjects4= [];
gdjs.Level_321Code.GDSpawnPointObjects5= [];
gdjs.Level_321Code.GDSpawnPointObjects6= [];
gdjs.Level_321Code.GDEquipUIObjects1= [];
gdjs.Level_321Code.GDEquipUIObjects2= [];
gdjs.Level_321Code.GDEquipUIObjects3= [];
gdjs.Level_321Code.GDEquipUIObjects4= [];
gdjs.Level_321Code.GDEquipUIObjects5= [];
gdjs.Level_321Code.GDEquipUIObjects6= [];
gdjs.Level_321Code.GDSelectUIObjects1= [];
gdjs.Level_321Code.GDSelectUIObjects2= [];
gdjs.Level_321Code.GDSelectUIObjects3= [];
gdjs.Level_321Code.GDSelectUIObjects4= [];
gdjs.Level_321Code.GDSelectUIObjects5= [];
gdjs.Level_321Code.GDSelectUIObjects6= [];
gdjs.Level_321Code.GDTimeTextObjects1= [];
gdjs.Level_321Code.GDTimeTextObjects2= [];
gdjs.Level_321Code.GDTimeTextObjects3= [];
gdjs.Level_321Code.GDTimeTextObjects4= [];
gdjs.Level_321Code.GDTimeTextObjects5= [];
gdjs.Level_321Code.GDTimeTextObjects6= [];
gdjs.Level_321Code.GDNightTextObjects1= [];
gdjs.Level_321Code.GDNightTextObjects2= [];
gdjs.Level_321Code.GDNightTextObjects3= [];
gdjs.Level_321Code.GDNightTextObjects4= [];
gdjs.Level_321Code.GDNightTextObjects5= [];
gdjs.Level_321Code.GDNightTextObjects6= [];
gdjs.Level_321Code.GDDayTextObjects1= [];
gdjs.Level_321Code.GDDayTextObjects2= [];
gdjs.Level_321Code.GDDayTextObjects3= [];
gdjs.Level_321Code.GDDayTextObjects4= [];
gdjs.Level_321Code.GDDayTextObjects5= [];
gdjs.Level_321Code.GDDayTextObjects6= [];
gdjs.Level_321Code.GDTimeText2Objects1= [];
gdjs.Level_321Code.GDTimeText2Objects2= [];
gdjs.Level_321Code.GDTimeText2Objects3= [];
gdjs.Level_321Code.GDTimeText2Objects4= [];
gdjs.Level_321Code.GDTimeText2Objects5= [];
gdjs.Level_321Code.GDTimeText2Objects6= [];
gdjs.Level_321Code.GDAssaultObjects1= [];
gdjs.Level_321Code.GDAssaultObjects2= [];
gdjs.Level_321Code.GDAssaultObjects3= [];
gdjs.Level_321Code.GDAssaultObjects4= [];
gdjs.Level_321Code.GDAssaultObjects5= [];
gdjs.Level_321Code.GDAssaultObjects6= [];
gdjs.Level_321Code.GDRifleObjects1= [];
gdjs.Level_321Code.GDRifleObjects2= [];
gdjs.Level_321Code.GDRifleObjects3= [];
gdjs.Level_321Code.GDRifleObjects4= [];
gdjs.Level_321Code.GDRifleObjects5= [];
gdjs.Level_321Code.GDRifleObjects6= [];
gdjs.Level_321Code.GDShotgunObjects1= [];
gdjs.Level_321Code.GDShotgunObjects2= [];
gdjs.Level_321Code.GDShotgunObjects3= [];
gdjs.Level_321Code.GDShotgunObjects4= [];
gdjs.Level_321Code.GDShotgunObjects5= [];
gdjs.Level_321Code.GDShotgunObjects6= [];
gdjs.Level_321Code.GDPistolObjects1= [];
gdjs.Level_321Code.GDPistolObjects2= [];
gdjs.Level_321Code.GDPistolObjects3= [];
gdjs.Level_321Code.GDPistolObjects4= [];
gdjs.Level_321Code.GDPistolObjects5= [];
gdjs.Level_321Code.GDPistolObjects6= [];
gdjs.Level_321Code.GDAssaultAmmoObjects1= [];
gdjs.Level_321Code.GDAssaultAmmoObjects2= [];
gdjs.Level_321Code.GDAssaultAmmoObjects3= [];
gdjs.Level_321Code.GDAssaultAmmoObjects4= [];
gdjs.Level_321Code.GDAssaultAmmoObjects5= [];
gdjs.Level_321Code.GDAssaultAmmoObjects6= [];
gdjs.Level_321Code.GDRifleAmmoObjects1= [];
gdjs.Level_321Code.GDRifleAmmoObjects2= [];
gdjs.Level_321Code.GDRifleAmmoObjects3= [];
gdjs.Level_321Code.GDRifleAmmoObjects4= [];
gdjs.Level_321Code.GDRifleAmmoObjects5= [];
gdjs.Level_321Code.GDRifleAmmoObjects6= [];
gdjs.Level_321Code.GDShotgunAmmoObjects1= [];
gdjs.Level_321Code.GDShotgunAmmoObjects2= [];
gdjs.Level_321Code.GDShotgunAmmoObjects3= [];
gdjs.Level_321Code.GDShotgunAmmoObjects4= [];
gdjs.Level_321Code.GDShotgunAmmoObjects5= [];
gdjs.Level_321Code.GDShotgunAmmoObjects6= [];
gdjs.Level_321Code.GDPistolAmmoObjects1= [];
gdjs.Level_321Code.GDPistolAmmoObjects2= [];
gdjs.Level_321Code.GDPistolAmmoObjects3= [];
gdjs.Level_321Code.GDPistolAmmoObjects4= [];
gdjs.Level_321Code.GDPistolAmmoObjects5= [];
gdjs.Level_321Code.GDPistolAmmoObjects6= [];
gdjs.Level_321Code.GDMouseObjectObjects1= [];
gdjs.Level_321Code.GDMouseObjectObjects2= [];
gdjs.Level_321Code.GDMouseObjectObjects3= [];
gdjs.Level_321Code.GDMouseObjectObjects4= [];
gdjs.Level_321Code.GDMouseObjectObjects5= [];
gdjs.Level_321Code.GDMouseObjectObjects6= [];
gdjs.Level_321Code.GDZambamboHealthBackObjects1= [];
gdjs.Level_321Code.GDZambamboHealthBackObjects2= [];
gdjs.Level_321Code.GDZambamboHealthBackObjects3= [];
gdjs.Level_321Code.GDZambamboHealthBackObjects4= [];
gdjs.Level_321Code.GDZambamboHealthBackObjects5= [];
gdjs.Level_321Code.GDZambamboHealthBackObjects6= [];
gdjs.Level_321Code.GDZambamboHealthObjects1= [];
gdjs.Level_321Code.GDZambamboHealthObjects2= [];
gdjs.Level_321Code.GDZambamboHealthObjects3= [];
gdjs.Level_321Code.GDZambamboHealthObjects4= [];
gdjs.Level_321Code.GDZambamboHealthObjects5= [];
gdjs.Level_321Code.GDZambamboHealthObjects6= [];
gdjs.Level_321Code.GDtempwall1Objects1= [];
gdjs.Level_321Code.GDtempwall1Objects2= [];
gdjs.Level_321Code.GDtempwall1Objects3= [];
gdjs.Level_321Code.GDtempwall1Objects4= [];
gdjs.Level_321Code.GDtempwall1Objects5= [];
gdjs.Level_321Code.GDtempwall1Objects6= [];
gdjs.Level_321Code.GDtempwall2Objects1= [];
gdjs.Level_321Code.GDtempwall2Objects2= [];
gdjs.Level_321Code.GDtempwall2Objects3= [];
gdjs.Level_321Code.GDtempwall2Objects4= [];
gdjs.Level_321Code.GDtempwall2Objects5= [];
gdjs.Level_321Code.GDtempwall2Objects6= [];

gdjs.Level_321Code.conditionTrue_0 = {val:false};
gdjs.Level_321Code.condition0IsTrue_0 = {val:false};
gdjs.Level_321Code.condition1IsTrue_0 = {val:false};
gdjs.Level_321Code.condition2IsTrue_0 = {val:false};
gdjs.Level_321Code.condition3IsTrue_0 = {val:false};
gdjs.Level_321Code.condition4IsTrue_0 = {val:false};
gdjs.Level_321Code.condition5IsTrue_0 = {val:false};
gdjs.Level_321Code.condition6IsTrue_0 = {val:false};
gdjs.Level_321Code.condition7IsTrue_0 = {val:false};
gdjs.Level_321Code.conditionTrue_1 = {val:false};
gdjs.Level_321Code.condition0IsTrue_1 = {val:false};
gdjs.Level_321Code.condition1IsTrue_1 = {val:false};
gdjs.Level_321Code.condition2IsTrue_1 = {val:false};
gdjs.Level_321Code.condition3IsTrue_1 = {val:false};
gdjs.Level_321Code.condition4IsTrue_1 = {val:false};
gdjs.Level_321Code.condition5IsTrue_1 = {val:false};
gdjs.Level_321Code.condition6IsTrue_1 = {val:false};
gdjs.Level_321Code.condition7IsTrue_1 = {val:false};


gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDEquipUIObjects2Objects = Hashtable.newFrom({"EquipUI": gdjs.Level_321Code.GDEquipUIObjects2});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDSelectUIObjects2Objects = Hashtable.newFrom({"SelectUI": gdjs.Level_321Code.GDSelectUIObjects2});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDHealthObjects2Objects = Hashtable.newFrom({"Health": gdjs.Level_321Code.GDHealthObjects2});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBuildObjects2Objects = Hashtable.newFrom({"Build": gdjs.Level_321Code.GDBuildObjects2});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPistolAmmoObjects2Objects = Hashtable.newFrom({"PistolAmmo": gdjs.Level_321Code.GDPistolAmmoObjects2});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDShotgunAmmoObjects2Objects = Hashtable.newFrom({"ShotgunAmmo": gdjs.Level_321Code.GDShotgunAmmoObjects2});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDRifleAmmoObjects2Objects = Hashtable.newFrom({"RifleAmmo": gdjs.Level_321Code.GDRifleAmmoObjects2});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDAssaultAmmoObjects2Objects = Hashtable.newFrom({"AssaultAmmo": gdjs.Level_321Code.GDAssaultAmmoObjects2});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDMouseObjectObjects2Objects = Hashtable.newFrom({"MouseObject": gdjs.Level_321Code.GDMouseObjectObjects2});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPistolObjects2Objects = Hashtable.newFrom({"Pistol": gdjs.Level_321Code.GDPistolObjects2});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDShotgunObjects2Objects = Hashtable.newFrom({"Shotgun": gdjs.Level_321Code.GDShotgunObjects2});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDRifleObjects2Objects = Hashtable.newFrom({"Rifle": gdjs.Level_321Code.GDRifleObjects2});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDAssaultObjects2Objects = Hashtable.newFrom({"Assault": gdjs.Level_321Code.GDAssaultObjects2});gdjs.Level_321Code.eventsList0 = function(runtimeScene) {

};gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDZambamboHealthObjects3Objects = Hashtable.newFrom({"ZambamboHealth": gdjs.Level_321Code.GDZambamboHealthObjects3});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDZambamboHealthBackObjects3Objects = Hashtable.newFrom({"ZambamboHealthBack": gdjs.Level_321Code.GDZambamboHealthBackObjects3});gdjs.Level_321Code.eventsList1 = function(runtimeScene) {

};gdjs.Level_321Code.eventsList2 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Level_321Code.GDSpawnPointObjects3, gdjs.Level_321Code.GDSpawnPointObjects4);


gdjs.Level_321Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level_321Code.GDSpawnPointObjects4.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDSpawnPointObjects4[i].getY() == -(864) ) {
        gdjs.Level_321Code.condition0IsTrue_0.val = true;
        gdjs.Level_321Code.GDSpawnPointObjects4[k] = gdjs.Level_321Code.GDSpawnPointObjects4[i];
        ++k;
    }
}
gdjs.Level_321Code.GDSpawnPointObjects4.length = k;}if (gdjs.Level_321Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level_321Code.GDSpawnPointObjects4 */
{for(var i = 0, len = gdjs.Level_321Code.GDSpawnPointObjects4.length ;i < len;++i) {
    gdjs.Level_321Code.GDSpawnPointObjects4[i].returnVariable(gdjs.Level_321Code.GDSpawnPointObjects4[i].getVariables().getFromIndex(1)).setNumber(1);
}
}}

}


{

gdjs.copyArray(gdjs.Level_321Code.GDSpawnPointObjects3, gdjs.Level_321Code.GDSpawnPointObjects4);


gdjs.Level_321Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level_321Code.GDSpawnPointObjects4.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDSpawnPointObjects4[i].getX() == -(864) ) {
        gdjs.Level_321Code.condition0IsTrue_0.val = true;
        gdjs.Level_321Code.GDSpawnPointObjects4[k] = gdjs.Level_321Code.GDSpawnPointObjects4[i];
        ++k;
    }
}
gdjs.Level_321Code.GDSpawnPointObjects4.length = k;}if (gdjs.Level_321Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level_321Code.GDSpawnPointObjects4 */
{for(var i = 0, len = gdjs.Level_321Code.GDSpawnPointObjects4.length ;i < len;++i) {
    gdjs.Level_321Code.GDSpawnPointObjects4[i].returnVariable(gdjs.Level_321Code.GDSpawnPointObjects4[i].getVariables().getFromIndex(1)).setNumber(2);
}
}}

}


{

gdjs.copyArray(gdjs.Level_321Code.GDSpawnPointObjects3, gdjs.Level_321Code.GDSpawnPointObjects4);


gdjs.Level_321Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level_321Code.GDSpawnPointObjects4.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDSpawnPointObjects4[i].getY() == 4000 ) {
        gdjs.Level_321Code.condition0IsTrue_0.val = true;
        gdjs.Level_321Code.GDSpawnPointObjects4[k] = gdjs.Level_321Code.GDSpawnPointObjects4[i];
        ++k;
    }
}
gdjs.Level_321Code.GDSpawnPointObjects4.length = k;}if (gdjs.Level_321Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level_321Code.GDSpawnPointObjects4 */
{for(var i = 0, len = gdjs.Level_321Code.GDSpawnPointObjects4.length ;i < len;++i) {
    gdjs.Level_321Code.GDSpawnPointObjects4[i].returnVariable(gdjs.Level_321Code.GDSpawnPointObjects4[i].getVariables().getFromIndex(1)).setNumber(3);
}
}}

}


{

gdjs.copyArray(gdjs.Level_321Code.GDSpawnPointObjects3, gdjs.Level_321Code.GDSpawnPointObjects4);


gdjs.Level_321Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level_321Code.GDSpawnPointObjects4.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDSpawnPointObjects4[i].getX() == 4000 ) {
        gdjs.Level_321Code.condition0IsTrue_0.val = true;
        gdjs.Level_321Code.GDSpawnPointObjects4[k] = gdjs.Level_321Code.GDSpawnPointObjects4[i];
        ++k;
    }
}
gdjs.Level_321Code.GDSpawnPointObjects4.length = k;}if (gdjs.Level_321Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level_321Code.GDSpawnPointObjects4 */
{for(var i = 0, len = gdjs.Level_321Code.GDSpawnPointObjects4.length ;i < len;++i) {
    gdjs.Level_321Code.GDSpawnPointObjects4[i].returnVariable(gdjs.Level_321Code.GDSpawnPointObjects4[i].getVariables().getFromIndex(1)).setNumber(4);
}
}}

}


};gdjs.Level_321Code.eventsList3 = function(runtimeScene) {

{



}


{


{
gdjs.Level_321Code.GDBuildObjects2.length = 0;

gdjs.Level_321Code.GDEquipUIObjects2.length = 0;

gdjs.Level_321Code.GDHealthObjects2.length = 0;

gdjs.Level_321Code.GDSelectUIObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDEquipUIObjects2Objects, 640, 992, "UI");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDSelectUIObjects2Objects, 632, 992, "UI");
}{for(var i = 0, len = gdjs.Level_321Code.GDSelectUIObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDSelectUIObjects2[i].setPosition((( gdjs.Level_321Code.GDEquipUIObjects2.length === 0 ) ? 0 :gdjs.Level_321Code.GDEquipUIObjects2[0].getPointX("")) - 4,(( gdjs.Level_321Code.GDEquipUIObjects2.length === 0 ) ? 0 :gdjs.Level_321Code.GDEquipUIObjects2[0].getPointY("")) - 4);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDHealthObjects2Objects, 0, 0, "UI");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBuildObjects2Objects, 0, 64, "UI");
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("EquipUI"), gdjs.Level_321Code.GDEquipUIObjects2);
gdjs.Level_321Code.GDAssaultAmmoObjects2.length = 0;

gdjs.Level_321Code.GDPistolAmmoObjects2.length = 0;

gdjs.Level_321Code.GDRifleAmmoObjects2.length = 0;

gdjs.Level_321Code.GDShotgunAmmoObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPistolAmmoObjects2Objects, (( gdjs.Level_321Code.GDEquipUIObjects2.length === 0 ) ? 0 :gdjs.Level_321Code.GDEquipUIObjects2[0].getPointX("")), (( gdjs.Level_321Code.GDEquipUIObjects2.length === 0 ) ? 0 :gdjs.Level_321Code.GDEquipUIObjects2[0].getPointY("")) - 25, "UI");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDShotgunAmmoObjects2Objects, (( gdjs.Level_321Code.GDEquipUIObjects2.length === 0 ) ? 0 :gdjs.Level_321Code.GDEquipUIObjects2[0].getPointX("")) + 64, (( gdjs.Level_321Code.GDEquipUIObjects2.length === 0 ) ? 0 :gdjs.Level_321Code.GDEquipUIObjects2[0].getPointY("")) - 25, "UI");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDRifleAmmoObjects2Objects, (( gdjs.Level_321Code.GDEquipUIObjects2.length === 0 ) ? 0 :gdjs.Level_321Code.GDEquipUIObjects2[0].getPointX("")) + 128, (( gdjs.Level_321Code.GDEquipUIObjects2.length === 0 ) ? 0 :gdjs.Level_321Code.GDEquipUIObjects2[0].getPointY("")) - 25, "UI");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDAssaultAmmoObjects2Objects, (( gdjs.Level_321Code.GDEquipUIObjects2.length === 0 ) ? 0 :gdjs.Level_321Code.GDEquipUIObjects2[0].getPointX("")) + 192, (( gdjs.Level_321Code.GDEquipUIObjects2.length === 0 ) ? 0 :gdjs.Level_321Code.GDEquipUIObjects2[0].getPointY("")) - 25, "UI");
}}

}


{



}


{


{
gdjs.Level_321Code.GDMouseObjectObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDMouseObjectObjects2Objects, gdjs.evtTools.input.getMouseX(runtimeScene, "", 0), gdjs.evtTools.input.getMouseY(runtimeScene, "", 0), "");
}}

}


{



}


{


{
gdjs.Level_321Code.GDAssaultObjects2.length = 0;

gdjs.Level_321Code.GDPistolObjects2.length = 0;

gdjs.Level_321Code.GDRifleObjects2.length = 0;

gdjs.Level_321Code.GDShotgunObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPistolObjects2Objects, 0, 0, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDShotgunObjects2Objects, 0, 0, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDRifleObjects2Objects, 0, 0, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDAssaultObjects2Objects, 0, 0, "");
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Wall"), gdjs.Level_321Code.GDWallObjects2);

for(gdjs.Level_321Code.forEachIndex3 = 0;gdjs.Level_321Code.forEachIndex3 < gdjs.Level_321Code.GDWallObjects2.length;++gdjs.Level_321Code.forEachIndex3) {
gdjs.Level_321Code.GDWallObjects3.length = 0;


gdjs.Level_321Code.forEachTemporary3 = gdjs.Level_321Code.GDWallObjects2[gdjs.Level_321Code.forEachIndex3];
gdjs.Level_321Code.GDWallObjects3.push(gdjs.Level_321Code.forEachTemporary3);
if (true) {
{for(var i = 0, len = gdjs.Level_321Code.GDWallObjects3.length ;i < len;++i) {
    gdjs.Level_321Code.GDWallObjects3[i].setZOrder((gdjs.Level_321Code.GDWallObjects3[i].getY()));
}
}}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Zambambo"), gdjs.Level_321Code.GDZambamboObjects2);

for(gdjs.Level_321Code.forEachIndex3 = 0;gdjs.Level_321Code.forEachIndex3 < gdjs.Level_321Code.GDZambamboObjects2.length;++gdjs.Level_321Code.forEachIndex3) {
gdjs.Level_321Code.GDZambamboHealthObjects3.length = 0;

gdjs.Level_321Code.GDZambamboHealthBackObjects3.length = 0;

gdjs.Level_321Code.GDZambamboObjects3.length = 0;


gdjs.Level_321Code.forEachTemporary3 = gdjs.Level_321Code.GDZambamboObjects2[gdjs.Level_321Code.forEachIndex3];
gdjs.Level_321Code.GDZambamboObjects3.push(gdjs.Level_321Code.forEachTemporary3);
if (true) {
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDZambamboHealthObjects3Objects, (( gdjs.Level_321Code.GDZambamboObjects3.length === 0 ) ? 0 :gdjs.Level_321Code.GDZambamboObjects3[0].getPointX("")), (( gdjs.Level_321Code.GDZambamboObjects3.length === 0 ) ? 0 :gdjs.Level_321Code.GDZambamboObjects3[0].getPointY("")) + 64, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDZambamboHealthBackObjects3Objects, (( gdjs.Level_321Code.GDZambamboObjects3.length === 0 ) ? 0 :gdjs.Level_321Code.GDZambamboObjects3[0].getPointX("")), (( gdjs.Level_321Code.GDZambamboObjects3.length === 0 ) ? 0 :gdjs.Level_321Code.GDZambamboObjects3[0].getPointY("")) + 64, "");
}{gdjs.evtTools.linkedObjects.linkObjects(runtimeScene, (gdjs.Level_321Code.GDZambamboObjects3.length !== 0 ? gdjs.Level_321Code.GDZambamboObjects3[0] : null), (gdjs.Level_321Code.GDZambamboHealthObjects3.length !== 0 ? gdjs.Level_321Code.GDZambamboHealthObjects3[0] : null));
}{gdjs.evtTools.linkedObjects.linkObjects(runtimeScene, (gdjs.Level_321Code.GDZambamboObjects3.length !== 0 ? gdjs.Level_321Code.GDZambamboObjects3[0] : null), (gdjs.Level_321Code.GDZambamboHealthBackObjects3.length !== 0 ? gdjs.Level_321Code.GDZambamboHealthBackObjects3[0] : null));
}}
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("SpawnPoint"), gdjs.Level_321Code.GDSpawnPointObjects2);

for(gdjs.Level_321Code.forEachIndex3 = 0;gdjs.Level_321Code.forEachIndex3 < gdjs.Level_321Code.GDSpawnPointObjects2.length;++gdjs.Level_321Code.forEachIndex3) {
gdjs.Level_321Code.GDSpawnPointObjects3.length = 0;


gdjs.Level_321Code.forEachTemporary3 = gdjs.Level_321Code.GDSpawnPointObjects2[gdjs.Level_321Code.forEachIndex3];
gdjs.Level_321Code.GDSpawnPointObjects3.push(gdjs.Level_321Code.forEachTemporary3);
if (true) {
{for(var i = 0, len = gdjs.Level_321Code.GDSpawnPointObjects3.length ;i < len;++i) {
    gdjs.Level_321Code.GDSpawnPointObjects3[i].resetTimer("SpawnTimer");
}
}{for(var i = 0, len = gdjs.Level_321Code.GDSpawnPointObjects3.length ;i < len;++i) {
    gdjs.Level_321Code.GDSpawnPointObjects3[i].pauseTimer("SpawnTimer");
}
}
{ //Subevents: 
gdjs.Level_321Code.eventsList2(runtimeScene);} //Subevents end.
}
}

}


{



}


{


{
gdjs.copyArray(runtimeScene.getObjects("DayText"), gdjs.Level_321Code.GDDayTextObjects1);
gdjs.copyArray(runtimeScene.getObjects("NightText"), gdjs.Level_321Code.GDNightTextObjects1);
{for(var i = 0, len = gdjs.Level_321Code.GDDayTextObjects1.length ;i < len;++i) {
    gdjs.Level_321Code.GDDayTextObjects1[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDNightTextObjects1.length ;i < len;++i) {
    gdjs.Level_321Code.GDNightTextObjects1[i].setOpacity(0);
}
}}

}


};gdjs.Level_321Code.eventsList4 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects1);
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.Level_321Code.GDPlayerObjects1.length !== 0 ? gdjs.Level_321Code.GDPlayerObjects1[0] : null), false, "", 0);
}}

}


};gdjs.Level_321Code.eventsList5 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("BarricadeGhost"), gdjs.Level_321Code.GDBarricadeGhostObjects2);
gdjs.copyArray(runtimeScene.getObjects("BarricadeShortGhost"), gdjs.Level_321Code.GDBarricadeShortGhostObjects2);
gdjs.copyArray(runtimeScene.getObjects("BarricadeSpikesGhost"), gdjs.Level_321Code.GDBarricadeSpikesGhostObjects2);
{for(var i = 0, len = gdjs.Level_321Code.GDBarricadeGhostObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDBarricadeGhostObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Level_321Code.GDBarricadeShortGhostObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDBarricadeShortGhostObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Level_321Code.GDBarricadeSpikesGhostObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDBarricadeSpikesGhostObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.Level_321Code.eventsList6 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("BarricadeGhost"), gdjs.Level_321Code.GDBarricadeGhostObjects2);
gdjs.copyArray(runtimeScene.getObjects("BarricadeShortGhost"), gdjs.Level_321Code.GDBarricadeShortGhostObjects2);
gdjs.copyArray(runtimeScene.getObjects("BarricadeSpikesGhost"), gdjs.Level_321Code.GDBarricadeSpikesGhostObjects2);
{for(var i = 0, len = gdjs.Level_321Code.GDBarricadeGhostObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDBarricadeGhostObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Level_321Code.GDBarricadeShortGhostObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDBarricadeShortGhostObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Level_321Code.GDBarricadeSpikesGhostObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDBarricadeSpikesGhostObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.Level_321Code.eventsList7 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("BarricadeGhost"), gdjs.Level_321Code.GDBarricadeGhostObjects2);
gdjs.copyArray(runtimeScene.getObjects("BarricadeShortGhost"), gdjs.Level_321Code.GDBarricadeShortGhostObjects2);
gdjs.copyArray(runtimeScene.getObjects("BarricadeSpikesGhost"), gdjs.Level_321Code.GDBarricadeSpikesGhostObjects2);
{for(var i = 0, len = gdjs.Level_321Code.GDBarricadeGhostObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDBarricadeGhostObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Level_321Code.GDBarricadeShortGhostObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDBarricadeShortGhostObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Level_321Code.GDBarricadeSpikesGhostObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDBarricadeSpikesGhostObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.Level_321Code.eventsList8 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("BarricadeGhost"), gdjs.Level_321Code.GDBarricadeGhostObjects2);
gdjs.copyArray(runtimeScene.getObjects("BarricadeShortGhost"), gdjs.Level_321Code.GDBarricadeShortGhostObjects2);
gdjs.copyArray(runtimeScene.getObjects("BarricadeSpikesGhost"), gdjs.Level_321Code.GDBarricadeSpikesGhostObjects2);
{for(var i = 0, len = gdjs.Level_321Code.GDBarricadeGhostObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDBarricadeGhostObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Level_321Code.GDBarricadeShortGhostObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDBarricadeShortGhostObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Level_321Code.GDBarricadeSpikesGhostObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDBarricadeSpikesGhostObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.Level_321Code.eventsList9 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("BarricadeGhost"), gdjs.Level_321Code.GDBarricadeGhostObjects2);
gdjs.copyArray(runtimeScene.getObjects("BarricadeShortGhost"), gdjs.Level_321Code.GDBarricadeShortGhostObjects2);
gdjs.copyArray(runtimeScene.getObjects("BarricadeSpikesGhost"), gdjs.Level_321Code.GDBarricadeSpikesGhostObjects2);
{for(var i = 0, len = gdjs.Level_321Code.GDBarricadeGhostObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDBarricadeGhostObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Level_321Code.GDBarricadeShortGhostObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDBarricadeShortGhostObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Level_321Code.GDBarricadeSpikesGhostObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDBarricadeSpikesGhostObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBarricadeGhostObjects2Objects = Hashtable.newFrom({"BarricadeGhost": gdjs.Level_321Code.GDBarricadeGhostObjects2});gdjs.Level_321Code.eventsList10 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("BarricadeGhost"), gdjs.Level_321Code.GDBarricadeGhostObjects2);
gdjs.copyArray(runtimeScene.getObjects("BarricadeShortGhost"), gdjs.Level_321Code.GDBarricadeShortGhostObjects2);
gdjs.copyArray(runtimeScene.getObjects("BarricadeSpikesGhost"), gdjs.Level_321Code.GDBarricadeSpikesGhostObjects2);
{for(var i = 0, len = gdjs.Level_321Code.GDBarricadeGhostObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDBarricadeGhostObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Level_321Code.GDBarricadeShortGhostObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDBarricadeShortGhostObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Level_321Code.GDBarricadeSpikesGhostObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDBarricadeSpikesGhostObjects2[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBarricadeGhostObjects2Objects, gdjs.evtTools.input.getMouseX(runtimeScene, "", 0), gdjs.evtTools.input.getMouseY(runtimeScene, "", 0), "");
}{for(var i = 0, len = gdjs.Level_321Code.GDBarricadeGhostObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDBarricadeGhostObjects2[i].setOpacity(100);
}
}}

}


};gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBarricadeShortGhostObjects2Objects = Hashtable.newFrom({"BarricadeShortGhost": gdjs.Level_321Code.GDBarricadeShortGhostObjects2});gdjs.Level_321Code.eventsList11 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("BarricadeGhost"), gdjs.Level_321Code.GDBarricadeGhostObjects2);
gdjs.copyArray(runtimeScene.getObjects("BarricadeShortGhost"), gdjs.Level_321Code.GDBarricadeShortGhostObjects2);
gdjs.copyArray(runtimeScene.getObjects("BarricadeSpikesGhost"), gdjs.Level_321Code.GDBarricadeSpikesGhostObjects2);
{for(var i = 0, len = gdjs.Level_321Code.GDBarricadeGhostObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDBarricadeGhostObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Level_321Code.GDBarricadeShortGhostObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDBarricadeShortGhostObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Level_321Code.GDBarricadeSpikesGhostObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDBarricadeSpikesGhostObjects2[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBarricadeShortGhostObjects2Objects, gdjs.evtTools.input.getMouseX(runtimeScene, "", 0), gdjs.evtTools.input.getMouseY(runtimeScene, "", 0), "");
}{for(var i = 0, len = gdjs.Level_321Code.GDBarricadeShortGhostObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDBarricadeShortGhostObjects2[i].setOpacity(100);
}
}}

}


};gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBarricadeSpikesGhostObjects2Objects = Hashtable.newFrom({"BarricadeSpikesGhost": gdjs.Level_321Code.GDBarricadeSpikesGhostObjects2});gdjs.Level_321Code.eventsList12 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("BarricadeGhost"), gdjs.Level_321Code.GDBarricadeGhostObjects2);
gdjs.copyArray(runtimeScene.getObjects("BarricadeShortGhost"), gdjs.Level_321Code.GDBarricadeShortGhostObjects2);
gdjs.copyArray(runtimeScene.getObjects("BarricadeSpikesGhost"), gdjs.Level_321Code.GDBarricadeSpikesGhostObjects2);
{for(var i = 0, len = gdjs.Level_321Code.GDBarricadeGhostObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDBarricadeGhostObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Level_321Code.GDBarricadeShortGhostObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDBarricadeShortGhostObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Level_321Code.GDBarricadeSpikesGhostObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDBarricadeSpikesGhostObjects2[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBarricadeSpikesGhostObjects2Objects, gdjs.evtTools.input.getMouseX(runtimeScene, "", 0), gdjs.evtTools.input.getMouseY(runtimeScene, "", 0), "");
}{for(var i = 0, len = gdjs.Level_321Code.GDBarricadeSpikesGhostObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDBarricadeSpikesGhostObjects2[i].setOpacity(100);
}
}}

}


};gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level_321Code.GDPlayerObjects2});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDMouseObjectObjects2Objects = Hashtable.newFrom({"MouseObject": gdjs.Level_321Code.GDMouseObjectObjects2});gdjs.Level_321Code.eventsList13 = function(runtimeScene) {

{



}


{


gdjs.Level_321Code.condition0IsTrue_0.val = false;
{
gdjs.Level_321Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Num1");
}if (gdjs.Level_321Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("EquipUI"), gdjs.Level_321Code.GDEquipUIObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("SelectUI"), gdjs.Level_321Code.GDSelectUIObjects2);
{for(var i = 0, len = gdjs.Level_321Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayerObjects2[i].returnVariable(gdjs.Level_321Code.GDPlayerObjects2[i].getVariables().getFromIndex(2)).setString("Pistol");
}
}{for(var i = 0, len = gdjs.Level_321Code.GDSelectUIObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDSelectUIObjects2[i].setPosition((( gdjs.Level_321Code.GDEquipUIObjects2.length === 0 ) ? 0 :gdjs.Level_321Code.GDEquipUIObjects2[0].getPointX("")) - 4,(( gdjs.Level_321Code.GDEquipUIObjects2.length === 0 ) ? 0 :gdjs.Level_321Code.GDEquipUIObjects2[0].getPointY("")) - 4);
}
}
{ //Subevents
gdjs.Level_321Code.eventsList5(runtimeScene);} //End of subevents
}

}


{


gdjs.Level_321Code.condition0IsTrue_0.val = false;
{
gdjs.Level_321Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Num2");
}if (gdjs.Level_321Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("EquipUI"), gdjs.Level_321Code.GDEquipUIObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("SelectUI"), gdjs.Level_321Code.GDSelectUIObjects2);
{for(var i = 0, len = gdjs.Level_321Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayerObjects2[i].returnVariable(gdjs.Level_321Code.GDPlayerObjects2[i].getVariables().getFromIndex(2)).setString("Shotgun");
}
}{for(var i = 0, len = gdjs.Level_321Code.GDSelectUIObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDSelectUIObjects2[i].setPosition((( gdjs.Level_321Code.GDEquipUIObjects2.length === 0 ) ? 0 :gdjs.Level_321Code.GDEquipUIObjects2[0].getPointX("")) - 4 + 64,(( gdjs.Level_321Code.GDEquipUIObjects2.length === 0 ) ? 0 :gdjs.Level_321Code.GDEquipUIObjects2[0].getPointY("")) - 4);
}
}
{ //Subevents
gdjs.Level_321Code.eventsList6(runtimeScene);} //End of subevents
}

}


{


gdjs.Level_321Code.condition0IsTrue_0.val = false;
{
gdjs.Level_321Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Num3");
}if (gdjs.Level_321Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("EquipUI"), gdjs.Level_321Code.GDEquipUIObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("SelectUI"), gdjs.Level_321Code.GDSelectUIObjects2);
{for(var i = 0, len = gdjs.Level_321Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayerObjects2[i].returnVariable(gdjs.Level_321Code.GDPlayerObjects2[i].getVariables().getFromIndex(2)).setString("Sniper");
}
}{for(var i = 0, len = gdjs.Level_321Code.GDSelectUIObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDSelectUIObjects2[i].setPosition((( gdjs.Level_321Code.GDEquipUIObjects2.length === 0 ) ? 0 :gdjs.Level_321Code.GDEquipUIObjects2[0].getPointX("")) - 4 + 128,(( gdjs.Level_321Code.GDEquipUIObjects2.length === 0 ) ? 0 :gdjs.Level_321Code.GDEquipUIObjects2[0].getPointY("")) - 4);
}
}
{ //Subevents
gdjs.Level_321Code.eventsList7(runtimeScene);} //End of subevents
}

}


{


gdjs.Level_321Code.condition0IsTrue_0.val = false;
{
gdjs.Level_321Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Num4");
}if (gdjs.Level_321Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("EquipUI"), gdjs.Level_321Code.GDEquipUIObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("SelectUI"), gdjs.Level_321Code.GDSelectUIObjects2);
{for(var i = 0, len = gdjs.Level_321Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayerObjects2[i].returnVariable(gdjs.Level_321Code.GDPlayerObjects2[i].getVariables().getFromIndex(2)).setString("Assault");
}
}{for(var i = 0, len = gdjs.Level_321Code.GDSelectUIObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDSelectUIObjects2[i].setPosition((( gdjs.Level_321Code.GDEquipUIObjects2.length === 0 ) ? 0 :gdjs.Level_321Code.GDEquipUIObjects2[0].getPointX("")) - 4 + 192,(( gdjs.Level_321Code.GDEquipUIObjects2.length === 0 ) ? 0 :gdjs.Level_321Code.GDEquipUIObjects2[0].getPointY("")) - 4);
}
}
{ //Subevents
gdjs.Level_321Code.eventsList8(runtimeScene);} //End of subevents
}

}


{


gdjs.Level_321Code.condition0IsTrue_0.val = false;
{
gdjs.Level_321Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Num5");
}if (gdjs.Level_321Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("EquipUI"), gdjs.Level_321Code.GDEquipUIObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("SelectUI"), gdjs.Level_321Code.GDSelectUIObjects2);
{for(var i = 0, len = gdjs.Level_321Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayerObjects2[i].returnVariable(gdjs.Level_321Code.GDPlayerObjects2[i].getVariables().getFromIndex(2)).setString("Grenade");
}
}{for(var i = 0, len = gdjs.Level_321Code.GDSelectUIObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDSelectUIObjects2[i].setPosition((( gdjs.Level_321Code.GDEquipUIObjects2.length === 0 ) ? 0 :gdjs.Level_321Code.GDEquipUIObjects2[0].getPointX("")) - 4 + 256,(( gdjs.Level_321Code.GDEquipUIObjects2.length === 0 ) ? 0 :gdjs.Level_321Code.GDEquipUIObjects2[0].getPointY("")) - 4);
}
}
{ //Subevents
gdjs.Level_321Code.eventsList9(runtimeScene);} //End of subevents
}

}


{


gdjs.Level_321Code.condition0IsTrue_0.val = false;
{
gdjs.Level_321Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Num6");
}if (gdjs.Level_321Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("EquipUI"), gdjs.Level_321Code.GDEquipUIObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("SelectUI"), gdjs.Level_321Code.GDSelectUIObjects2);
{for(var i = 0, len = gdjs.Level_321Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayerObjects2[i].returnVariable(gdjs.Level_321Code.GDPlayerObjects2[i].getVariables().getFromIndex(2)).setString("Barricade");
}
}{for(var i = 0, len = gdjs.Level_321Code.GDSelectUIObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDSelectUIObjects2[i].setPosition((( gdjs.Level_321Code.GDEquipUIObjects2.length === 0 ) ? 0 :gdjs.Level_321Code.GDEquipUIObjects2[0].getPointX("")) - 4 + 320,(( gdjs.Level_321Code.GDEquipUIObjects2.length === 0 ) ? 0 :gdjs.Level_321Code.GDEquipUIObjects2[0].getPointY("")) - 4);
}
}
{ //Subevents
gdjs.Level_321Code.eventsList10(runtimeScene);} //End of subevents
}

}


{


gdjs.Level_321Code.condition0IsTrue_0.val = false;
{
gdjs.Level_321Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Num7");
}if (gdjs.Level_321Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("EquipUI"), gdjs.Level_321Code.GDEquipUIObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("SelectUI"), gdjs.Level_321Code.GDSelectUIObjects2);
{for(var i = 0, len = gdjs.Level_321Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayerObjects2[i].returnVariable(gdjs.Level_321Code.GDPlayerObjects2[i].getVariables().getFromIndex(2)).setString("Cover");
}
}{for(var i = 0, len = gdjs.Level_321Code.GDSelectUIObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDSelectUIObjects2[i].setPosition((( gdjs.Level_321Code.GDEquipUIObjects2.length === 0 ) ? 0 :gdjs.Level_321Code.GDEquipUIObjects2[0].getPointX("")) - 4 + 384,(( gdjs.Level_321Code.GDEquipUIObjects2.length === 0 ) ? 0 :gdjs.Level_321Code.GDEquipUIObjects2[0].getPointY("")) - 4);
}
}
{ //Subevents
gdjs.Level_321Code.eventsList11(runtimeScene);} //End of subevents
}

}


{


gdjs.Level_321Code.condition0IsTrue_0.val = false;
{
gdjs.Level_321Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Num8");
}if (gdjs.Level_321Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("EquipUI"), gdjs.Level_321Code.GDEquipUIObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("SelectUI"), gdjs.Level_321Code.GDSelectUIObjects2);
{for(var i = 0, len = gdjs.Level_321Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayerObjects2[i].returnVariable(gdjs.Level_321Code.GDPlayerObjects2[i].getVariables().getFromIndex(2)).setString("Spikes");
}
}{for(var i = 0, len = gdjs.Level_321Code.GDSelectUIObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDSelectUIObjects2[i].setPosition((( gdjs.Level_321Code.GDEquipUIObjects2.length === 0 ) ? 0 :gdjs.Level_321Code.GDEquipUIObjects2[0].getPointX("")) - 4 + 448,(( gdjs.Level_321Code.GDEquipUIObjects2.length === 0 ) ? 0 :gdjs.Level_321Code.GDEquipUIObjects2[0].getPointY("")) - 4);
}
}
{ //Subevents
gdjs.Level_321Code.eventsList12(runtimeScene);} //End of subevents
}

}


{



}


{


{
gdjs.copyArray(runtimeScene.getObjects("Assault"), gdjs.Level_321Code.GDAssaultObjects2);
gdjs.copyArray(runtimeScene.getObjects("AssaultAmmo"), gdjs.Level_321Code.GDAssaultAmmoObjects2);
gdjs.copyArray(runtimeScene.getObjects("Pistol"), gdjs.Level_321Code.GDPistolObjects2);
gdjs.copyArray(runtimeScene.getObjects("PistolAmmo"), gdjs.Level_321Code.GDPistolAmmoObjects2);
gdjs.copyArray(runtimeScene.getObjects("Rifle"), gdjs.Level_321Code.GDRifleObjects2);
gdjs.copyArray(runtimeScene.getObjects("RifleAmmo"), gdjs.Level_321Code.GDRifleAmmoObjects2);
gdjs.copyArray(runtimeScene.getObjects("Shotgun"), gdjs.Level_321Code.GDShotgunObjects2);
gdjs.copyArray(runtimeScene.getObjects("ShotgunAmmo"), gdjs.Level_321Code.GDShotgunAmmoObjects2);
{for(var i = 0, len = gdjs.Level_321Code.GDPistolAmmoObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPistolAmmoObjects2[i].setString((gdjs.RuntimeObject.getVariableString(((gdjs.Level_321Code.GDPistolObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Level_321Code.GDPistolObjects2[0].getVariables()).getFromIndex(2))));
}
}{for(var i = 0, len = gdjs.Level_321Code.GDShotgunAmmoObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDShotgunAmmoObjects2[i].setString((gdjs.RuntimeObject.getVariableString(((gdjs.Level_321Code.GDShotgunObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Level_321Code.GDShotgunObjects2[0].getVariables()).getFromIndex(2))));
}
}{for(var i = 0, len = gdjs.Level_321Code.GDRifleAmmoObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDRifleAmmoObjects2[i].setString((gdjs.RuntimeObject.getVariableString(((gdjs.Level_321Code.GDRifleObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Level_321Code.GDRifleObjects2[0].getVariables()).getFromIndex(2))));
}
}{for(var i = 0, len = gdjs.Level_321Code.GDAssaultAmmoObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDAssaultAmmoObjects2[i].setString((gdjs.RuntimeObject.getVariableString(((gdjs.Level_321Code.GDAssaultObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Level_321Code.GDAssaultObjects2[0].getVariables()).getFromIndex(2))));
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("BarricadeGhost"), gdjs.Level_321Code.GDBarricadeGhostObjects2);
gdjs.copyArray(runtimeScene.getObjects("BarricadeShortGhost"), gdjs.Level_321Code.GDBarricadeShortGhostObjects2);
gdjs.copyArray(runtimeScene.getObjects("BarricadeSpikesGhost"), gdjs.Level_321Code.GDBarricadeSpikesGhostObjects2);
gdjs.copyArray(runtimeScene.getObjects("MouseObject"), gdjs.Level_321Code.GDMouseObjectObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);

gdjs.Level_321Code.condition0IsTrue_0.val = false;
gdjs.Level_321Code.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level_321Code.GDBarricadeGhostObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDBarricadeGhostObjects2[i].isOnLayer("") ) {
        gdjs.Level_321Code.condition0IsTrue_0.val = true;
        gdjs.Level_321Code.GDBarricadeGhostObjects2[k] = gdjs.Level_321Code.GDBarricadeGhostObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDBarricadeGhostObjects2.length = k;for(var i = 0, k = 0, l = gdjs.Level_321Code.GDBarricadeShortGhostObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDBarricadeShortGhostObjects2[i].isOnLayer("") ) {
        gdjs.Level_321Code.condition0IsTrue_0.val = true;
        gdjs.Level_321Code.GDBarricadeShortGhostObjects2[k] = gdjs.Level_321Code.GDBarricadeShortGhostObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDBarricadeShortGhostObjects2.length = k;for(var i = 0, k = 0, l = gdjs.Level_321Code.GDBarricadeSpikesGhostObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDBarricadeSpikesGhostObjects2[i].isOnLayer("") ) {
        gdjs.Level_321Code.condition0IsTrue_0.val = true;
        gdjs.Level_321Code.GDBarricadeSpikesGhostObjects2[k] = gdjs.Level_321Code.GDBarricadeSpikesGhostObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDBarricadeSpikesGhostObjects2.length = k;}if ( gdjs.Level_321Code.condition0IsTrue_0.val ) {
{
gdjs.Level_321Code.condition1IsTrue_0.val = gdjs.evtTools.object.distanceTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects2Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDMouseObjectObjects2Objects, (gdjs.RuntimeObject.getVariableNumber(((gdjs.Level_321Code.GDPlayerObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Level_321Code.GDPlayerObjects2[0].getVariables()).getFromIndex(3))), false);
}}
if (gdjs.Level_321Code.condition1IsTrue_0.val) {
/* Reuse gdjs.Level_321Code.GDBarricadeGhostObjects2 */
/* Reuse gdjs.Level_321Code.GDBarricadeShortGhostObjects2 */
/* Reuse gdjs.Level_321Code.GDBarricadeSpikesGhostObjects2 */
{for(var i = 0, len = gdjs.Level_321Code.GDBarricadeGhostObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDBarricadeGhostObjects2[i].setPosition(32 * (Math.round((gdjs.evtTools.input.getMouseX(runtimeScene, "", 0) - 16) / 32)),32 * (Math.round((gdjs.evtTools.input.getMouseY(runtimeScene, "", 0) - 32) / 32)));
}
}{for(var i = 0, len = gdjs.Level_321Code.GDBarricadeShortGhostObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDBarricadeShortGhostObjects2[i].setPosition(32 * (Math.round((gdjs.evtTools.input.getMouseX(runtimeScene, "", 0) - 16) / 32)),32 * (Math.round((gdjs.evtTools.input.getMouseY(runtimeScene, "", 0) - 16) / 32)));
}
}{for(var i = 0, len = gdjs.Level_321Code.GDBarricadeSpikesGhostObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDBarricadeSpikesGhostObjects2[i].setPosition(32 * (Math.round((gdjs.evtTools.input.getMouseX(runtimeScene, "", 0) - 16) / 32)),32 * (Math.round((gdjs.evtTools.input.getMouseY(runtimeScene, "", 0) - 16) / 32)));
}
}}

}


{



}


{


{
gdjs.copyArray(runtimeScene.getObjects("MouseObject"), gdjs.Level_321Code.GDMouseObjectObjects1);
{for(var i = 0, len = gdjs.Level_321Code.GDMouseObjectObjects1.length ;i < len;++i) {
    gdjs.Level_321Code.GDMouseObjectObjects1[i].setPosition(gdjs.evtTools.input.getMouseX(runtimeScene, "", 0),gdjs.evtTools.input.getMouseY(runtimeScene, "", 0));
}
}}

}


};gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDZambamboObjects2Objects = Hashtable.newFrom({"Zambambo": gdjs.Level_321Code.GDZambamboObjects2});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDZambamboHealthObjects2Objects = Hashtable.newFrom({"ZambamboHealth": gdjs.Level_321Code.GDZambamboHealthObjects2});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDZambamboHealthBackObjects2Objects = Hashtable.newFrom({"ZambamboHealthBack": gdjs.Level_321Code.GDZambamboHealthBackObjects2});gdjs.Level_321Code.eventsList14 = function(runtimeScene) {

};gdjs.Level_321Code.eventsList15 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("SpawnPoint"), gdjs.Level_321Code.GDSpawnPointObjects1);

for(gdjs.Level_321Code.forEachIndex2 = 0;gdjs.Level_321Code.forEachIndex2 < gdjs.Level_321Code.GDSpawnPointObjects1.length;++gdjs.Level_321Code.forEachIndex2) {
gdjs.Level_321Code.GDZambamboObjects2.length = 0;

gdjs.Level_321Code.GDZambamboHealthObjects2.length = 0;

gdjs.Level_321Code.GDZambamboHealthBackObjects2.length = 0;

gdjs.Level_321Code.GDSpawnPointObjects2.length = 0;


gdjs.Level_321Code.forEachTemporary2 = gdjs.Level_321Code.GDSpawnPointObjects1[gdjs.Level_321Code.forEachIndex2];
gdjs.Level_321Code.GDSpawnPointObjects2.push(gdjs.Level_321Code.forEachTemporary2);
gdjs.Level_321Code.condition0IsTrue_0.val = false;
gdjs.Level_321Code.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level_321Code.GDSpawnPointObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDSpawnPointObjects2[i].getVariableNumber(gdjs.Level_321Code.GDSpawnPointObjects2[i].getVariables().getFromIndex(0)) == 1 ) {
        gdjs.Level_321Code.condition0IsTrue_0.val = true;
        gdjs.Level_321Code.GDSpawnPointObjects2[k] = gdjs.Level_321Code.GDSpawnPointObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDSpawnPointObjects2.length = k;}if ( gdjs.Level_321Code.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level_321Code.GDSpawnPointObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDSpawnPointObjects2[i].getTimerElapsedTimeInSecondsOrNaN("SpawnTimer") > 10 ) {
        gdjs.Level_321Code.condition1IsTrue_0.val = true;
        gdjs.Level_321Code.GDSpawnPointObjects2[k] = gdjs.Level_321Code.GDSpawnPointObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDSpawnPointObjects2.length = k;}}
if (gdjs.Level_321Code.condition1IsTrue_0.val) {
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDZambamboObjects2Objects, (( gdjs.Level_321Code.GDSpawnPointObjects2.length === 0 ) ? 0 :gdjs.Level_321Code.GDSpawnPointObjects2[0].getPointX("")), (( gdjs.Level_321Code.GDSpawnPointObjects2.length === 0 ) ? 0 :gdjs.Level_321Code.GDSpawnPointObjects2[0].getPointY("")), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDZambamboHealthObjects2Objects, (( gdjs.Level_321Code.GDZambamboObjects2.length === 0 ) ? 0 :gdjs.Level_321Code.GDZambamboObjects2[0].getPointX("")), (( gdjs.Level_321Code.GDZambamboObjects2.length === 0 ) ? 0 :gdjs.Level_321Code.GDZambamboObjects2[0].getPointY("")) + 64, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDZambamboHealthBackObjects2Objects, (( gdjs.Level_321Code.GDZambamboObjects2.length === 0 ) ? 0 :gdjs.Level_321Code.GDZambamboObjects2[0].getPointX("")), (( gdjs.Level_321Code.GDZambamboObjects2.length === 0 ) ? 0 :gdjs.Level_321Code.GDZambamboObjects2[0].getPointY("")) + 64, "");
}{gdjs.evtTools.linkedObjects.linkObjects(runtimeScene, (gdjs.Level_321Code.GDZambamboObjects2.length !== 0 ? gdjs.Level_321Code.GDZambamboObjects2[0] : null), (gdjs.Level_321Code.GDZambamboHealthObjects2.length !== 0 ? gdjs.Level_321Code.GDZambamboHealthObjects2[0] : null));
}{gdjs.evtTools.linkedObjects.linkObjects(runtimeScene, (gdjs.Level_321Code.GDZambamboObjects2.length !== 0 ? gdjs.Level_321Code.GDZambamboObjects2[0] : null), (gdjs.Level_321Code.GDZambamboHealthBackObjects2.length !== 0 ? gdjs.Level_321Code.GDZambamboHealthBackObjects2[0] : null));
}{for(var i = 0, len = gdjs.Level_321Code.GDSpawnPointObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDSpawnPointObjects2[i].resetTimer("SpawnTimer");
}
}}
}

}


};gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDZambamboHealthObjects3Objects = Hashtable.newFrom({"ZambamboHealth": gdjs.Level_321Code.GDZambamboHealthObjects3});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDZambamboHealthBackObjects3Objects = Hashtable.newFrom({"ZambamboHealthBack": gdjs.Level_321Code.GDZambamboHealthBackObjects3});gdjs.Level_321Code.eventsList16 = function(runtimeScene) {

};gdjs.Level_321Code.eventsList17 = function(runtimeScene) {

};gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects3ObjectsGDgdjs_46Level_95321Code_46GDWallObjects3ObjectsGDgdjs_46Level_95321Code_46GDBarricadeObjects3Objects = Hashtable.newFrom({"Player": gdjs.Level_321Code.GDPlayerObjects3, "Wall": gdjs.Level_321Code.GDWallObjects3, "Barricade": gdjs.Level_321Code.GDBarricadeObjects3});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects4Objects = Hashtable.newFrom({"Player": gdjs.Level_321Code.GDPlayerObjects4});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects4Objects = Hashtable.newFrom({"Player": gdjs.Level_321Code.GDPlayerObjects4});gdjs.Level_321Code.eventsList18 = function(runtimeScene) {

{



}


{

gdjs.copyArray(gdjs.Level_321Code.GDPlayerObjects3, gdjs.Level_321Code.GDPlayerObjects4);


gdjs.Level_321Code.condition0IsTrue_0.val = false;
{
gdjs.Level_321Code.condition0IsTrue_0.val = gdjs.evtTools.object.pickedObjectsCount(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects4Objects) > 0;
}if (gdjs.Level_321Code.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.Level_321Code.GDZambamboObjects3, gdjs.Level_321Code.GDZambamboObjects4);

{for(var i = 0, len = gdjs.Level_321Code.GDZambamboObjects4.length ;i < len;++i) {
    gdjs.Level_321Code.GDZambamboObjects4[i].returnVariable(gdjs.Level_321Code.GDZambamboObjects4[i].getVariables().getFromIndex(0)).setNumber(1);
}
}}

}


{

gdjs.copyArray(gdjs.Level_321Code.GDPlayerObjects3, gdjs.Level_321Code.GDPlayerObjects4);


gdjs.Level_321Code.condition0IsTrue_0.val = false;
{
gdjs.Level_321Code.condition0IsTrue_0.val = gdjs.evtTools.object.pickedObjectsCount(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects4Objects) == 0;
}if (gdjs.Level_321Code.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.Level_321Code.GDZambamboObjects3, gdjs.Level_321Code.GDZambamboObjects4);

{for(var i = 0, len = gdjs.Level_321Code.GDZambamboObjects4.length ;i < len;++i) {
    gdjs.Level_321Code.GDZambamboObjects4[i].returnVariable(gdjs.Level_321Code.GDZambamboObjects4[i].getVariables().getFromIndex(0)).setNumber(0);
}
}}

}


};gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDZambamboObjects2Objects = Hashtable.newFrom({"Zambambo": gdjs.Level_321Code.GDZambamboObjects2});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBarricadeObjects2Objects = Hashtable.newFrom({"Barricade": gdjs.Level_321Code.GDBarricadeObjects2});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDZambamboObjects2Objects = Hashtable.newFrom({"Zambambo": gdjs.Level_321Code.GDZambamboObjects2});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBarricadeShortObjects2Objects = Hashtable.newFrom({"BarricadeShort": gdjs.Level_321Code.GDBarricadeShortObjects2});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDZambamboObjects2Objects = Hashtable.newFrom({"Zambambo": gdjs.Level_321Code.GDZambamboObjects2});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBarricadeObjects2Objects = Hashtable.newFrom({"Barricade": gdjs.Level_321Code.GDBarricadeObjects2});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDZambamboObjects2Objects = Hashtable.newFrom({"Zambambo": gdjs.Level_321Code.GDZambamboObjects2});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBarricadeShortObjects2Objects = Hashtable.newFrom({"BarricadeShort": gdjs.Level_321Code.GDBarricadeShortObjects2});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDZambamboObjects2Objects = Hashtable.newFrom({"Zambambo": gdjs.Level_321Code.GDZambamboObjects2});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level_321Code.GDPlayerObjects2});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDZambamboHealthObjects1Objects = Hashtable.newFrom({"ZambamboHealth": gdjs.Level_321Code.GDZambamboHealthObjects1});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDZambamboHealthBackObjects1Objects = Hashtable.newFrom({"ZambamboHealthBack": gdjs.Level_321Code.GDZambamboHealthBackObjects1});gdjs.Level_321Code.eventsList19 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Zambambo"), gdjs.Level_321Code.GDZambamboObjects2);

for(gdjs.Level_321Code.forEachIndex3 = 0;gdjs.Level_321Code.forEachIndex3 < gdjs.Level_321Code.GDZambamboObjects2.length;++gdjs.Level_321Code.forEachIndex3) {
gdjs.copyArray(runtimeScene.getObjects("ZambamboHealth"), gdjs.Level_321Code.GDZambamboHealthObjects3);
gdjs.copyArray(runtimeScene.getObjects("ZambamboHealthBack"), gdjs.Level_321Code.GDZambamboHealthBackObjects3);
gdjs.Level_321Code.GDZambamboObjects3.length = 0;


gdjs.Level_321Code.forEachTemporary3 = gdjs.Level_321Code.GDZambamboObjects2[gdjs.Level_321Code.forEachIndex3];
gdjs.Level_321Code.GDZambamboObjects3.push(gdjs.Level_321Code.forEachTemporary3);
gdjs.Level_321Code.condition0IsTrue_0.val = false;
gdjs.Level_321Code.condition1IsTrue_0.val = false;
{
gdjs.Level_321Code.condition0IsTrue_0.val = gdjs.evtTools.linkedObjects.pickObjectsLinkedTo(runtimeScene, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDZambamboHealthObjects3Objects, (gdjs.Level_321Code.GDZambamboObjects3.length !== 0 ? gdjs.Level_321Code.GDZambamboObjects3[0] : null), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}if ( gdjs.Level_321Code.condition0IsTrue_0.val ) {
{
gdjs.Level_321Code.condition1IsTrue_0.val = gdjs.evtTools.linkedObjects.pickObjectsLinkedTo(runtimeScene, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDZambamboHealthBackObjects3Objects, (gdjs.Level_321Code.GDZambamboObjects3.length !== 0 ? gdjs.Level_321Code.GDZambamboObjects3[0] : null), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}
if (gdjs.Level_321Code.condition1IsTrue_0.val) {
{for(var i = 0, len = gdjs.Level_321Code.GDZambamboHealthObjects3.length ;i < len;++i) {
    gdjs.Level_321Code.GDZambamboHealthObjects3[i].setPosition((( gdjs.Level_321Code.GDZambamboObjects3.length === 0 ) ? 0 :gdjs.Level_321Code.GDZambamboObjects3[0].getPointX("")),(( gdjs.Level_321Code.GDZambamboObjects3.length === 0 ) ? 0 :gdjs.Level_321Code.GDZambamboObjects3[0].getPointY("")) + 64);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDZambamboHealthBackObjects3.length ;i < len;++i) {
    gdjs.Level_321Code.GDZambamboHealthBackObjects3[i].setPosition((( gdjs.Level_321Code.GDZambamboObjects3.length === 0 ) ? 0 :gdjs.Level_321Code.GDZambamboObjects3[0].getPointX("")),(( gdjs.Level_321Code.GDZambamboObjects3.length === 0 ) ? 0 :gdjs.Level_321Code.GDZambamboObjects3[0].getPointY("")) + 64);
}
}}
}

}


{



}


{


{
gdjs.copyArray(runtimeScene.getObjects("Zambambo"), gdjs.Level_321Code.GDZambamboObjects2);
{for(var i = 0, len = gdjs.Level_321Code.GDZambamboObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDZambamboObjects2[i].getBehavior("Pathfinding").setMaxSpeed((255 - gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(0))));
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Zambambo"), gdjs.Level_321Code.GDZambamboObjects2);

for(gdjs.Level_321Code.forEachIndex3 = 0;gdjs.Level_321Code.forEachIndex3 < gdjs.Level_321Code.GDZambamboObjects2.length;++gdjs.Level_321Code.forEachIndex3) {
gdjs.Level_321Code.GDZambamboObjects3.length = 0;


gdjs.Level_321Code.forEachTemporary3 = gdjs.Level_321Code.GDZambamboObjects2[gdjs.Level_321Code.forEachIndex3];
gdjs.Level_321Code.GDZambamboObjects3.push(gdjs.Level_321Code.forEachTemporary3);
if (true) {
{for(var i = 0, len = gdjs.Level_321Code.GDZambamboObjects3.length ;i < len;++i) {
    gdjs.Level_321Code.GDZambamboObjects3[i].setZOrder((gdjs.Level_321Code.GDZambamboObjects3[i].getCenterYInScene()));
}
}}
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Zambambo"), gdjs.Level_321Code.GDZambamboObjects2);

for(gdjs.Level_321Code.forEachIndex3 = 0;gdjs.Level_321Code.forEachIndex3 < gdjs.Level_321Code.GDZambamboObjects2.length;++gdjs.Level_321Code.forEachIndex3) {
gdjs.copyArray(runtimeScene.getObjects("Barricade"), gdjs.Level_321Code.GDBarricadeObjects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects3);
gdjs.copyArray(runtimeScene.getObjects("Wall"), gdjs.Level_321Code.GDWallObjects3);
gdjs.Level_321Code.GDZambamboObjects3.length = 0;


gdjs.Level_321Code.forEachTemporary3 = gdjs.Level_321Code.GDZambamboObjects2[gdjs.Level_321Code.forEachIndex3];
gdjs.Level_321Code.GDZambamboObjects3.push(gdjs.Level_321Code.forEachTemporary3);
gdjs.Level_321Code.condition0IsTrue_0.val = false;
{
gdjs.Level_321Code.condition0IsTrue_0.val = gdjs.evtTools.object.raycastObject(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects3ObjectsGDgdjs_46Level_95321Code_46GDWallObjects3ObjectsGDgdjs_46Level_95321Code_46GDBarricadeObjects3Objects, (( gdjs.Level_321Code.GDZambamboObjects3.length === 0 ) ? 0 :gdjs.Level_321Code.GDZambamboObjects3[0].getCenterXInScene()), (( gdjs.Level_321Code.GDZambamboObjects3.length === 0 ) ? 0 :gdjs.Level_321Code.GDZambamboObjects3[0].getCenterYInScene()), (( gdjs.Level_321Code.GDZambamboObjects3.length === 0 ) ? 0 :gdjs.Level_321Code.GDZambamboObjects3[0].getAngleToObject((gdjs.Level_321Code.GDPlayerObjects3.length !== 0 ? gdjs.Level_321Code.GDPlayerObjects3[0] : null))), 600, runtimeScene.getVariables().get("IntersectionX"), runtimeScene.getVariables().get("IntersectionY"), false);
}if (gdjs.Level_321Code.condition0IsTrue_0.val) {

{ //Subevents: 
gdjs.Level_321Code.eventsList18(runtimeScene);} //Subevents end.
}
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Zambambo"), gdjs.Level_321Code.GDZambamboObjects2);

gdjs.Level_321Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level_321Code.GDZambamboObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDZambamboObjects2[i].getVariableNumber(gdjs.Level_321Code.GDZambamboObjects2[i].getVariables().getFromIndex(0)) == 1 ) {
        gdjs.Level_321Code.condition0IsTrue_0.val = true;
        gdjs.Level_321Code.GDZambamboObjects2[k] = gdjs.Level_321Code.GDZambamboObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDZambamboObjects2.length = k;}if (gdjs.Level_321Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);
/* Reuse gdjs.Level_321Code.GDZambamboObjects2 */
{for(var i = 0, len = gdjs.Level_321Code.GDZambamboObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDZambamboObjects2[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.Level_321Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Level_321Code.GDPlayerObjects2[0].getPointX("")) + gdjs.random(60), (( gdjs.Level_321Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Level_321Code.GDPlayerObjects2[0].getPointY("")) + gdjs.random(60));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Barricade"), gdjs.Level_321Code.GDBarricadeObjects2);
gdjs.copyArray(runtimeScene.getObjects("Zambambo"), gdjs.Level_321Code.GDZambamboObjects2);

gdjs.Level_321Code.condition0IsTrue_0.val = false;
{
gdjs.Level_321Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDZambamboObjects2Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBarricadeObjects2Objects, false, runtimeScene, true);
}if (gdjs.Level_321Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level_321Code.GDBarricadeObjects2 */
/* Reuse gdjs.Level_321Code.GDZambamboObjects2 */
{for(var i = 0, len = gdjs.Level_321Code.GDZambamboObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDZambamboObjects2[i].activateBehavior("Pathfinding", false);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDBarricadeObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDBarricadeObjects2[i].getBehavior("Health").Hit((gdjs.RuntimeObject.getVariableNumber(((gdjs.Level_321Code.GDZambamboObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Level_321Code.GDZambamboObjects2[0].getVariables()).getFromIndex(1))), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("BarricadeShort"), gdjs.Level_321Code.GDBarricadeShortObjects2);
gdjs.copyArray(runtimeScene.getObjects("Zambambo"), gdjs.Level_321Code.GDZambamboObjects2);

gdjs.Level_321Code.condition0IsTrue_0.val = false;
{
gdjs.Level_321Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDZambamboObjects2Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBarricadeShortObjects2Objects, false, runtimeScene, true);
}if (gdjs.Level_321Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level_321Code.GDBarricadeShortObjects2 */
/* Reuse gdjs.Level_321Code.GDZambamboObjects2 */
{for(var i = 0, len = gdjs.Level_321Code.GDZambamboObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDZambamboObjects2[i].activateBehavior("Pathfinding", false);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDBarricadeShortObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDBarricadeShortObjects2[i].getBehavior("Health").Hit((gdjs.RuntimeObject.getVariableNumber(((gdjs.Level_321Code.GDZambamboObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Level_321Code.GDZambamboObjects2[0].getVariables()).getFromIndex(1))), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Barricade"), gdjs.Level_321Code.GDBarricadeObjects2);
gdjs.copyArray(runtimeScene.getObjects("BarricadeShort"), gdjs.Level_321Code.GDBarricadeShortObjects2);
gdjs.copyArray(runtimeScene.getObjects("Zambambo"), gdjs.Level_321Code.GDZambamboObjects2);

gdjs.Level_321Code.condition0IsTrue_0.val = false;
gdjs.Level_321Code.condition1IsTrue_0.val = false;
{
gdjs.Level_321Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDZambamboObjects2Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBarricadeObjects2Objects, true, runtimeScene, false);
}if ( gdjs.Level_321Code.condition0IsTrue_0.val ) {
{
gdjs.Level_321Code.condition1IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDZambamboObjects2Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBarricadeShortObjects2Objects, true, runtimeScene, false);
}}
if (gdjs.Level_321Code.condition1IsTrue_0.val) {
/* Reuse gdjs.Level_321Code.GDZambamboObjects2 */
{for(var i = 0, len = gdjs.Level_321Code.GDZambamboObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDZambamboObjects2[i].activateBehavior("Pathfinding", true);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Zambambo"), gdjs.Level_321Code.GDZambamboObjects2);

gdjs.Level_321Code.condition0IsTrue_0.val = false;
{
gdjs.Level_321Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDZambamboObjects2Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects2Objects, false, runtimeScene, false);
}if (gdjs.Level_321Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level_321Code.GDPlayerObjects2 */
/* Reuse gdjs.Level_321Code.GDZambamboObjects2 */
{for(var i = 0, len = gdjs.Level_321Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayerObjects2[i].getBehavior("Health").Hit((gdjs.RuntimeObject.getVariableNumber(((gdjs.Level_321Code.GDZambamboObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Level_321Code.GDZambamboObjects2[0].getVariables()).getFromIndex(1))), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Zambambo"), gdjs.Level_321Code.GDZambamboObjects1);
gdjs.copyArray(runtimeScene.getObjects("ZambamboHealth"), gdjs.Level_321Code.GDZambamboHealthObjects1);
gdjs.copyArray(runtimeScene.getObjects("ZambamboHealthBack"), gdjs.Level_321Code.GDZambamboHealthBackObjects1);

gdjs.Level_321Code.condition0IsTrue_0.val = false;
gdjs.Level_321Code.condition1IsTrue_0.val = false;
gdjs.Level_321Code.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level_321Code.GDZambamboObjects1.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDZambamboObjects1[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.Level_321Code.condition0IsTrue_0.val = true;
        gdjs.Level_321Code.GDZambamboObjects1[k] = gdjs.Level_321Code.GDZambamboObjects1[i];
        ++k;
    }
}
gdjs.Level_321Code.GDZambamboObjects1.length = k;}if ( gdjs.Level_321Code.condition0IsTrue_0.val ) {
{
gdjs.Level_321Code.condition1IsTrue_0.val = gdjs.evtTools.linkedObjects.pickObjectsLinkedTo(runtimeScene, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDZambamboHealthObjects1Objects, (gdjs.Level_321Code.GDZambamboObjects1.length !== 0 ? gdjs.Level_321Code.GDZambamboObjects1[0] : null), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}if ( gdjs.Level_321Code.condition1IsTrue_0.val ) {
{
gdjs.Level_321Code.condition2IsTrue_0.val = gdjs.evtTools.linkedObjects.pickObjectsLinkedTo(runtimeScene, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDZambamboHealthBackObjects1Objects, (gdjs.Level_321Code.GDZambamboObjects1.length !== 0 ? gdjs.Level_321Code.GDZambamboObjects1[0] : null), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}
}
if (gdjs.Level_321Code.condition2IsTrue_0.val) {
/* Reuse gdjs.Level_321Code.GDZambamboObjects1 */
/* Reuse gdjs.Level_321Code.GDZambamboHealthObjects1 */
/* Reuse gdjs.Level_321Code.GDZambamboHealthBackObjects1 */
{for(var i = 0, len = gdjs.Level_321Code.GDZambamboHealthObjects1.length ;i < len;++i) {
    gdjs.Level_321Code.GDZambamboHealthObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDZambamboHealthBackObjects1.length ;i < len;++i) {
    gdjs.Level_321Code.GDZambamboHealthBackObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDZambamboObjects1.length ;i < len;++i) {
    gdjs.Level_321Code.GDZambamboObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerHeadObjects2Objects = Hashtable.newFrom({"PlayerHead": gdjs.Level_321Code.GDPlayerHeadObjects2});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDWallObjects2Objects = Hashtable.newFrom({"Wall": gdjs.Level_321Code.GDWallObjects2});gdjs.Level_321Code.eventsList20 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("PlayerHead"), gdjs.Level_321Code.GDPlayerHeadObjects2);
gdjs.copyArray(runtimeScene.getObjects("Wall"), gdjs.Level_321Code.GDWallObjects2);

gdjs.Level_321Code.condition0IsTrue_0.val = false;
{
gdjs.Level_321Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerHeadObjects2Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDWallObjects2Objects, false, runtimeScene, true);
}if (gdjs.Level_321Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level_321Code.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.Level_321Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayerObjects2[i].setZOrder(100000);
}
}}

}


};gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level_321Code.GDPlayerObjects2});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDWallObjects2Objects = Hashtable.newFrom({"Wall": gdjs.Level_321Code.GDWallObjects2});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDWallObjects2Objects = Hashtable.newFrom({"Wall": gdjs.Level_321Code.GDWallObjects2});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level_321Code.GDPlayerObjects2});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDFakewallObjects2Objects = Hashtable.newFrom({"Fakewall": gdjs.Level_321Code.GDFakewallObjects2});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDFakewallObjects2Objects = Hashtable.newFrom({"Fakewall": gdjs.Level_321Code.GDFakewallObjects2});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level_321Code.GDPlayerObjects2});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDtempwall1Objects2Objects = Hashtable.newFrom({"tempwall1": gdjs.Level_321Code.GDtempwall1Objects2});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDtempwall1Objects2Objects = Hashtable.newFrom({"tempwall1": gdjs.Level_321Code.GDtempwall1Objects2});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level_321Code.GDPlayerObjects2});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDtempwall2Objects2Objects = Hashtable.newFrom({"tempwall2": gdjs.Level_321Code.GDtempwall2Objects2});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDtempwall2Objects2Objects = Hashtable.newFrom({"tempwall2": gdjs.Level_321Code.GDtempwall2Objects2});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level_321Code.GDPlayerObjects2});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBarricadeObjects2Objects = Hashtable.newFrom({"Barricade": gdjs.Level_321Code.GDBarricadeObjects2});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBarricadeObjects2Objects = Hashtable.newFrom({"Barricade": gdjs.Level_321Code.GDBarricadeObjects2});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Level_321Code.GDPlayerObjects1});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBarricadeShortObjects1Objects = Hashtable.newFrom({"BarricadeShort": gdjs.Level_321Code.GDBarricadeShortObjects1});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBarricadeShortObjects1Objects = Hashtable.newFrom({"BarricadeShort": gdjs.Level_321Code.GDBarricadeShortObjects1});gdjs.Level_321Code.eventsList21 = function(runtimeScene) {

{


gdjs.Level_321Code.condition0IsTrue_0.val = false;
{
gdjs.Level_321Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "w");
}if (gdjs.Level_321Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);
{for(var i = 0, len = gdjs.Level_321Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayerObjects2[i].addForce(0, -((gdjs.RuntimeObject.getVariableNumber(gdjs.Level_321Code.GDPlayerObjects2[i].getVariables().getFromIndex(0)))), 0);
}
}}

}


{


gdjs.Level_321Code.condition0IsTrue_0.val = false;
{
gdjs.Level_321Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
}if (gdjs.Level_321Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);
{for(var i = 0, len = gdjs.Level_321Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayerObjects2[i].addForce(-((gdjs.RuntimeObject.getVariableNumber(gdjs.Level_321Code.GDPlayerObjects2[i].getVariables().getFromIndex(0)))), 0, 0);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayerObjects2[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayerObjects2[i].flipX(true);
}
}}

}


{


gdjs.Level_321Code.condition0IsTrue_0.val = false;
{
gdjs.Level_321Code.condition0IsTrue_0.val = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "a");
}if (gdjs.Level_321Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);
{for(var i = 0, len = gdjs.Level_321Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayerObjects2[i].setAnimation(0);
}
}}

}


{


gdjs.Level_321Code.condition0IsTrue_0.val = false;
{
gdjs.Level_321Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "s");
}if (gdjs.Level_321Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);
{for(var i = 0, len = gdjs.Level_321Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayerObjects2[i].addForce(0, (gdjs.RuntimeObject.getVariableNumber(gdjs.Level_321Code.GDPlayerObjects2[i].getVariables().getFromIndex(0))), 0);
}
}}

}


{


gdjs.Level_321Code.condition0IsTrue_0.val = false;
{
gdjs.Level_321Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
}if (gdjs.Level_321Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);
{for(var i = 0, len = gdjs.Level_321Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayerObjects2[i].addForce((gdjs.RuntimeObject.getVariableNumber(gdjs.Level_321Code.GDPlayerObjects2[i].getVariables().getFromIndex(0))), 0, 0);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayerObjects2[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayerObjects2[i].flipX(false);
}
}}

}


{


gdjs.Level_321Code.condition0IsTrue_0.val = false;
{
gdjs.Level_321Code.condition0IsTrue_0.val = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "d");
}if (gdjs.Level_321Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);
{for(var i = 0, len = gdjs.Level_321Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayerObjects2[i].setAnimation(0);
}
}}

}


{



}


{


{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("PlayerHead"), gdjs.Level_321Code.GDPlayerHeadObjects2);
{for(var i = 0, len = gdjs.Level_321Code.GDPlayerHeadObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayerHeadObjects2[i].setPosition((( gdjs.Level_321Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Level_321Code.GDPlayerObjects2[0].getPointX("")),(( gdjs.Level_321Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Level_321Code.GDPlayerObjects2[0].getPointY("")));
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);
{for(var i = 0, len = gdjs.Level_321Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayerObjects2[i].setZOrder((gdjs.Level_321Code.GDPlayerObjects2[i].getCenterYInScene()));
}
}
{ //Subevents
gdjs.Level_321Code.eventsList20(runtimeScene);} //End of subevents
}

}


{



}


{


{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);
{for(var i = 0, len = gdjs.Level_321Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayerObjects2[i].setAnimationName("Walking" + gdjs.evtTools.common.toString(Math.round((gdjs.Level_321Code.GDPlayerObjects2[i].getAngle()) / 90) * 90));
}
}}

}


{



}


{


{
gdjs.copyArray(runtimeScene.getObjects("Health"), gdjs.Level_321Code.GDHealthObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);
{for(var i = 0, len = gdjs.Level_321Code.GDHealthObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDHealthObjects2[i].setWidth(((( gdjs.Level_321Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Level_321Code.GDPlayerObjects2[0].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) * 64) / 10);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);

gdjs.Level_321Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level_321Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDPlayerObjects2[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.Level_321Code.condition0IsTrue_0.val = true;
        gdjs.Level_321Code.GDPlayerObjects2[k] = gdjs.Level_321Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDPlayerObjects2.length = k;}if (gdjs.Level_321Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level_321Code.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.Level_321Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayerObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("Build"), gdjs.Level_321Code.GDBuildObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);
{for(var i = 0, len = gdjs.Level_321Code.GDBuildObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDBuildObjects2[i].setWidth(((gdjs.RuntimeObject.getVariableNumber(((gdjs.Level_321Code.GDPlayerObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Level_321Code.GDPlayerObjects2[0].getVariables()).getFromIndex(1))) * 64) / 10);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Wall"), gdjs.Level_321Code.GDWallObjects2);

gdjs.Level_321Code.condition0IsTrue_0.val = false;
{
gdjs.Level_321Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects2Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDWallObjects2Objects, false, runtimeScene, false);
}if (gdjs.Level_321Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level_321Code.GDPlayerObjects2 */
/* Reuse gdjs.Level_321Code.GDWallObjects2 */
{for(var i = 0, len = gdjs.Level_321Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayerObjects2[i].separateFromObjectsList(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDWallObjects2Objects, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Fakewall"), gdjs.Level_321Code.GDFakewallObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);

gdjs.Level_321Code.condition0IsTrue_0.val = false;
{
gdjs.Level_321Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects2Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDFakewallObjects2Objects, false, runtimeScene, false);
}if (gdjs.Level_321Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level_321Code.GDFakewallObjects2 */
/* Reuse gdjs.Level_321Code.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.Level_321Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayerObjects2[i].separateFromObjectsList(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDFakewallObjects2Objects, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("tempwall1"), gdjs.Level_321Code.GDtempwall1Objects2);

gdjs.Level_321Code.condition0IsTrue_0.val = false;
{
gdjs.Level_321Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects2Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDtempwall1Objects2Objects, false, runtimeScene, false);
}if (gdjs.Level_321Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level_321Code.GDPlayerObjects2 */
/* Reuse gdjs.Level_321Code.GDtempwall1Objects2 */
{for(var i = 0, len = gdjs.Level_321Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayerObjects2[i].separateFromObjectsList(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDtempwall1Objects2Objects, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("tempwall2"), gdjs.Level_321Code.GDtempwall2Objects2);

gdjs.Level_321Code.condition0IsTrue_0.val = false;
{
gdjs.Level_321Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects2Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDtempwall2Objects2Objects, false, runtimeScene, false);
}if (gdjs.Level_321Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level_321Code.GDPlayerObjects2 */
/* Reuse gdjs.Level_321Code.GDtempwall2Objects2 */
{for(var i = 0, len = gdjs.Level_321Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayerObjects2[i].separateFromObjectsList(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDtempwall2Objects2Objects, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Barricade"), gdjs.Level_321Code.GDBarricadeObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);

gdjs.Level_321Code.condition0IsTrue_0.val = false;
{
gdjs.Level_321Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects2Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBarricadeObjects2Objects, false, runtimeScene, false);
}if (gdjs.Level_321Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level_321Code.GDBarricadeObjects2 */
/* Reuse gdjs.Level_321Code.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.Level_321Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayerObjects2[i].separateFromObjectsList(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBarricadeObjects2Objects, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("BarricadeShort"), gdjs.Level_321Code.GDBarricadeShortObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects1);

gdjs.Level_321Code.condition0IsTrue_0.val = false;
{
gdjs.Level_321Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects1Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBarricadeShortObjects1Objects, false, runtimeScene, false);
}if (gdjs.Level_321Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level_321Code.GDBarricadeShortObjects1 */
/* Reuse gdjs.Level_321Code.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.Level_321Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayerObjects1[i].separateFromObjectsList(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBarricadeShortObjects1Objects, false);
}
}}

}


};gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBulletObjects3Objects = Hashtable.newFrom({"Bullet": gdjs.Level_321Code.GDBulletObjects3});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects4Objects = Hashtable.newFrom({"Player": gdjs.Level_321Code.GDPlayerObjects4});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects5Objects = Hashtable.newFrom({"Player": gdjs.Level_321Code.GDPlayerObjects5});gdjs.Level_321Code.eventsList22 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Level_321Code.GDPlayerObjects4, gdjs.Level_321Code.GDPlayerObjects5);


gdjs.Level_321Code.condition0IsTrue_0.val = false;
{
gdjs.Level_321Code.condition0IsTrue_0.val = gdjs.evtTools.object.pickedObjectsCount(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects5Objects) > 0;
}if (gdjs.Level_321Code.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.Level_321Code.GDZambamboObjects4, gdjs.Level_321Code.GDZambamboObjects5);

{for(var i = 0, len = gdjs.Level_321Code.GDZambamboObjects5.length ;i < len;++i) {
    gdjs.Level_321Code.GDZambamboObjects5[i].returnVariable(gdjs.Level_321Code.GDZambamboObjects5[i].getVariables().getFromIndex(0)).setNumber(1);
}
}}

}


};gdjs.Level_321Code.eventsList23 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Level_321Code.GDPlayerObjects3, gdjs.Level_321Code.GDPlayerObjects4);


gdjs.Level_321Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level_321Code.GDPlayerObjects4.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDPlayerObjects4[i].getTimerElapsedTimeInSecondsOrNaN("Ammo") > 0.5 ) {
        gdjs.Level_321Code.condition0IsTrue_0.val = true;
        gdjs.Level_321Code.GDPlayerObjects4[k] = gdjs.Level_321Code.GDPlayerObjects4[i];
        ++k;
    }
}
gdjs.Level_321Code.GDPlayerObjects4.length = k;}if (gdjs.Level_321Code.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.Level_321Code.GDPistolObjects3, gdjs.Level_321Code.GDPistolObjects4);

/* Reuse gdjs.Level_321Code.GDPlayerObjects4 */
{for(var i = 0, len = gdjs.Level_321Code.GDPistolObjects4.length ;i < len;++i) {
    gdjs.Level_321Code.GDPistolObjects4[i].returnVariable(gdjs.Level_321Code.GDPistolObjects4[i].getVariables().getFromIndex(2)).sub(1);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayerObjects4[i].resetTimer("Ammo");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Zambambo"), gdjs.Level_321Code.GDZambamboObjects3);

for(gdjs.Level_321Code.forEachIndex4 = 0;gdjs.Level_321Code.forEachIndex4 < gdjs.Level_321Code.GDZambamboObjects3.length;++gdjs.Level_321Code.forEachIndex4) {
gdjs.copyArray(gdjs.Level_321Code.GDPistolObjects3, gdjs.Level_321Code.GDPistolObjects4);

gdjs.copyArray(gdjs.Level_321Code.GDPlayerObjects3, gdjs.Level_321Code.GDPlayerObjects4);

gdjs.Level_321Code.GDZambamboObjects4.length = 0;


gdjs.Level_321Code.forEachTemporary4 = gdjs.Level_321Code.GDZambamboObjects3[gdjs.Level_321Code.forEachIndex4];
gdjs.Level_321Code.GDZambamboObjects4.push(gdjs.Level_321Code.forEachTemporary4);
gdjs.Level_321Code.condition0IsTrue_0.val = false;
{
gdjs.Level_321Code.condition0IsTrue_0.val = gdjs.evtTools.object.raycastObject(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects4Objects, (( gdjs.Level_321Code.GDZambamboObjects4.length === 0 ) ? 0 :gdjs.Level_321Code.GDZambamboObjects4[0].getCenterXInScene()), (( gdjs.Level_321Code.GDZambamboObjects4.length === 0 ) ? 0 :gdjs.Level_321Code.GDZambamboObjects4[0].getCenterYInScene()), (( gdjs.Level_321Code.GDZambamboObjects4.length === 0 ) ? 0 :gdjs.Level_321Code.GDZambamboObjects4[0].getAngleToObject((gdjs.Level_321Code.GDPlayerObjects4.length !== 0 ? gdjs.Level_321Code.GDPlayerObjects4[0] : null))), (gdjs.RuntimeObject.getVariableNumber(((gdjs.Level_321Code.GDPistolObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Level_321Code.GDPistolObjects4[0].getVariables()).getFromIndex(3))), runtimeScene.getVariables().get("IntersectionX"), runtimeScene.getVariables().get("IntersectionY"), false);
}if (gdjs.Level_321Code.condition0IsTrue_0.val) {

{ //Subevents: 
gdjs.Level_321Code.eventsList22(runtimeScene);} //Subevents end.
}
}

}


};gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBulletObjects5Objects = Hashtable.newFrom({"Bullet": gdjs.Level_321Code.GDBulletObjects5});gdjs.Level_321Code.eventsList24 = function(runtimeScene) {

};gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects4Objects = Hashtable.newFrom({"Player": gdjs.Level_321Code.GDPlayerObjects4});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects5Objects = Hashtable.newFrom({"Player": gdjs.Level_321Code.GDPlayerObjects5});gdjs.Level_321Code.eventsList25 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Level_321Code.GDPlayerObjects4, gdjs.Level_321Code.GDPlayerObjects5);


gdjs.Level_321Code.condition0IsTrue_0.val = false;
{
gdjs.Level_321Code.condition0IsTrue_0.val = gdjs.evtTools.object.pickedObjectsCount(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects5Objects) > 0;
}if (gdjs.Level_321Code.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.Level_321Code.GDZambamboObjects4, gdjs.Level_321Code.GDZambamboObjects5);

{for(var i = 0, len = gdjs.Level_321Code.GDZambamboObjects5.length ;i < len;++i) {
    gdjs.Level_321Code.GDZambamboObjects5[i].returnVariable(gdjs.Level_321Code.GDZambamboObjects5[i].getVariables().getFromIndex(0)).setNumber(1);
}
}}

}


};gdjs.Level_321Code.eventsList26 = function(runtimeScene) {

{


gdjs.Level_321Code.repeatCount5 = 3;
for(gdjs.Level_321Code.repeatIndex5 = 0;gdjs.Level_321Code.repeatIndex5 < gdjs.Level_321Code.repeatCount5;++gdjs.Level_321Code.repeatIndex5) {
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.Level_321Code.GDBulletObjects5);
gdjs.copyArray(gdjs.Level_321Code.GDPlayerObjects3, gdjs.Level_321Code.GDPlayerObjects5);

gdjs.copyArray(gdjs.Level_321Code.GDShotgunObjects3, gdjs.Level_321Code.GDShotgunObjects5);


if (true)
{
{for(var i = 0, len = gdjs.Level_321Code.GDPlayerObjects5.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayerObjects5[i].getBehavior("FireBullet").Fire((gdjs.Level_321Code.GDPlayerObjects5[i].getPointX("")), (gdjs.Level_321Code.GDPlayerObjects5[i].getPointY("")), gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBulletObjects5Objects, gdjs.evtTools.common.angleBetweenPositions((gdjs.Level_321Code.GDPlayerObjects5[i].getCenterXInScene()), (gdjs.Level_321Code.GDPlayerObjects5[i].getCenterYInScene()), gdjs.evtTools.input.getMouseX(runtimeScene, "", 0), gdjs.evtTools.input.getMouseY(runtimeScene, "", 0)) + gdjs.randomFloatInRange(-(20), 20), (gdjs.RuntimeObject.getVariableNumber(((gdjs.Level_321Code.GDShotgunObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Level_321Code.GDShotgunObjects5[0].getVariables()).getFromIndex(1))), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Level_321Code.GDBulletObjects5.length ;i < len;++i) {
    gdjs.Level_321Code.GDBulletObjects5[i].returnVariable(gdjs.Level_321Code.GDBulletObjects5[i].getVariables().getFromIndex(0)).setNumber((gdjs.RuntimeObject.getVariableNumber(((gdjs.Level_321Code.GDShotgunObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Level_321Code.GDShotgunObjects5[0].getVariables()).getFromIndex(0))));
}
}}
}

}


{

gdjs.copyArray(gdjs.Level_321Code.GDPlayerObjects3, gdjs.Level_321Code.GDPlayerObjects4);


gdjs.Level_321Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level_321Code.GDPlayerObjects4.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDPlayerObjects4[i].getTimerElapsedTimeInSecondsOrNaN("Ammo") > 0.5 ) {
        gdjs.Level_321Code.condition0IsTrue_0.val = true;
        gdjs.Level_321Code.GDPlayerObjects4[k] = gdjs.Level_321Code.GDPlayerObjects4[i];
        ++k;
    }
}
gdjs.Level_321Code.GDPlayerObjects4.length = k;}if (gdjs.Level_321Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level_321Code.GDPlayerObjects4 */
gdjs.copyArray(gdjs.Level_321Code.GDShotgunObjects3, gdjs.Level_321Code.GDShotgunObjects4);

{for(var i = 0, len = gdjs.Level_321Code.GDShotgunObjects4.length ;i < len;++i) {
    gdjs.Level_321Code.GDShotgunObjects4[i].returnVariable(gdjs.Level_321Code.GDShotgunObjects4[i].getVariables().getFromIndex(2)).sub(1);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayerObjects4[i].resetTimer("Ammo");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Zambambo"), gdjs.Level_321Code.GDZambamboObjects3);

for(gdjs.Level_321Code.forEachIndex4 = 0;gdjs.Level_321Code.forEachIndex4 < gdjs.Level_321Code.GDZambamboObjects3.length;++gdjs.Level_321Code.forEachIndex4) {
gdjs.copyArray(gdjs.Level_321Code.GDPlayerObjects3, gdjs.Level_321Code.GDPlayerObjects4);

gdjs.copyArray(gdjs.Level_321Code.GDShotgunObjects3, gdjs.Level_321Code.GDShotgunObjects4);

gdjs.Level_321Code.GDZambamboObjects4.length = 0;


gdjs.Level_321Code.forEachTemporary4 = gdjs.Level_321Code.GDZambamboObjects3[gdjs.Level_321Code.forEachIndex4];
gdjs.Level_321Code.GDZambamboObjects4.push(gdjs.Level_321Code.forEachTemporary4);
gdjs.Level_321Code.condition0IsTrue_0.val = false;
{
gdjs.Level_321Code.condition0IsTrue_0.val = gdjs.evtTools.object.raycastObject(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects4Objects, (( gdjs.Level_321Code.GDZambamboObjects4.length === 0 ) ? 0 :gdjs.Level_321Code.GDZambamboObjects4[0].getCenterXInScene()), (( gdjs.Level_321Code.GDZambamboObjects4.length === 0 ) ? 0 :gdjs.Level_321Code.GDZambamboObjects4[0].getCenterYInScene()), (( gdjs.Level_321Code.GDZambamboObjects4.length === 0 ) ? 0 :gdjs.Level_321Code.GDZambamboObjects4[0].getAngleToObject((gdjs.Level_321Code.GDPlayerObjects4.length !== 0 ? gdjs.Level_321Code.GDPlayerObjects4[0] : null))), (gdjs.RuntimeObject.getVariableNumber(((gdjs.Level_321Code.GDShotgunObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Level_321Code.GDShotgunObjects4[0].getVariables()).getFromIndex(3))), runtimeScene.getVariables().get("IntersectionX"), runtimeScene.getVariables().get("IntersectionY"), false);
}if (gdjs.Level_321Code.condition0IsTrue_0.val) {

{ //Subevents: 
gdjs.Level_321Code.eventsList25(runtimeScene);} //Subevents end.
}
}

}


};gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBulletObjects3Objects = Hashtable.newFrom({"Bullet": gdjs.Level_321Code.GDBulletObjects3});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects4Objects = Hashtable.newFrom({"Player": gdjs.Level_321Code.GDPlayerObjects4});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects5Objects = Hashtable.newFrom({"Player": gdjs.Level_321Code.GDPlayerObjects5});gdjs.Level_321Code.eventsList27 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Level_321Code.GDPlayerObjects4, gdjs.Level_321Code.GDPlayerObjects5);


gdjs.Level_321Code.condition0IsTrue_0.val = false;
{
gdjs.Level_321Code.condition0IsTrue_0.val = gdjs.evtTools.object.pickedObjectsCount(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects5Objects) > 0;
}if (gdjs.Level_321Code.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.Level_321Code.GDZambamboObjects4, gdjs.Level_321Code.GDZambamboObjects5);

{for(var i = 0, len = gdjs.Level_321Code.GDZambamboObjects5.length ;i < len;++i) {
    gdjs.Level_321Code.GDZambamboObjects5[i].returnVariable(gdjs.Level_321Code.GDZambamboObjects5[i].getVariables().getFromIndex(0)).setNumber(1);
}
}}

}


};gdjs.Level_321Code.eventsList28 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Level_321Code.GDPlayerObjects3, gdjs.Level_321Code.GDPlayerObjects4);


gdjs.Level_321Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level_321Code.GDPlayerObjects4.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDPlayerObjects4[i].getTimerElapsedTimeInSecondsOrNaN("Ammo") > 0.5 ) {
        gdjs.Level_321Code.condition0IsTrue_0.val = true;
        gdjs.Level_321Code.GDPlayerObjects4[k] = gdjs.Level_321Code.GDPlayerObjects4[i];
        ++k;
    }
}
gdjs.Level_321Code.GDPlayerObjects4.length = k;}if (gdjs.Level_321Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level_321Code.GDPlayerObjects4 */
gdjs.copyArray(gdjs.Level_321Code.GDRifleObjects3, gdjs.Level_321Code.GDRifleObjects4);

{for(var i = 0, len = gdjs.Level_321Code.GDRifleObjects4.length ;i < len;++i) {
    gdjs.Level_321Code.GDRifleObjects4[i].returnVariable(gdjs.Level_321Code.GDRifleObjects4[i].getVariables().getFromIndex(2)).sub(1);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayerObjects4[i].resetTimer("Ammo");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Zambambo"), gdjs.Level_321Code.GDZambamboObjects3);

for(gdjs.Level_321Code.forEachIndex4 = 0;gdjs.Level_321Code.forEachIndex4 < gdjs.Level_321Code.GDZambamboObjects3.length;++gdjs.Level_321Code.forEachIndex4) {
gdjs.copyArray(gdjs.Level_321Code.GDPlayerObjects3, gdjs.Level_321Code.GDPlayerObjects4);

gdjs.copyArray(gdjs.Level_321Code.GDRifleObjects3, gdjs.Level_321Code.GDRifleObjects4);

gdjs.Level_321Code.GDZambamboObjects4.length = 0;


gdjs.Level_321Code.forEachTemporary4 = gdjs.Level_321Code.GDZambamboObjects3[gdjs.Level_321Code.forEachIndex4];
gdjs.Level_321Code.GDZambamboObjects4.push(gdjs.Level_321Code.forEachTemporary4);
gdjs.Level_321Code.condition0IsTrue_0.val = false;
{
gdjs.Level_321Code.condition0IsTrue_0.val = gdjs.evtTools.object.raycastObject(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects4Objects, (( gdjs.Level_321Code.GDZambamboObjects4.length === 0 ) ? 0 :gdjs.Level_321Code.GDZambamboObjects4[0].getCenterXInScene()), (( gdjs.Level_321Code.GDZambamboObjects4.length === 0 ) ? 0 :gdjs.Level_321Code.GDZambamboObjects4[0].getCenterYInScene()), (( gdjs.Level_321Code.GDZambamboObjects4.length === 0 ) ? 0 :gdjs.Level_321Code.GDZambamboObjects4[0].getAngleToObject((gdjs.Level_321Code.GDPlayerObjects4.length !== 0 ? gdjs.Level_321Code.GDPlayerObjects4[0] : null))), (gdjs.RuntimeObject.getVariableNumber(((gdjs.Level_321Code.GDRifleObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Level_321Code.GDRifleObjects4[0].getVariables()).getFromIndex(3))), runtimeScene.getVariables().get("IntersectionX"), runtimeScene.getVariables().get("IntersectionY"), false);
}if (gdjs.Level_321Code.condition0IsTrue_0.val) {

{ //Subevents: 
gdjs.Level_321Code.eventsList27(runtimeScene);} //Subevents end.
}
}

}


};gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBulletObjects2Objects = Hashtable.newFrom({"Bullet": gdjs.Level_321Code.GDBulletObjects2});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Level_321Code.GDPlayerObjects3});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects4Objects = Hashtable.newFrom({"Player": gdjs.Level_321Code.GDPlayerObjects4});gdjs.Level_321Code.eventsList29 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Level_321Code.GDPlayerObjects3, gdjs.Level_321Code.GDPlayerObjects4);


gdjs.Level_321Code.condition0IsTrue_0.val = false;
{
gdjs.Level_321Code.condition0IsTrue_0.val = gdjs.evtTools.object.pickedObjectsCount(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects4Objects) > 0;
}if (gdjs.Level_321Code.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.Level_321Code.GDZambamboObjects3, gdjs.Level_321Code.GDZambamboObjects4);

{for(var i = 0, len = gdjs.Level_321Code.GDZambamboObjects4.length ;i < len;++i) {
    gdjs.Level_321Code.GDZambamboObjects4[i].returnVariable(gdjs.Level_321Code.GDZambamboObjects4[i].getVariables().getFromIndex(0)).setNumber(1);
}
}}

}


};gdjs.Level_321Code.eventsList30 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Level_321Code.GDPlayerObjects2, gdjs.Level_321Code.GDPlayerObjects3);


gdjs.Level_321Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level_321Code.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDPlayerObjects3[i].getTimerElapsedTimeInSecondsOrNaN("Ammo") > 0.5 ) {
        gdjs.Level_321Code.condition0IsTrue_0.val = true;
        gdjs.Level_321Code.GDPlayerObjects3[k] = gdjs.Level_321Code.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Level_321Code.GDPlayerObjects3.length = k;}if (gdjs.Level_321Code.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.Level_321Code.GDAssaultObjects2, gdjs.Level_321Code.GDAssaultObjects3);

/* Reuse gdjs.Level_321Code.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.Level_321Code.GDAssaultObjects3.length ;i < len;++i) {
    gdjs.Level_321Code.GDAssaultObjects3[i].returnVariable(gdjs.Level_321Code.GDAssaultObjects3[i].getVariables().getFromIndex(2)).sub(1);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayerObjects3[i].resetTimer("Ammo");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Zambambo"), gdjs.Level_321Code.GDZambamboObjects2);

for(gdjs.Level_321Code.forEachIndex3 = 0;gdjs.Level_321Code.forEachIndex3 < gdjs.Level_321Code.GDZambamboObjects2.length;++gdjs.Level_321Code.forEachIndex3) {
gdjs.copyArray(gdjs.Level_321Code.GDAssaultObjects2, gdjs.Level_321Code.GDAssaultObjects3);

gdjs.copyArray(gdjs.Level_321Code.GDPlayerObjects2, gdjs.Level_321Code.GDPlayerObjects3);

gdjs.Level_321Code.GDZambamboObjects3.length = 0;


gdjs.Level_321Code.forEachTemporary3 = gdjs.Level_321Code.GDZambamboObjects2[gdjs.Level_321Code.forEachIndex3];
gdjs.Level_321Code.GDZambamboObjects3.push(gdjs.Level_321Code.forEachTemporary3);
gdjs.Level_321Code.condition0IsTrue_0.val = false;
{
gdjs.Level_321Code.condition0IsTrue_0.val = gdjs.evtTools.object.raycastObject(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects3Objects, (( gdjs.Level_321Code.GDZambamboObjects3.length === 0 ) ? 0 :gdjs.Level_321Code.GDZambamboObjects3[0].getCenterXInScene()), (( gdjs.Level_321Code.GDZambamboObjects3.length === 0 ) ? 0 :gdjs.Level_321Code.GDZambamboObjects3[0].getCenterYInScene()), (( gdjs.Level_321Code.GDZambamboObjects3.length === 0 ) ? 0 :gdjs.Level_321Code.GDZambamboObjects3[0].getAngleToObject((gdjs.Level_321Code.GDPlayerObjects3.length !== 0 ? gdjs.Level_321Code.GDPlayerObjects3[0] : null))), (gdjs.RuntimeObject.getVariableNumber(((gdjs.Level_321Code.GDAssaultObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Level_321Code.GDAssaultObjects3[0].getVariables()).getFromIndex(3))), runtimeScene.getVariables().get("IntersectionX"), runtimeScene.getVariables().get("IntersectionY"), false);
}if (gdjs.Level_321Code.condition0IsTrue_0.val) {

{ //Subevents: 
gdjs.Level_321Code.eventsList29(runtimeScene);} //Subevents end.
}
}

}


};gdjs.Level_321Code.eventsList31 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Pistol"), gdjs.Level_321Code.GDPistolObjects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects3);

gdjs.Level_321Code.condition0IsTrue_0.val = false;
gdjs.Level_321Code.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level_321Code.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDPlayerObjects3[i].getVariableString(gdjs.Level_321Code.GDPlayerObjects3[i].getVariables().getFromIndex(2)) == "Pistol" ) {
        gdjs.Level_321Code.condition0IsTrue_0.val = true;
        gdjs.Level_321Code.GDPlayerObjects3[k] = gdjs.Level_321Code.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Level_321Code.GDPlayerObjects3.length = k;}if ( gdjs.Level_321Code.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level_321Code.GDPistolObjects3.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDPistolObjects3[i].getVariableNumber(gdjs.Level_321Code.GDPistolObjects3[i].getVariables().getFromIndex(2)) > 0 ) {
        gdjs.Level_321Code.condition1IsTrue_0.val = true;
        gdjs.Level_321Code.GDPistolObjects3[k] = gdjs.Level_321Code.GDPistolObjects3[i];
        ++k;
    }
}
gdjs.Level_321Code.GDPistolObjects3.length = k;}}
if (gdjs.Level_321Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.Level_321Code.GDBulletObjects3);
/* Reuse gdjs.Level_321Code.GDPistolObjects3 */
/* Reuse gdjs.Level_321Code.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.Level_321Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayerObjects3[i].getBehavior("FireBullet").Fire((gdjs.Level_321Code.GDPlayerObjects3[i].getPointX("")), (gdjs.Level_321Code.GDPlayerObjects3[i].getPointY("")), gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBulletObjects3Objects, gdjs.evtTools.common.angleBetweenPositions((gdjs.Level_321Code.GDPlayerObjects3[i].getCenterXInScene()), (gdjs.Level_321Code.GDPlayerObjects3[i].getCenterYInScene()), gdjs.evtTools.input.getMouseX(runtimeScene, "", 0), gdjs.evtTools.input.getMouseY(runtimeScene, "", 0)), (gdjs.RuntimeObject.getVariableNumber(((gdjs.Level_321Code.GDPistolObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Level_321Code.GDPistolObjects3[0].getVariables()).getFromIndex(1))), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Level_321Code.GDBulletObjects3.length ;i < len;++i) {
    gdjs.Level_321Code.GDBulletObjects3[i].returnVariable(gdjs.Level_321Code.GDBulletObjects3[i].getVariables().getFromIndex(0)).setNumber((gdjs.RuntimeObject.getVariableNumber(((gdjs.Level_321Code.GDPistolObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Level_321Code.GDPistolObjects3[0].getVariables()).getFromIndex(0))));
}
}
{ //Subevents
gdjs.Level_321Code.eventsList23(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects3);
gdjs.copyArray(runtimeScene.getObjects("Shotgun"), gdjs.Level_321Code.GDShotgunObjects3);

gdjs.Level_321Code.condition0IsTrue_0.val = false;
gdjs.Level_321Code.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level_321Code.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDPlayerObjects3[i].getVariableString(gdjs.Level_321Code.GDPlayerObjects3[i].getVariables().getFromIndex(2)) == "Shotgun" ) {
        gdjs.Level_321Code.condition0IsTrue_0.val = true;
        gdjs.Level_321Code.GDPlayerObjects3[k] = gdjs.Level_321Code.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Level_321Code.GDPlayerObjects3.length = k;}if ( gdjs.Level_321Code.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level_321Code.GDShotgunObjects3.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDShotgunObjects3[i].getVariableNumber(gdjs.Level_321Code.GDShotgunObjects3[i].getVariables().getFromIndex(2)) > 0 ) {
        gdjs.Level_321Code.condition1IsTrue_0.val = true;
        gdjs.Level_321Code.GDShotgunObjects3[k] = gdjs.Level_321Code.GDShotgunObjects3[i];
        ++k;
    }
}
gdjs.Level_321Code.GDShotgunObjects3.length = k;}}
if (gdjs.Level_321Code.condition1IsTrue_0.val) {

{ //Subevents
gdjs.Level_321Code.eventsList26(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects3);
gdjs.copyArray(runtimeScene.getObjects("Rifle"), gdjs.Level_321Code.GDRifleObjects3);

gdjs.Level_321Code.condition0IsTrue_0.val = false;
gdjs.Level_321Code.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level_321Code.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDPlayerObjects3[i].getVariableString(gdjs.Level_321Code.GDPlayerObjects3[i].getVariables().getFromIndex(2)) == "Sniper" ) {
        gdjs.Level_321Code.condition0IsTrue_0.val = true;
        gdjs.Level_321Code.GDPlayerObjects3[k] = gdjs.Level_321Code.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Level_321Code.GDPlayerObjects3.length = k;}if ( gdjs.Level_321Code.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level_321Code.GDRifleObjects3.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDRifleObjects3[i].getVariableNumber(gdjs.Level_321Code.GDRifleObjects3[i].getVariables().getFromIndex(2)) > 0 ) {
        gdjs.Level_321Code.condition1IsTrue_0.val = true;
        gdjs.Level_321Code.GDRifleObjects3[k] = gdjs.Level_321Code.GDRifleObjects3[i];
        ++k;
    }
}
gdjs.Level_321Code.GDRifleObjects3.length = k;}}
if (gdjs.Level_321Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.Level_321Code.GDBulletObjects3);
/* Reuse gdjs.Level_321Code.GDPlayerObjects3 */
/* Reuse gdjs.Level_321Code.GDRifleObjects3 */
{for(var i = 0, len = gdjs.Level_321Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayerObjects3[i].getBehavior("FireBullet").Fire((gdjs.Level_321Code.GDPlayerObjects3[i].getPointX("")), (gdjs.Level_321Code.GDPlayerObjects3[i].getPointY("")), gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBulletObjects3Objects, gdjs.evtTools.common.angleBetweenPositions((gdjs.Level_321Code.GDPlayerObjects3[i].getCenterXInScene()), (gdjs.Level_321Code.GDPlayerObjects3[i].getCenterYInScene()), gdjs.evtTools.input.getMouseX(runtimeScene, "", 0), gdjs.evtTools.input.getMouseY(runtimeScene, "", 0)), (gdjs.RuntimeObject.getVariableNumber(((gdjs.Level_321Code.GDRifleObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Level_321Code.GDRifleObjects3[0].getVariables()).getFromIndex(1))), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Level_321Code.GDBulletObjects3.length ;i < len;++i) {
    gdjs.Level_321Code.GDBulletObjects3[i].returnVariable(gdjs.Level_321Code.GDBulletObjects3[i].getVariables().getFromIndex(0)).setNumber((gdjs.RuntimeObject.getVariableNumber(((gdjs.Level_321Code.GDRifleObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Level_321Code.GDRifleObjects3[0].getVariables()).getFromIndex(0))));
}
}
{ //Subevents
gdjs.Level_321Code.eventsList28(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Assault"), gdjs.Level_321Code.GDAssaultObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);

gdjs.Level_321Code.condition0IsTrue_0.val = false;
gdjs.Level_321Code.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level_321Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDPlayerObjects2[i].getVariableString(gdjs.Level_321Code.GDPlayerObjects2[i].getVariables().getFromIndex(2)) == "Assault" ) {
        gdjs.Level_321Code.condition0IsTrue_0.val = true;
        gdjs.Level_321Code.GDPlayerObjects2[k] = gdjs.Level_321Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDPlayerObjects2.length = k;}if ( gdjs.Level_321Code.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level_321Code.GDAssaultObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDAssaultObjects2[i].getVariableNumber(gdjs.Level_321Code.GDAssaultObjects2[i].getVariables().getFromIndex(2)) > 0 ) {
        gdjs.Level_321Code.condition1IsTrue_0.val = true;
        gdjs.Level_321Code.GDAssaultObjects2[k] = gdjs.Level_321Code.GDAssaultObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDAssaultObjects2.length = k;}}
if (gdjs.Level_321Code.condition1IsTrue_0.val) {
/* Reuse gdjs.Level_321Code.GDAssaultObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.Level_321Code.GDBulletObjects2);
/* Reuse gdjs.Level_321Code.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.Level_321Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayerObjects2[i].getBehavior("FireBullet").Fire((gdjs.Level_321Code.GDPlayerObjects2[i].getPointX("")), (gdjs.Level_321Code.GDPlayerObjects2[i].getPointY("")), gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBulletObjects2Objects, gdjs.evtTools.common.angleBetweenPositions((gdjs.Level_321Code.GDPlayerObjects2[i].getCenterXInScene()), (gdjs.Level_321Code.GDPlayerObjects2[i].getCenterYInScene()), gdjs.evtTools.input.getMouseX(runtimeScene, "", 0), gdjs.evtTools.input.getMouseY(runtimeScene, "", 0)), (gdjs.RuntimeObject.getVariableNumber(((gdjs.Level_321Code.GDAssaultObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Level_321Code.GDAssaultObjects2[0].getVariables()).getFromIndex(1))), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Level_321Code.GDBulletObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDBulletObjects2[i].returnVariable(gdjs.Level_321Code.GDBulletObjects2[i].getVariables().getFromIndex(0)).setNumber((gdjs.RuntimeObject.getVariableNumber(((gdjs.Level_321Code.GDAssaultObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Level_321Code.GDAssaultObjects2[0].getVariables()).getFromIndex(0))));
}
}
{ //Subevents
gdjs.Level_321Code.eventsList30(runtimeScene);} //End of subevents
}

}


};gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBulletObjects2Objects = Hashtable.newFrom({"Bullet": gdjs.Level_321Code.GDBulletObjects2});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBarricadeObjects2Objects = Hashtable.newFrom({"Barricade": gdjs.Level_321Code.GDBarricadeObjects2});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBulletObjects2Objects = Hashtable.newFrom({"Bullet": gdjs.Level_321Code.GDBulletObjects2});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDWallObjects2Objects = Hashtable.newFrom({"Wall": gdjs.Level_321Code.GDWallObjects2});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBulletObjects1Objects = Hashtable.newFrom({"Bullet": gdjs.Level_321Code.GDBulletObjects1});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDZambamboObjects1Objects = Hashtable.newFrom({"Zambambo": gdjs.Level_321Code.GDZambamboObjects1});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDZambamboHealthObjects1Objects = Hashtable.newFrom({"ZambamboHealth": gdjs.Level_321Code.GDZambamboHealthObjects1});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDZambamboHealthBackObjects1Objects = Hashtable.newFrom({"ZambamboHealthBack": gdjs.Level_321Code.GDZambamboHealthBackObjects1});gdjs.Level_321Code.eventsList32 = function(runtimeScene) {

{

/* Reuse gdjs.Level_321Code.GDZambamboObjects1 */
gdjs.copyArray(runtimeScene.getObjects("ZambamboHealth"), gdjs.Level_321Code.GDZambamboHealthObjects1);
gdjs.copyArray(runtimeScene.getObjects("ZambamboHealthBack"), gdjs.Level_321Code.GDZambamboHealthBackObjects1);

gdjs.Level_321Code.condition0IsTrue_0.val = false;
gdjs.Level_321Code.condition1IsTrue_0.val = false;
{
gdjs.Level_321Code.condition0IsTrue_0.val = gdjs.evtTools.linkedObjects.pickObjectsLinkedTo(runtimeScene, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDZambamboHealthObjects1Objects, (gdjs.Level_321Code.GDZambamboObjects1.length !== 0 ? gdjs.Level_321Code.GDZambamboObjects1[0] : null), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}if ( gdjs.Level_321Code.condition0IsTrue_0.val ) {
{
gdjs.Level_321Code.condition1IsTrue_0.val = gdjs.evtTools.linkedObjects.pickObjectsLinkedTo(runtimeScene, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDZambamboHealthBackObjects1Objects, (gdjs.Level_321Code.GDZambamboObjects1.length !== 0 ? gdjs.Level_321Code.GDZambamboObjects1[0] : null), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}
if (gdjs.Level_321Code.condition1IsTrue_0.val) {
/* Reuse gdjs.Level_321Code.GDBulletObjects1 */
/* Reuse gdjs.Level_321Code.GDZambamboObjects1 */
/* Reuse gdjs.Level_321Code.GDZambamboHealthObjects1 */
/* Reuse gdjs.Level_321Code.GDZambamboHealthBackObjects1 */
{for(var i = 0, len = gdjs.Level_321Code.GDZambamboHealthObjects1.length ;i < len;++i) {
    gdjs.Level_321Code.GDZambamboHealthObjects1[i].setWidth((((gdjs.RuntimeObject.getVariableNumber(((gdjs.Level_321Code.GDZambamboObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Level_321Code.GDZambamboObjects1[0].getVariables()).getFromIndex(3))) - (gdjs.RuntimeObject.getVariableNumber(((gdjs.Level_321Code.GDBulletObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Level_321Code.GDBulletObjects1[0].getVariables()).getFromIndex(0)))) / (gdjs.RuntimeObject.getVariableNumber(((gdjs.Level_321Code.GDZambamboObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Level_321Code.GDZambamboObjects1[0].getVariables()).getFromIndex(2)))) * (( gdjs.Level_321Code.GDZambamboHealthBackObjects1.length === 0 ) ? 0 :gdjs.Level_321Code.GDZambamboHealthBackObjects1[0].getWidth()));
}
}{for(var i = 0, len = gdjs.Level_321Code.GDZambamboObjects1.length ;i < len;++i) {
    gdjs.Level_321Code.GDZambamboObjects1[i].returnVariable(gdjs.Level_321Code.GDZambamboObjects1[i].getVariables().getFromIndex(3)).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.Level_321Code.GDBulletObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Level_321Code.GDBulletObjects1[0].getVariables()).getFromIndex(0))));
}
}}

}


};gdjs.Level_321Code.eventsList33 = function(runtimeScene) {

{



}


{



}


{


gdjs.Level_321Code.condition0IsTrue_0.val = false;
{
gdjs.Level_321Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if (gdjs.Level_321Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Level_321Code.eventsList31(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Barricade"), gdjs.Level_321Code.GDBarricadeObjects2);
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.Level_321Code.GDBulletObjects2);

gdjs.Level_321Code.condition0IsTrue_0.val = false;
{
gdjs.Level_321Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBulletObjects2Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBarricadeObjects2Objects, false, runtimeScene, false);
}if (gdjs.Level_321Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level_321Code.GDBarricadeObjects2 */
/* Reuse gdjs.Level_321Code.GDBulletObjects2 */
{for(var i = 0, len = gdjs.Level_321Code.GDBarricadeObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDBarricadeObjects2[i].getBehavior("Health").Hit((gdjs.RuntimeObject.getVariableNumber(((gdjs.Level_321Code.GDBulletObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Level_321Code.GDBulletObjects2[0].getVariables()).getFromIndex(0))), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Level_321Code.GDBulletObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDBulletObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.Level_321Code.GDBulletObjects2);
gdjs.copyArray(runtimeScene.getObjects("Wall"), gdjs.Level_321Code.GDWallObjects2);

gdjs.Level_321Code.condition0IsTrue_0.val = false;
{
gdjs.Level_321Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBulletObjects2Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDWallObjects2Objects, false, runtimeScene, false);
}if (gdjs.Level_321Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level_321Code.GDBulletObjects2 */
{for(var i = 0, len = gdjs.Level_321Code.GDBulletObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDBulletObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.Level_321Code.GDBulletObjects1);
gdjs.copyArray(runtimeScene.getObjects("Zambambo"), gdjs.Level_321Code.GDZambamboObjects1);

gdjs.Level_321Code.condition0IsTrue_0.val = false;
{
gdjs.Level_321Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBulletObjects1Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDZambamboObjects1Objects, false, runtimeScene, false);
}if (gdjs.Level_321Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level_321Code.GDBulletObjects1 */
/* Reuse gdjs.Level_321Code.GDZambamboObjects1 */
{for(var i = 0, len = gdjs.Level_321Code.GDBulletObjects1.length ;i < len;++i) {
    gdjs.Level_321Code.GDBulletObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDZambamboObjects1.length ;i < len;++i) {
    gdjs.Level_321Code.GDZambamboObjects1[i].getBehavior("Health").Hit((gdjs.RuntimeObject.getVariableNumber(((gdjs.Level_321Code.GDBulletObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Level_321Code.GDBulletObjects1[0].getVariables()).getFromIndex(0))), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.Level_321Code.eventsList32(runtimeScene);} //End of subevents
}

}


};gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level_321Code.GDPlayerObjects2});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDMouseObjectObjects2Objects = Hashtable.newFrom({"MouseObject": gdjs.Level_321Code.GDMouseObjectObjects2});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBarricadeGhostObjects3Objects = Hashtable.newFrom({"BarricadeGhost": gdjs.Level_321Code.GDBarricadeGhostObjects3});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBarricadeObjects3Objects = Hashtable.newFrom({"Barricade": gdjs.Level_321Code.GDBarricadeObjects3});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBarricadeGhostObjects3Objects = Hashtable.newFrom({"BarricadeGhost": gdjs.Level_321Code.GDBarricadeGhostObjects3});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBarricadeShortObjects3Objects = Hashtable.newFrom({"BarricadeShort": gdjs.Level_321Code.GDBarricadeShortObjects3});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBarricadeGhostObjects3Objects = Hashtable.newFrom({"BarricadeGhost": gdjs.Level_321Code.GDBarricadeGhostObjects3});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBarricadeSpikesObjects3Objects = Hashtable.newFrom({"BarricadeSpikes": gdjs.Level_321Code.GDBarricadeSpikesObjects3});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBarricadeGhostObjects3Objects = Hashtable.newFrom({"BarricadeGhost": gdjs.Level_321Code.GDBarricadeGhostObjects3});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDWallObjects3Objects = Hashtable.newFrom({"Wall": gdjs.Level_321Code.GDWallObjects3});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBarricadeObjects3Objects = Hashtable.newFrom({"Barricade": gdjs.Level_321Code.GDBarricadeObjects3});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBarricadeShortGhostObjects3Objects = Hashtable.newFrom({"BarricadeShortGhost": gdjs.Level_321Code.GDBarricadeShortGhostObjects3});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBarricadeObjects3Objects = Hashtable.newFrom({"Barricade": gdjs.Level_321Code.GDBarricadeObjects3});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBarricadeShortGhostObjects3Objects = Hashtable.newFrom({"BarricadeShortGhost": gdjs.Level_321Code.GDBarricadeShortGhostObjects3});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBarricadeShortObjects3Objects = Hashtable.newFrom({"BarricadeShort": gdjs.Level_321Code.GDBarricadeShortObjects3});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBarricadeShortGhostObjects3Objects = Hashtable.newFrom({"BarricadeShortGhost": gdjs.Level_321Code.GDBarricadeShortGhostObjects3});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBarricadeSpikesObjects3Objects = Hashtable.newFrom({"BarricadeSpikes": gdjs.Level_321Code.GDBarricadeSpikesObjects3});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBarricadeShortGhostObjects3Objects = Hashtable.newFrom({"BarricadeShortGhost": gdjs.Level_321Code.GDBarricadeShortGhostObjects3});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDWallObjects3Objects = Hashtable.newFrom({"Wall": gdjs.Level_321Code.GDWallObjects3});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBarricadeShortObjects3Objects = Hashtable.newFrom({"BarricadeShort": gdjs.Level_321Code.GDBarricadeShortObjects3});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBarricadeSpikesGhostObjects2Objects = Hashtable.newFrom({"BarricadeSpikesGhost": gdjs.Level_321Code.GDBarricadeSpikesGhostObjects2});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBarricadeObjects2Objects = Hashtable.newFrom({"Barricade": gdjs.Level_321Code.GDBarricadeObjects2});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBarricadeSpikesGhostObjects2Objects = Hashtable.newFrom({"BarricadeSpikesGhost": gdjs.Level_321Code.GDBarricadeSpikesGhostObjects2});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBarricadeShortObjects2Objects = Hashtable.newFrom({"BarricadeShort": gdjs.Level_321Code.GDBarricadeShortObjects2});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBarricadeSpikesGhostObjects2Objects = Hashtable.newFrom({"BarricadeSpikesGhost": gdjs.Level_321Code.GDBarricadeSpikesGhostObjects2});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBarricadeSpikesObjects2Objects = Hashtable.newFrom({"BarricadeSpikes": gdjs.Level_321Code.GDBarricadeSpikesObjects2});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBarricadeSpikesGhostObjects2Objects = Hashtable.newFrom({"BarricadeSpikesGhost": gdjs.Level_321Code.GDBarricadeSpikesGhostObjects2});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDWallObjects2Objects = Hashtable.newFrom({"Wall": gdjs.Level_321Code.GDWallObjects2});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBarricadeSpikesObjects2Objects = Hashtable.newFrom({"BarricadeSpikes": gdjs.Level_321Code.GDBarricadeSpikesObjects2});gdjs.Level_321Code.eventsList34 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Barricade"), gdjs.Level_321Code.GDBarricadeObjects3);
gdjs.copyArray(runtimeScene.getObjects("BarricadeGhost"), gdjs.Level_321Code.GDBarricadeGhostObjects3);
gdjs.copyArray(runtimeScene.getObjects("BarricadeShort"), gdjs.Level_321Code.GDBarricadeShortObjects3);
gdjs.copyArray(runtimeScene.getObjects("BarricadeSpikes"), gdjs.Level_321Code.GDBarricadeSpikesObjects3);
gdjs.copyArray(gdjs.Level_321Code.GDPlayerObjects2, gdjs.Level_321Code.GDPlayerObjects3);

gdjs.copyArray(runtimeScene.getObjects("Wall"), gdjs.Level_321Code.GDWallObjects3);

gdjs.Level_321Code.condition0IsTrue_0.val = false;
gdjs.Level_321Code.condition1IsTrue_0.val = false;
gdjs.Level_321Code.condition2IsTrue_0.val = false;
gdjs.Level_321Code.condition3IsTrue_0.val = false;
gdjs.Level_321Code.condition4IsTrue_0.val = false;
gdjs.Level_321Code.condition5IsTrue_0.val = false;
gdjs.Level_321Code.condition6IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level_321Code.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDPlayerObjects3[i].getVariableString(gdjs.Level_321Code.GDPlayerObjects3[i].getVariables().getFromIndex(2)) == "Barricade" ) {
        gdjs.Level_321Code.condition0IsTrue_0.val = true;
        gdjs.Level_321Code.GDPlayerObjects3[k] = gdjs.Level_321Code.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Level_321Code.GDPlayerObjects3.length = k;}if ( gdjs.Level_321Code.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level_321Code.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDPlayerObjects3[i].getVariableNumber(gdjs.Level_321Code.GDPlayerObjects3[i].getVariables().getFromIndex(1)) >= (gdjs.RuntimeObject.getVariableNumber(((gdjs.Level_321Code.GDBarricadeObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Level_321Code.GDBarricadeObjects3[0].getVariables()).getFromIndex(1))) ) {
        gdjs.Level_321Code.condition1IsTrue_0.val = true;
        gdjs.Level_321Code.GDPlayerObjects3[k] = gdjs.Level_321Code.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Level_321Code.GDPlayerObjects3.length = k;}if ( gdjs.Level_321Code.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level_321Code.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDPlayerObjects3[i].getTimerElapsedTimeInSecondsOrNaN("BuildTimer") > 0.5 ) {
        gdjs.Level_321Code.condition2IsTrue_0.val = true;
        gdjs.Level_321Code.GDPlayerObjects3[k] = gdjs.Level_321Code.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Level_321Code.GDPlayerObjects3.length = k;}if ( gdjs.Level_321Code.condition2IsTrue_0.val ) {
{
gdjs.Level_321Code.condition3IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBarricadeGhostObjects3Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBarricadeObjects3Objects, true, runtimeScene, false);
}if ( gdjs.Level_321Code.condition3IsTrue_0.val ) {
{
gdjs.Level_321Code.condition4IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBarricadeGhostObjects3Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBarricadeShortObjects3Objects, true, runtimeScene, false);
}if ( gdjs.Level_321Code.condition4IsTrue_0.val ) {
{
gdjs.Level_321Code.condition5IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBarricadeGhostObjects3Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBarricadeSpikesObjects3Objects, true, runtimeScene, false);
}if ( gdjs.Level_321Code.condition5IsTrue_0.val ) {
{
gdjs.Level_321Code.condition6IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBarricadeGhostObjects3Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDWallObjects3Objects, true, runtimeScene, false);
}}
}
}
}
}
}
if (gdjs.Level_321Code.condition6IsTrue_0.val) {
/* Reuse gdjs.Level_321Code.GDPlayerObjects3 */
/* Reuse gdjs.Level_321Code.GDBarricadeObjects3 */
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBarricadeObjects3Objects, 32 * (Math.round((gdjs.evtTools.input.getMouseX(runtimeScene, "", 0) - 16) / 32)), 32 * (Math.round((gdjs.evtTools.input.getMouseY(runtimeScene, "", 0) - 32) / 32)), "Base Layer");
}{for(var i = 0, len = gdjs.Level_321Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayerObjects3[i].returnVariable(gdjs.Level_321Code.GDPlayerObjects3[i].getVariables().getFromIndex(1)).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.Level_321Code.GDBarricadeObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Level_321Code.GDBarricadeObjects3[0].getVariables()).getFromIndex(1))));
}
}{for(var i = 0, len = gdjs.Level_321Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayerObjects3[i].resetTimer("BuildTimer");
}
}{for(var i = 0, len = gdjs.Level_321Code.GDBarricadeObjects3.length ;i < len;++i) {
    gdjs.Level_321Code.GDBarricadeObjects3[i].setZOrder((gdjs.Level_321Code.GDBarricadeObjects3[i].getCenterYInScene()));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Barricade"), gdjs.Level_321Code.GDBarricadeObjects3);
gdjs.copyArray(runtimeScene.getObjects("BarricadeShort"), gdjs.Level_321Code.GDBarricadeShortObjects3);
gdjs.copyArray(runtimeScene.getObjects("BarricadeShortGhost"), gdjs.Level_321Code.GDBarricadeShortGhostObjects3);
gdjs.copyArray(runtimeScene.getObjects("BarricadeSpikes"), gdjs.Level_321Code.GDBarricadeSpikesObjects3);
gdjs.copyArray(gdjs.Level_321Code.GDPlayerObjects2, gdjs.Level_321Code.GDPlayerObjects3);

gdjs.copyArray(runtimeScene.getObjects("Wall"), gdjs.Level_321Code.GDWallObjects3);

gdjs.Level_321Code.condition0IsTrue_0.val = false;
gdjs.Level_321Code.condition1IsTrue_0.val = false;
gdjs.Level_321Code.condition2IsTrue_0.val = false;
gdjs.Level_321Code.condition3IsTrue_0.val = false;
gdjs.Level_321Code.condition4IsTrue_0.val = false;
gdjs.Level_321Code.condition5IsTrue_0.val = false;
gdjs.Level_321Code.condition6IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level_321Code.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDPlayerObjects3[i].getVariableString(gdjs.Level_321Code.GDPlayerObjects3[i].getVariables().getFromIndex(2)) == "Cover" ) {
        gdjs.Level_321Code.condition0IsTrue_0.val = true;
        gdjs.Level_321Code.GDPlayerObjects3[k] = gdjs.Level_321Code.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Level_321Code.GDPlayerObjects3.length = k;}if ( gdjs.Level_321Code.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level_321Code.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDPlayerObjects3[i].getVariableNumber(gdjs.Level_321Code.GDPlayerObjects3[i].getVariables().getFromIndex(1)) >= (gdjs.RuntimeObject.getVariableNumber(((gdjs.Level_321Code.GDBarricadeShortObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Level_321Code.GDBarricadeShortObjects3[0].getVariables()).getFromIndex(1))) ) {
        gdjs.Level_321Code.condition1IsTrue_0.val = true;
        gdjs.Level_321Code.GDPlayerObjects3[k] = gdjs.Level_321Code.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Level_321Code.GDPlayerObjects3.length = k;}if ( gdjs.Level_321Code.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level_321Code.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDPlayerObjects3[i].getTimerElapsedTimeInSecondsOrNaN("BuildTimer") > 0.5 ) {
        gdjs.Level_321Code.condition2IsTrue_0.val = true;
        gdjs.Level_321Code.GDPlayerObjects3[k] = gdjs.Level_321Code.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Level_321Code.GDPlayerObjects3.length = k;}if ( gdjs.Level_321Code.condition2IsTrue_0.val ) {
{
gdjs.Level_321Code.condition3IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBarricadeShortGhostObjects3Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBarricadeObjects3Objects, true, runtimeScene, false);
}if ( gdjs.Level_321Code.condition3IsTrue_0.val ) {
{
gdjs.Level_321Code.condition4IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBarricadeShortGhostObjects3Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBarricadeShortObjects3Objects, true, runtimeScene, false);
}if ( gdjs.Level_321Code.condition4IsTrue_0.val ) {
{
gdjs.Level_321Code.condition5IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBarricadeShortGhostObjects3Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBarricadeSpikesObjects3Objects, true, runtimeScene, false);
}if ( gdjs.Level_321Code.condition5IsTrue_0.val ) {
{
gdjs.Level_321Code.condition6IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBarricadeShortGhostObjects3Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDWallObjects3Objects, true, runtimeScene, false);
}}
}
}
}
}
}
if (gdjs.Level_321Code.condition6IsTrue_0.val) {
/* Reuse gdjs.Level_321Code.GDPlayerObjects3 */
/* Reuse gdjs.Level_321Code.GDBarricadeShortObjects3 */
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBarricadeShortObjects3Objects, 32 * (Math.round((gdjs.evtTools.input.getMouseX(runtimeScene, "", 0) - 16) / 32)), 32 * (Math.round((gdjs.evtTools.input.getMouseY(runtimeScene, "", 0) - 16) / 32)), "Base Layer");
}{for(var i = 0, len = gdjs.Level_321Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayerObjects3[i].returnVariable(gdjs.Level_321Code.GDPlayerObjects3[i].getVariables().getFromIndex(1)).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.Level_321Code.GDBarricadeShortObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Level_321Code.GDBarricadeShortObjects3[0].getVariables()).getFromIndex(1))));
}
}{for(var i = 0, len = gdjs.Level_321Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayerObjects3[i].resetTimer("BuildTimer");
}
}{for(var i = 0, len = gdjs.Level_321Code.GDBarricadeShortObjects3.length ;i < len;++i) {
    gdjs.Level_321Code.GDBarricadeShortObjects3[i].setZOrder((gdjs.Level_321Code.GDBarricadeShortObjects3[i].getCenterYInScene()));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Barricade"), gdjs.Level_321Code.GDBarricadeObjects2);
gdjs.copyArray(runtimeScene.getObjects("BarricadeShort"), gdjs.Level_321Code.GDBarricadeShortObjects2);
gdjs.copyArray(runtimeScene.getObjects("BarricadeSpikes"), gdjs.Level_321Code.GDBarricadeSpikesObjects2);
gdjs.copyArray(runtimeScene.getObjects("BarricadeSpikesGhost"), gdjs.Level_321Code.GDBarricadeSpikesGhostObjects2);
/* Reuse gdjs.Level_321Code.GDPlayerObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Wall"), gdjs.Level_321Code.GDWallObjects2);

gdjs.Level_321Code.condition0IsTrue_0.val = false;
gdjs.Level_321Code.condition1IsTrue_0.val = false;
gdjs.Level_321Code.condition2IsTrue_0.val = false;
gdjs.Level_321Code.condition3IsTrue_0.val = false;
gdjs.Level_321Code.condition4IsTrue_0.val = false;
gdjs.Level_321Code.condition5IsTrue_0.val = false;
gdjs.Level_321Code.condition6IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level_321Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDPlayerObjects2[i].getVariableString(gdjs.Level_321Code.GDPlayerObjects2[i].getVariables().getFromIndex(2)) == "Spikes" ) {
        gdjs.Level_321Code.condition0IsTrue_0.val = true;
        gdjs.Level_321Code.GDPlayerObjects2[k] = gdjs.Level_321Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDPlayerObjects2.length = k;}if ( gdjs.Level_321Code.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level_321Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDPlayerObjects2[i].getVariableNumber(gdjs.Level_321Code.GDPlayerObjects2[i].getVariables().getFromIndex(1)) >= (gdjs.RuntimeObject.getVariableNumber(((gdjs.Level_321Code.GDBarricadeSpikesObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Level_321Code.GDBarricadeSpikesObjects2[0].getVariables()).getFromIndex(1))) ) {
        gdjs.Level_321Code.condition1IsTrue_0.val = true;
        gdjs.Level_321Code.GDPlayerObjects2[k] = gdjs.Level_321Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDPlayerObjects2.length = k;}if ( gdjs.Level_321Code.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level_321Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDPlayerObjects2[i].getTimerElapsedTimeInSecondsOrNaN("BuildTimer") > 0.5 ) {
        gdjs.Level_321Code.condition2IsTrue_0.val = true;
        gdjs.Level_321Code.GDPlayerObjects2[k] = gdjs.Level_321Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDPlayerObjects2.length = k;}if ( gdjs.Level_321Code.condition2IsTrue_0.val ) {
{
gdjs.Level_321Code.condition3IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBarricadeSpikesGhostObjects2Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBarricadeObjects2Objects, true, runtimeScene, false);
}if ( gdjs.Level_321Code.condition3IsTrue_0.val ) {
{
gdjs.Level_321Code.condition4IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBarricadeSpikesGhostObjects2Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBarricadeShortObjects2Objects, true, runtimeScene, false);
}if ( gdjs.Level_321Code.condition4IsTrue_0.val ) {
{
gdjs.Level_321Code.condition5IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBarricadeSpikesGhostObjects2Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBarricadeSpikesObjects2Objects, true, runtimeScene, false);
}if ( gdjs.Level_321Code.condition5IsTrue_0.val ) {
{
gdjs.Level_321Code.condition6IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBarricadeSpikesGhostObjects2Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDWallObjects2Objects, true, runtimeScene, false);
}}
}
}
}
}
}
if (gdjs.Level_321Code.condition6IsTrue_0.val) {
/* Reuse gdjs.Level_321Code.GDPlayerObjects2 */
/* Reuse gdjs.Level_321Code.GDBarricadeSpikesObjects2 */
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBarricadeSpikesObjects2Objects, 32 * (Math.round((gdjs.evtTools.input.getMouseX(runtimeScene, "", 0) - 16) / 32)), 32 * (Math.round((gdjs.evtTools.input.getMouseY(runtimeScene, "", 0) - 16) / 32)), "Base Layer");
}{for(var i = 0, len = gdjs.Level_321Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayerObjects2[i].returnVariable(gdjs.Level_321Code.GDPlayerObjects2[i].getVariables().getFromIndex(1)).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.Level_321Code.GDBarricadeSpikesObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Level_321Code.GDBarricadeSpikesObjects2[0].getVariables()).getFromIndex(1))));
}
}{for(var i = 0, len = gdjs.Level_321Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayerObjects2[i].resetTimer("BuildTimer");
}
}{for(var i = 0, len = gdjs.Level_321Code.GDBarricadeSpikesObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDBarricadeSpikesObjects2[i].setZOrder((gdjs.Level_321Code.GDBarricadeSpikesObjects2[i].getPointY("")) - 32);
}
}}

}


};gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects1ObjectsGDgdjs_46Level_95321Code_46GDZambamboObjects1Objects = Hashtable.newFrom({"Player": gdjs.Level_321Code.GDPlayerObjects1, "Zambambo": gdjs.Level_321Code.GDZambamboObjects1});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBarricadeSpikesObjects1Objects = Hashtable.newFrom({"BarricadeSpikes": gdjs.Level_321Code.GDBarricadeSpikesObjects1});gdjs.Level_321Code.eventsList35 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("MouseObject"), gdjs.Level_321Code.GDMouseObjectObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);

gdjs.Level_321Code.condition0IsTrue_0.val = false;
gdjs.Level_321Code.condition1IsTrue_0.val = false;
{
gdjs.Level_321Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.Level_321Code.condition0IsTrue_0.val ) {
{
gdjs.Level_321Code.condition1IsTrue_0.val = gdjs.evtTools.object.distanceTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects2Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDMouseObjectObjects2Objects, (gdjs.RuntimeObject.getVariableNumber(((gdjs.Level_321Code.GDPlayerObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Level_321Code.GDPlayerObjects2[0].getVariables()).getFromIndex(3))), false);
}}
if (gdjs.Level_321Code.condition1IsTrue_0.val) {

{ //Subevents
gdjs.Level_321Code.eventsList34(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Barricade"), gdjs.Level_321Code.GDBarricadeObjects2);

gdjs.Level_321Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level_321Code.GDBarricadeObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDBarricadeObjects2[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.Level_321Code.condition0IsTrue_0.val = true;
        gdjs.Level_321Code.GDBarricadeObjects2[k] = gdjs.Level_321Code.GDBarricadeObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDBarricadeObjects2.length = k;}if (gdjs.Level_321Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level_321Code.GDBarricadeObjects2 */
{for(var i = 0, len = gdjs.Level_321Code.GDBarricadeObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDBarricadeObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("BarricadeShort"), gdjs.Level_321Code.GDBarricadeShortObjects2);

gdjs.Level_321Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level_321Code.GDBarricadeShortObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDBarricadeShortObjects2[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.Level_321Code.condition0IsTrue_0.val = true;
        gdjs.Level_321Code.GDBarricadeShortObjects2[k] = gdjs.Level_321Code.GDBarricadeShortObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDBarricadeShortObjects2.length = k;}if (gdjs.Level_321Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level_321Code.GDBarricadeShortObjects2 */
{for(var i = 0, len = gdjs.Level_321Code.GDBarricadeShortObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDBarricadeShortObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("BarricadeSpikes"), gdjs.Level_321Code.GDBarricadeSpikesObjects2);

gdjs.Level_321Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level_321Code.GDBarricadeSpikesObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDBarricadeSpikesObjects2[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.Level_321Code.condition0IsTrue_0.val = true;
        gdjs.Level_321Code.GDBarricadeSpikesObjects2[k] = gdjs.Level_321Code.GDBarricadeSpikesObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDBarricadeSpikesObjects2.length = k;}if (gdjs.Level_321Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level_321Code.GDBarricadeSpikesObjects2 */
{for(var i = 0, len = gdjs.Level_321Code.GDBarricadeSpikesObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDBarricadeSpikesObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Barricade"), gdjs.Level_321Code.GDBarricadeObjects2);

gdjs.Level_321Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level_321Code.GDBarricadeObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDBarricadeObjects2[i].getBehavior("Health").IsJustDamaged((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.Level_321Code.condition0IsTrue_0.val = true;
        gdjs.Level_321Code.GDBarricadeObjects2[k] = gdjs.Level_321Code.GDBarricadeObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDBarricadeObjects2.length = k;}if (gdjs.Level_321Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level_321Code.GDBarricadeObjects2 */
{for(var i = 0, len = gdjs.Level_321Code.GDBarricadeObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDBarricadeObjects2[i].returnVariable(gdjs.Level_321Code.GDBarricadeObjects2[i].getVariables().getFromIndex(0)).add(1);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDBarricadeObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDBarricadeObjects2[i].setAnimationName("BarricadeD" + (gdjs.RuntimeObject.getVariableString(gdjs.Level_321Code.GDBarricadeObjects2[i].getVariables().getFromIndex(0))));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("BarricadeShort"), gdjs.Level_321Code.GDBarricadeShortObjects2);

gdjs.Level_321Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level_321Code.GDBarricadeShortObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDBarricadeShortObjects2[i].getBehavior("Health").IsJustDamaged((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.Level_321Code.condition0IsTrue_0.val = true;
        gdjs.Level_321Code.GDBarricadeShortObjects2[k] = gdjs.Level_321Code.GDBarricadeShortObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDBarricadeShortObjects2.length = k;}if (gdjs.Level_321Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level_321Code.GDBarricadeShortObjects2 */
{for(var i = 0, len = gdjs.Level_321Code.GDBarricadeShortObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDBarricadeShortObjects2[i].returnVariable(gdjs.Level_321Code.GDBarricadeShortObjects2[i].getVariables().getFromIndex(0)).add(1);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDBarricadeShortObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDBarricadeShortObjects2[i].setAnimationName("BarricadeD" + (gdjs.RuntimeObject.getVariableString(gdjs.Level_321Code.GDBarricadeShortObjects2[i].getVariables().getFromIndex(0))));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("BarricadeSpikes"), gdjs.Level_321Code.GDBarricadeSpikesObjects2);

gdjs.Level_321Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level_321Code.GDBarricadeSpikesObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDBarricadeSpikesObjects2[i].getBehavior("Health").IsJustDamaged((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.Level_321Code.condition0IsTrue_0.val = true;
        gdjs.Level_321Code.GDBarricadeSpikesObjects2[k] = gdjs.Level_321Code.GDBarricadeSpikesObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDBarricadeSpikesObjects2.length = k;}if (gdjs.Level_321Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level_321Code.GDBarricadeSpikesObjects2 */
{for(var i = 0, len = gdjs.Level_321Code.GDBarricadeSpikesObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDBarricadeSpikesObjects2[i].returnVariable(gdjs.Level_321Code.GDBarricadeSpikesObjects2[i].getVariables().getFromIndex(0)).add(1);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDBarricadeSpikesObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDBarricadeSpikesObjects2[i].setAnimationName("BarricadeD" + (gdjs.RuntimeObject.getVariableString(gdjs.Level_321Code.GDBarricadeSpikesObjects2[i].getVariables().getFromIndex(0))));
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("BarricadeSpikes"), gdjs.Level_321Code.GDBarricadeSpikesObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("Zambambo"), gdjs.Level_321Code.GDZambamboObjects1);

gdjs.Level_321Code.condition0IsTrue_0.val = false;
{
gdjs.Level_321Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects1ObjectsGDgdjs_46Level_95321Code_46GDZambamboObjects1Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBarricadeSpikesObjects1Objects, false, runtimeScene, false);
}if (gdjs.Level_321Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level_321Code.GDBarricadeSpikesObjects1 */
/* Reuse gdjs.Level_321Code.GDPlayerObjects1 */
/* Reuse gdjs.Level_321Code.GDZambamboObjects1 */
{for(var i = 0, len = gdjs.Level_321Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayerObjects1[i].getBehavior("Health").Hit((gdjs.RuntimeObject.getVariableNumber(((gdjs.Level_321Code.GDBarricadeSpikesObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Level_321Code.GDBarricadeSpikesObjects1[0].getVariables()).getFromIndex(2))), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.Level_321Code.GDZambamboObjects1.length ;i < len;++i) {
    gdjs.Level_321Code.GDZambamboObjects1[i].getBehavior("Health").Hit((gdjs.RuntimeObject.getVariableNumber(((gdjs.Level_321Code.GDBarricadeSpikesObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Level_321Code.GDBarricadeSpikesObjects1[0].getVariables()).getFromIndex(2))), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Level_321Code.GDBarricadeSpikesObjects1.length ;i < len;++i) {
    gdjs.Level_321Code.GDBarricadeSpikesObjects1[i].getBehavior("Health").Hit(1, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


};gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level_321Code.GDPlayerObjects2});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBuildTokenObjects2Objects = Hashtable.newFrom({"BuildToken": gdjs.Level_321Code.GDBuildTokenObjects2});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Level_321Code.GDPlayerObjects1});gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDHealthTokenObjects1Objects = Hashtable.newFrom({"HealthToken": gdjs.Level_321Code.GDHealthTokenObjects1});gdjs.Level_321Code.eventsList36 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("BuildToken"), gdjs.Level_321Code.GDBuildTokenObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);

gdjs.Level_321Code.condition0IsTrue_0.val = false;
{
gdjs.Level_321Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects2Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBuildTokenObjects2Objects, false, runtimeScene, false);
}if (gdjs.Level_321Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Assault"), gdjs.Level_321Code.GDAssaultObjects2);
/* Reuse gdjs.Level_321Code.GDBuildTokenObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Pistol"), gdjs.Level_321Code.GDPistolObjects2);
/* Reuse gdjs.Level_321Code.GDPlayerObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Rifle"), gdjs.Level_321Code.GDRifleObjects2);
gdjs.copyArray(runtimeScene.getObjects("Shotgun"), gdjs.Level_321Code.GDShotgunObjects2);
{for(var i = 0, len = gdjs.Level_321Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayerObjects2[i].returnVariable(gdjs.Level_321Code.GDPlayerObjects2[i].getVariables().getFromIndex(1)).add((gdjs.RuntimeObject.getVariableNumber(((gdjs.Level_321Code.GDBuildTokenObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Level_321Code.GDBuildTokenObjects2[0].getVariables()).getFromIndex(0))));
}
}{for(var i = 0, len = gdjs.Level_321Code.GDPistolObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPistolObjects2[i].returnVariable(gdjs.Level_321Code.GDPistolObjects2[i].getVariables().getFromIndex(2)).add((gdjs.RuntimeObject.getVariableNumber(((gdjs.Level_321Code.GDBuildTokenObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Level_321Code.GDBuildTokenObjects2[0].getVariables()).getFromIndex(1))));
}
}{for(var i = 0, len = gdjs.Level_321Code.GDShotgunObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDShotgunObjects2[i].returnVariable(gdjs.Level_321Code.GDShotgunObjects2[i].getVariables().getFromIndex(2)).add((gdjs.RuntimeObject.getVariableNumber(((gdjs.Level_321Code.GDBuildTokenObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Level_321Code.GDBuildTokenObjects2[0].getVariables()).getFromIndex(2))));
}
}{for(var i = 0, len = gdjs.Level_321Code.GDRifleObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDRifleObjects2[i].returnVariable(gdjs.Level_321Code.GDRifleObjects2[i].getVariables().getFromIndex(2)).add((gdjs.RuntimeObject.getVariableNumber(((gdjs.Level_321Code.GDBuildTokenObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Level_321Code.GDBuildTokenObjects2[0].getVariables()).getFromIndex(3))));
}
}{for(var i = 0, len = gdjs.Level_321Code.GDAssaultObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDAssaultObjects2[i].returnVariable(gdjs.Level_321Code.GDAssaultObjects2[i].getVariables().getFromIndex(2)).add((gdjs.RuntimeObject.getVariableNumber(((gdjs.Level_321Code.GDBuildTokenObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Level_321Code.GDBuildTokenObjects2[0].getVariables()).getFromIndex(4))));
}
}{for(var i = 0, len = gdjs.Level_321Code.GDBuildTokenObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDBuildTokenObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("HealthToken"), gdjs.Level_321Code.GDHealthTokenObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects1);

gdjs.Level_321Code.condition0IsTrue_0.val = false;
{
gdjs.Level_321Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects1Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDHealthTokenObjects1Objects, false, runtimeScene, false);
}if (gdjs.Level_321Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level_321Code.GDHealthTokenObjects1 */
/* Reuse gdjs.Level_321Code.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.Level_321Code.GDHealthTokenObjects1.length ;i < len;++i) {
    gdjs.Level_321Code.GDHealthTokenObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayerObjects1[i].getBehavior("Health").Heal(10, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


};gdjs.Level_321Code.eventsList37 = function(runtimeScene) {

{



}


{


{
gdjs.copyArray(runtimeScene.getObjects("DayText"), gdjs.Level_321Code.GDDayTextObjects2);
gdjs.copyArray(runtimeScene.getObjects("NightText"), gdjs.Level_321Code.GDNightTextObjects2);
gdjs.copyArray(runtimeScene.getObjects("TimeText"), gdjs.Level_321Code.GDTimeTextObjects2);
gdjs.copyArray(runtimeScene.getObjects("TimeText2"), gdjs.Level_321Code.GDTimeText2Objects2);
{gdjs.evtTools.camera.setLayerAmbientLightColor(runtimeScene, "Lighting", gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().getFromIndex(0)) + ";" + gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().getFromIndex(0)) + ";" + gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().getFromIndex(0)));
}{for(var i = 0, len = gdjs.Level_321Code.GDTimeTextObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDTimeTextObjects2[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().getFromIndex(0)));
}
}{for(var i = 0, len = gdjs.Level_321Code.GDTimeText2Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDTimeText2Objects2[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().getFromIndex(1)));
}
}{for(var i = 0, len = gdjs.Level_321Code.GDDayTextObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDDayTextObjects2[i].setString("Day " + gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Day")));
}
}{for(var i = 0, len = gdjs.Level_321Code.GDNightTextObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDNightTextObjects2[i].setString("Night " + gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Night")));
}
}}

}


{


gdjs.Level_321Code.condition0IsTrue_0.val = false;
{
gdjs.Level_321Code.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) == 0;
}if (gdjs.Level_321Code.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(0).add(gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene));
}}

}


{


gdjs.Level_321Code.condition0IsTrue_0.val = false;
{
gdjs.Level_321Code.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(0)) > 254;
}if (gdjs.Level_321Code.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(1).setNumber(1);
}{runtimeScene.getVariables().get("DaySwitch").setNumber(0);
}}

}


{


gdjs.Level_321Code.condition0IsTrue_0.val = false;
{
gdjs.Level_321Code.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) == 1;
}if (gdjs.Level_321Code.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(0).sub(gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene));
}}

}


{


gdjs.Level_321Code.condition0IsTrue_0.val = false;
{
gdjs.Level_321Code.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(0)) < 1;
}if (gdjs.Level_321Code.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(1).setNumber(0);
}{runtimeScene.getVariables().get("NightSwitch").setNumber(1);
}}

}


};gdjs.Level_321Code.eventsList38 = function(runtimeScene) {

};gdjs.Level_321Code.eventsList39 = function(runtimeScene) {

};gdjs.Level_321Code.eventsList40 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("SpawnPoint"), gdjs.Level_321Code.GDSpawnPointObjects2);

for(gdjs.Level_321Code.forEachIndex3 = 0;gdjs.Level_321Code.forEachIndex3 < gdjs.Level_321Code.GDSpawnPointObjects2.length;++gdjs.Level_321Code.forEachIndex3) {
gdjs.Level_321Code.GDSpawnPointObjects3.length = 0;


gdjs.Level_321Code.forEachTemporary3 = gdjs.Level_321Code.GDSpawnPointObjects2[gdjs.Level_321Code.forEachIndex3];
gdjs.Level_321Code.GDSpawnPointObjects3.push(gdjs.Level_321Code.forEachTemporary3);
gdjs.Level_321Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level_321Code.GDSpawnPointObjects3.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDSpawnPointObjects3[i].getVariableNumber(gdjs.Level_321Code.GDSpawnPointObjects3[i].getVariables().getFromIndex(1)) <= gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("CurrentLevel")) ) {
        gdjs.Level_321Code.condition0IsTrue_0.val = true;
        gdjs.Level_321Code.GDSpawnPointObjects3[k] = gdjs.Level_321Code.GDSpawnPointObjects3[i];
        ++k;
    }
}
gdjs.Level_321Code.GDSpawnPointObjects3.length = k;}if (gdjs.Level_321Code.condition0IsTrue_0.val) {
{for(var i = 0, len = gdjs.Level_321Code.GDSpawnPointObjects3.length ;i < len;++i) {
    gdjs.Level_321Code.GDSpawnPointObjects3[i].returnVariable(gdjs.Level_321Code.GDSpawnPointObjects3[i].getVariables().getFromIndex(0)).setNumber(1);
}
}}
}

}


};gdjs.Level_321Code.eventsList41 = function(runtimeScene) {

};gdjs.Level_321Code.eventsList42 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("SpawnPoint"), gdjs.Level_321Code.GDSpawnPointObjects2);

for(gdjs.Level_321Code.forEachIndex3 = 0;gdjs.Level_321Code.forEachIndex3 < gdjs.Level_321Code.GDSpawnPointObjects2.length;++gdjs.Level_321Code.forEachIndex3) {
gdjs.Level_321Code.GDSpawnPointObjects3.length = 0;


gdjs.Level_321Code.forEachTemporary3 = gdjs.Level_321Code.GDSpawnPointObjects2[gdjs.Level_321Code.forEachIndex3];
gdjs.Level_321Code.GDSpawnPointObjects3.push(gdjs.Level_321Code.forEachTemporary3);
if (true) {
{for(var i = 0, len = gdjs.Level_321Code.GDSpawnPointObjects3.length ;i < len;++i) {
    gdjs.Level_321Code.GDSpawnPointObjects3[i].returnVariable(gdjs.Level_321Code.GDSpawnPointObjects3[i].getVariables().getFromIndex(0)).setNumber(0);
}
}}
}

}


};gdjs.Level_321Code.eventsList43 = function(runtimeScene) {

{


gdjs.Level_321Code.condition0IsTrue_0.val = false;
{
{gdjs.Level_321Code.conditionTrue_1 = gdjs.Level_321Code.condition0IsTrue_0;
gdjs.Level_321Code.condition0IsTrue_1.val = false;
gdjs.Level_321Code.condition1IsTrue_1.val = false;
gdjs.Level_321Code.condition2IsTrue_1.val = false;
{
gdjs.Level_321Code.condition0IsTrue_1.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) == 1;
}if ( gdjs.Level_321Code.condition0IsTrue_1.val ) {
{
gdjs.Level_321Code.condition1IsTrue_1.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(0)) < 125;
}if ( gdjs.Level_321Code.condition1IsTrue_1.val ) {
{
gdjs.Level_321Code.condition2IsTrue_1.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("NightSwitch")) == 0;
}}
}
gdjs.Level_321Code.conditionTrue_1.val = true && gdjs.Level_321Code.condition0IsTrue_1.val && gdjs.Level_321Code.condition1IsTrue_1.val && gdjs.Level_321Code.condition2IsTrue_1.val;
}
}if (gdjs.Level_321Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("NightText"), gdjs.Level_321Code.GDNightTextObjects2);
{runtimeScene.getVariables().get("Night").add(1);
}{runtimeScene.getVariables().get("NightSwitch").setNumber(1);
}{runtimeScene.getVariables().get("CurrentLevel").add(1);
}{runtimeScene.getVariables().get("DaySwitch").setNumber(0);
}{for(var i = 0, len = gdjs.Level_321Code.GDNightTextObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDNightTextObjects2[i].setOpacity(255);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDNightTextObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDNightTextObjects2[i].resetTimer("NightTimer");
}
}
{ //Subevents
gdjs.Level_321Code.eventsList40(runtimeScene);} //End of subevents
}

}


{


{
}

}


{


gdjs.Level_321Code.condition0IsTrue_0.val = false;
{
{gdjs.Level_321Code.conditionTrue_1 = gdjs.Level_321Code.condition0IsTrue_0;
gdjs.Level_321Code.condition0IsTrue_1.val = false;
gdjs.Level_321Code.condition1IsTrue_1.val = false;
gdjs.Level_321Code.condition2IsTrue_1.val = false;
{
gdjs.Level_321Code.condition0IsTrue_1.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) == 0;
}if ( gdjs.Level_321Code.condition0IsTrue_1.val ) {
{
gdjs.Level_321Code.condition1IsTrue_1.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(0)) > 125;
}if ( gdjs.Level_321Code.condition1IsTrue_1.val ) {
{
gdjs.Level_321Code.condition2IsTrue_1.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("DaySwitch")) == 0;
}}
}
gdjs.Level_321Code.conditionTrue_1.val = true && gdjs.Level_321Code.condition0IsTrue_1.val && gdjs.Level_321Code.condition1IsTrue_1.val && gdjs.Level_321Code.condition2IsTrue_1.val;
}
}if (gdjs.Level_321Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("DayText"), gdjs.Level_321Code.GDDayTextObjects2);
{runtimeScene.getVariables().get("Day").add(1);
}{runtimeScene.getVariables().get("DaySwitch").setNumber(1);
}{runtimeScene.getVariables().get("NightSwitch").setNumber(0);
}{for(var i = 0, len = gdjs.Level_321Code.GDDayTextObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDDayTextObjects2[i].setOpacity(255);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDDayTextObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDDayTextObjects2[i].resetTimer("DayTimer");
}
}
{ //Subevents
gdjs.Level_321Code.eventsList42(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("DayText"), gdjs.Level_321Code.GDDayTextObjects2);

gdjs.Level_321Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level_321Code.GDDayTextObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDDayTextObjects2[i].getTimerElapsedTimeInSecondsOrNaN("DayTimer") > 4 ) {
        gdjs.Level_321Code.condition0IsTrue_0.val = true;
        gdjs.Level_321Code.GDDayTextObjects2[k] = gdjs.Level_321Code.GDDayTextObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDDayTextObjects2.length = k;}if (gdjs.Level_321Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level_321Code.GDDayTextObjects2 */
{for(var i = 0, len = gdjs.Level_321Code.GDDayTextObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDDayTextObjects2[i].setOpacity(0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NightText"), gdjs.Level_321Code.GDNightTextObjects1);

gdjs.Level_321Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level_321Code.GDNightTextObjects1.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDNightTextObjects1[i].getTimerElapsedTimeInSecondsOrNaN("NightTimer") > 4 ) {
        gdjs.Level_321Code.condition0IsTrue_0.val = true;
        gdjs.Level_321Code.GDNightTextObjects1[k] = gdjs.Level_321Code.GDNightTextObjects1[i];
        ++k;
    }
}
gdjs.Level_321Code.GDNightTextObjects1.length = k;}if (gdjs.Level_321Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level_321Code.GDNightTextObjects1 */
{for(var i = 0, len = gdjs.Level_321Code.GDNightTextObjects1.length ;i < len;++i) {
    gdjs.Level_321Code.GDNightTextObjects1[i].setOpacity(0);
}
}}

}


};gdjs.Level_321Code.eventsList44 = function(runtimeScene) {

{



}


{


gdjs.Level_321Code.condition0IsTrue_0.val = false;
{
gdjs.Level_321Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.Level_321Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("PlayerHead"), gdjs.Level_321Code.GDPlayerHeadObjects1);
{for(var i = 0, len = gdjs.Level_321Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayerObjects1[i].resetTimer("BuildTimer");
}
}{for(var i = 0, len = gdjs.Level_321Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayerObjects1[i].resetTimer("Ammo");
}
}{for(var i = 0, len = gdjs.Level_321Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayerObjects1[i].setScale(gdjs.Level_321Code.GDPlayerObjects1[i].getScale() * (0.75));
}
}{for(var i = 0, len = gdjs.Level_321Code.GDPlayerHeadObjects1.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayerHeadObjects1[i].setScale(gdjs.Level_321Code.GDPlayerHeadObjects1[i].getScale() * (0.75));
}
}{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 2, "", 0);
}
{ //Subevents
gdjs.Level_321Code.eventsList3(runtimeScene);} //End of subevents
}

}


{


gdjs.Level_321Code.eventsList4(runtimeScene);
}


{


gdjs.Level_321Code.eventsList13(runtimeScene);
}


{


gdjs.Level_321Code.eventsList15(runtimeScene);
}


{


gdjs.Level_321Code.eventsList19(runtimeScene);
}


{


gdjs.Level_321Code.eventsList21(runtimeScene);
}


{


gdjs.Level_321Code.eventsList33(runtimeScene);
}


{


gdjs.Level_321Code.eventsList35(runtimeScene);
}


{


gdjs.Level_321Code.eventsList36(runtimeScene);
}


{


gdjs.Level_321Code.eventsList37(runtimeScene);
}


{


gdjs.Level_321Code.eventsList38(runtimeScene);
}


{


gdjs.Level_321Code.eventsList43(runtimeScene);
}


};

gdjs.Level_321Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Level_321Code.GDPlayerHeadObjects1.length = 0;
gdjs.Level_321Code.GDPlayerHeadObjects2.length = 0;
gdjs.Level_321Code.GDPlayerHeadObjects3.length = 0;
gdjs.Level_321Code.GDPlayerHeadObjects4.length = 0;
gdjs.Level_321Code.GDPlayerHeadObjects5.length = 0;
gdjs.Level_321Code.GDPlayerHeadObjects6.length = 0;
gdjs.Level_321Code.GDPlayerObjects1.length = 0;
gdjs.Level_321Code.GDPlayerObjects2.length = 0;
gdjs.Level_321Code.GDPlayerObjects3.length = 0;
gdjs.Level_321Code.GDPlayerObjects4.length = 0;
gdjs.Level_321Code.GDPlayerObjects5.length = 0;
gdjs.Level_321Code.GDPlayerObjects6.length = 0;
gdjs.Level_321Code.GDZambamboObjects1.length = 0;
gdjs.Level_321Code.GDZambamboObjects2.length = 0;
gdjs.Level_321Code.GDZambamboObjects3.length = 0;
gdjs.Level_321Code.GDZambamboObjects4.length = 0;
gdjs.Level_321Code.GDZambamboObjects5.length = 0;
gdjs.Level_321Code.GDZambamboObjects6.length = 0;
gdjs.Level_321Code.GDBulletObjects1.length = 0;
gdjs.Level_321Code.GDBulletObjects2.length = 0;
gdjs.Level_321Code.GDBulletObjects3.length = 0;
gdjs.Level_321Code.GDBulletObjects4.length = 0;
gdjs.Level_321Code.GDBulletObjects5.length = 0;
gdjs.Level_321Code.GDBulletObjects6.length = 0;
gdjs.Level_321Code.GDFakewallObjects1.length = 0;
gdjs.Level_321Code.GDFakewallObjects2.length = 0;
gdjs.Level_321Code.GDFakewallObjects3.length = 0;
gdjs.Level_321Code.GDFakewallObjects4.length = 0;
gdjs.Level_321Code.GDFakewallObjects5.length = 0;
gdjs.Level_321Code.GDFakewallObjects6.length = 0;
gdjs.Level_321Code.GDWallObjects1.length = 0;
gdjs.Level_321Code.GDWallObjects2.length = 0;
gdjs.Level_321Code.GDWallObjects3.length = 0;
gdjs.Level_321Code.GDWallObjects4.length = 0;
gdjs.Level_321Code.GDWallObjects5.length = 0;
gdjs.Level_321Code.GDWallObjects6.length = 0;
gdjs.Level_321Code.GDBarricadeShortGhostObjects1.length = 0;
gdjs.Level_321Code.GDBarricadeShortGhostObjects2.length = 0;
gdjs.Level_321Code.GDBarricadeShortGhostObjects3.length = 0;
gdjs.Level_321Code.GDBarricadeShortGhostObjects4.length = 0;
gdjs.Level_321Code.GDBarricadeShortGhostObjects5.length = 0;
gdjs.Level_321Code.GDBarricadeShortGhostObjects6.length = 0;
gdjs.Level_321Code.GDBarricadeShortObjects1.length = 0;
gdjs.Level_321Code.GDBarricadeShortObjects2.length = 0;
gdjs.Level_321Code.GDBarricadeShortObjects3.length = 0;
gdjs.Level_321Code.GDBarricadeShortObjects4.length = 0;
gdjs.Level_321Code.GDBarricadeShortObjects5.length = 0;
gdjs.Level_321Code.GDBarricadeShortObjects6.length = 0;
gdjs.Level_321Code.GDBarricadeSpikesGhostObjects1.length = 0;
gdjs.Level_321Code.GDBarricadeSpikesGhostObjects2.length = 0;
gdjs.Level_321Code.GDBarricadeSpikesGhostObjects3.length = 0;
gdjs.Level_321Code.GDBarricadeSpikesGhostObjects4.length = 0;
gdjs.Level_321Code.GDBarricadeSpikesGhostObjects5.length = 0;
gdjs.Level_321Code.GDBarricadeSpikesGhostObjects6.length = 0;
gdjs.Level_321Code.GDBarricadeSpikesObjects1.length = 0;
gdjs.Level_321Code.GDBarricadeSpikesObjects2.length = 0;
gdjs.Level_321Code.GDBarricadeSpikesObjects3.length = 0;
gdjs.Level_321Code.GDBarricadeSpikesObjects4.length = 0;
gdjs.Level_321Code.GDBarricadeSpikesObjects5.length = 0;
gdjs.Level_321Code.GDBarricadeSpikesObjects6.length = 0;
gdjs.Level_321Code.GDBarricadeGhostObjects1.length = 0;
gdjs.Level_321Code.GDBarricadeGhostObjects2.length = 0;
gdjs.Level_321Code.GDBarricadeGhostObjects3.length = 0;
gdjs.Level_321Code.GDBarricadeGhostObjects4.length = 0;
gdjs.Level_321Code.GDBarricadeGhostObjects5.length = 0;
gdjs.Level_321Code.GDBarricadeGhostObjects6.length = 0;
gdjs.Level_321Code.GDBarricadeObjects1.length = 0;
gdjs.Level_321Code.GDBarricadeObjects2.length = 0;
gdjs.Level_321Code.GDBarricadeObjects3.length = 0;
gdjs.Level_321Code.GDBarricadeObjects4.length = 0;
gdjs.Level_321Code.GDBarricadeObjects5.length = 0;
gdjs.Level_321Code.GDBarricadeObjects6.length = 0;
gdjs.Level_321Code.GDHealthObjects1.length = 0;
gdjs.Level_321Code.GDHealthObjects2.length = 0;
gdjs.Level_321Code.GDHealthObjects3.length = 0;
gdjs.Level_321Code.GDHealthObjects4.length = 0;
gdjs.Level_321Code.GDHealthObjects5.length = 0;
gdjs.Level_321Code.GDHealthObjects6.length = 0;
gdjs.Level_321Code.GDHealthTokenObjects1.length = 0;
gdjs.Level_321Code.GDHealthTokenObjects2.length = 0;
gdjs.Level_321Code.GDHealthTokenObjects3.length = 0;
gdjs.Level_321Code.GDHealthTokenObjects4.length = 0;
gdjs.Level_321Code.GDHealthTokenObjects5.length = 0;
gdjs.Level_321Code.GDHealthTokenObjects6.length = 0;
gdjs.Level_321Code.GDBuildObjects1.length = 0;
gdjs.Level_321Code.GDBuildObjects2.length = 0;
gdjs.Level_321Code.GDBuildObjects3.length = 0;
gdjs.Level_321Code.GDBuildObjects4.length = 0;
gdjs.Level_321Code.GDBuildObjects5.length = 0;
gdjs.Level_321Code.GDBuildObjects6.length = 0;
gdjs.Level_321Code.GDBuildTokenObjects1.length = 0;
gdjs.Level_321Code.GDBuildTokenObjects2.length = 0;
gdjs.Level_321Code.GDBuildTokenObjects3.length = 0;
gdjs.Level_321Code.GDBuildTokenObjects4.length = 0;
gdjs.Level_321Code.GDBuildTokenObjects5.length = 0;
gdjs.Level_321Code.GDBuildTokenObjects6.length = 0;
gdjs.Level_321Code.GDLightObjects1.length = 0;
gdjs.Level_321Code.GDLightObjects2.length = 0;
gdjs.Level_321Code.GDLightObjects3.length = 0;
gdjs.Level_321Code.GDLightObjects4.length = 0;
gdjs.Level_321Code.GDLightObjects5.length = 0;
gdjs.Level_321Code.GDLightObjects6.length = 0;
gdjs.Level_321Code.GDSpawnPointObjects1.length = 0;
gdjs.Level_321Code.GDSpawnPointObjects2.length = 0;
gdjs.Level_321Code.GDSpawnPointObjects3.length = 0;
gdjs.Level_321Code.GDSpawnPointObjects4.length = 0;
gdjs.Level_321Code.GDSpawnPointObjects5.length = 0;
gdjs.Level_321Code.GDSpawnPointObjects6.length = 0;
gdjs.Level_321Code.GDEquipUIObjects1.length = 0;
gdjs.Level_321Code.GDEquipUIObjects2.length = 0;
gdjs.Level_321Code.GDEquipUIObjects3.length = 0;
gdjs.Level_321Code.GDEquipUIObjects4.length = 0;
gdjs.Level_321Code.GDEquipUIObjects5.length = 0;
gdjs.Level_321Code.GDEquipUIObjects6.length = 0;
gdjs.Level_321Code.GDSelectUIObjects1.length = 0;
gdjs.Level_321Code.GDSelectUIObjects2.length = 0;
gdjs.Level_321Code.GDSelectUIObjects3.length = 0;
gdjs.Level_321Code.GDSelectUIObjects4.length = 0;
gdjs.Level_321Code.GDSelectUIObjects5.length = 0;
gdjs.Level_321Code.GDSelectUIObjects6.length = 0;
gdjs.Level_321Code.GDTimeTextObjects1.length = 0;
gdjs.Level_321Code.GDTimeTextObjects2.length = 0;
gdjs.Level_321Code.GDTimeTextObjects3.length = 0;
gdjs.Level_321Code.GDTimeTextObjects4.length = 0;
gdjs.Level_321Code.GDTimeTextObjects5.length = 0;
gdjs.Level_321Code.GDTimeTextObjects6.length = 0;
gdjs.Level_321Code.GDNightTextObjects1.length = 0;
gdjs.Level_321Code.GDNightTextObjects2.length = 0;
gdjs.Level_321Code.GDNightTextObjects3.length = 0;
gdjs.Level_321Code.GDNightTextObjects4.length = 0;
gdjs.Level_321Code.GDNightTextObjects5.length = 0;
gdjs.Level_321Code.GDNightTextObjects6.length = 0;
gdjs.Level_321Code.GDDayTextObjects1.length = 0;
gdjs.Level_321Code.GDDayTextObjects2.length = 0;
gdjs.Level_321Code.GDDayTextObjects3.length = 0;
gdjs.Level_321Code.GDDayTextObjects4.length = 0;
gdjs.Level_321Code.GDDayTextObjects5.length = 0;
gdjs.Level_321Code.GDDayTextObjects6.length = 0;
gdjs.Level_321Code.GDTimeText2Objects1.length = 0;
gdjs.Level_321Code.GDTimeText2Objects2.length = 0;
gdjs.Level_321Code.GDTimeText2Objects3.length = 0;
gdjs.Level_321Code.GDTimeText2Objects4.length = 0;
gdjs.Level_321Code.GDTimeText2Objects5.length = 0;
gdjs.Level_321Code.GDTimeText2Objects6.length = 0;
gdjs.Level_321Code.GDAssaultObjects1.length = 0;
gdjs.Level_321Code.GDAssaultObjects2.length = 0;
gdjs.Level_321Code.GDAssaultObjects3.length = 0;
gdjs.Level_321Code.GDAssaultObjects4.length = 0;
gdjs.Level_321Code.GDAssaultObjects5.length = 0;
gdjs.Level_321Code.GDAssaultObjects6.length = 0;
gdjs.Level_321Code.GDRifleObjects1.length = 0;
gdjs.Level_321Code.GDRifleObjects2.length = 0;
gdjs.Level_321Code.GDRifleObjects3.length = 0;
gdjs.Level_321Code.GDRifleObjects4.length = 0;
gdjs.Level_321Code.GDRifleObjects5.length = 0;
gdjs.Level_321Code.GDRifleObjects6.length = 0;
gdjs.Level_321Code.GDShotgunObjects1.length = 0;
gdjs.Level_321Code.GDShotgunObjects2.length = 0;
gdjs.Level_321Code.GDShotgunObjects3.length = 0;
gdjs.Level_321Code.GDShotgunObjects4.length = 0;
gdjs.Level_321Code.GDShotgunObjects5.length = 0;
gdjs.Level_321Code.GDShotgunObjects6.length = 0;
gdjs.Level_321Code.GDPistolObjects1.length = 0;
gdjs.Level_321Code.GDPistolObjects2.length = 0;
gdjs.Level_321Code.GDPistolObjects3.length = 0;
gdjs.Level_321Code.GDPistolObjects4.length = 0;
gdjs.Level_321Code.GDPistolObjects5.length = 0;
gdjs.Level_321Code.GDPistolObjects6.length = 0;
gdjs.Level_321Code.GDAssaultAmmoObjects1.length = 0;
gdjs.Level_321Code.GDAssaultAmmoObjects2.length = 0;
gdjs.Level_321Code.GDAssaultAmmoObjects3.length = 0;
gdjs.Level_321Code.GDAssaultAmmoObjects4.length = 0;
gdjs.Level_321Code.GDAssaultAmmoObjects5.length = 0;
gdjs.Level_321Code.GDAssaultAmmoObjects6.length = 0;
gdjs.Level_321Code.GDRifleAmmoObjects1.length = 0;
gdjs.Level_321Code.GDRifleAmmoObjects2.length = 0;
gdjs.Level_321Code.GDRifleAmmoObjects3.length = 0;
gdjs.Level_321Code.GDRifleAmmoObjects4.length = 0;
gdjs.Level_321Code.GDRifleAmmoObjects5.length = 0;
gdjs.Level_321Code.GDRifleAmmoObjects6.length = 0;
gdjs.Level_321Code.GDShotgunAmmoObjects1.length = 0;
gdjs.Level_321Code.GDShotgunAmmoObjects2.length = 0;
gdjs.Level_321Code.GDShotgunAmmoObjects3.length = 0;
gdjs.Level_321Code.GDShotgunAmmoObjects4.length = 0;
gdjs.Level_321Code.GDShotgunAmmoObjects5.length = 0;
gdjs.Level_321Code.GDShotgunAmmoObjects6.length = 0;
gdjs.Level_321Code.GDPistolAmmoObjects1.length = 0;
gdjs.Level_321Code.GDPistolAmmoObjects2.length = 0;
gdjs.Level_321Code.GDPistolAmmoObjects3.length = 0;
gdjs.Level_321Code.GDPistolAmmoObjects4.length = 0;
gdjs.Level_321Code.GDPistolAmmoObjects5.length = 0;
gdjs.Level_321Code.GDPistolAmmoObjects6.length = 0;
gdjs.Level_321Code.GDMouseObjectObjects1.length = 0;
gdjs.Level_321Code.GDMouseObjectObjects2.length = 0;
gdjs.Level_321Code.GDMouseObjectObjects3.length = 0;
gdjs.Level_321Code.GDMouseObjectObjects4.length = 0;
gdjs.Level_321Code.GDMouseObjectObjects5.length = 0;
gdjs.Level_321Code.GDMouseObjectObjects6.length = 0;
gdjs.Level_321Code.GDZambamboHealthBackObjects1.length = 0;
gdjs.Level_321Code.GDZambamboHealthBackObjects2.length = 0;
gdjs.Level_321Code.GDZambamboHealthBackObjects3.length = 0;
gdjs.Level_321Code.GDZambamboHealthBackObjects4.length = 0;
gdjs.Level_321Code.GDZambamboHealthBackObjects5.length = 0;
gdjs.Level_321Code.GDZambamboHealthBackObjects6.length = 0;
gdjs.Level_321Code.GDZambamboHealthObjects1.length = 0;
gdjs.Level_321Code.GDZambamboHealthObjects2.length = 0;
gdjs.Level_321Code.GDZambamboHealthObjects3.length = 0;
gdjs.Level_321Code.GDZambamboHealthObjects4.length = 0;
gdjs.Level_321Code.GDZambamboHealthObjects5.length = 0;
gdjs.Level_321Code.GDZambamboHealthObjects6.length = 0;
gdjs.Level_321Code.GDtempwall1Objects1.length = 0;
gdjs.Level_321Code.GDtempwall1Objects2.length = 0;
gdjs.Level_321Code.GDtempwall1Objects3.length = 0;
gdjs.Level_321Code.GDtempwall1Objects4.length = 0;
gdjs.Level_321Code.GDtempwall1Objects5.length = 0;
gdjs.Level_321Code.GDtempwall1Objects6.length = 0;
gdjs.Level_321Code.GDtempwall2Objects1.length = 0;
gdjs.Level_321Code.GDtempwall2Objects2.length = 0;
gdjs.Level_321Code.GDtempwall2Objects3.length = 0;
gdjs.Level_321Code.GDtempwall2Objects4.length = 0;
gdjs.Level_321Code.GDtempwall2Objects5.length = 0;
gdjs.Level_321Code.GDtempwall2Objects6.length = 0;

gdjs.Level_321Code.eventsList44(runtimeScene);
return;

}

gdjs['Level_321Code'] = gdjs.Level_321Code;
