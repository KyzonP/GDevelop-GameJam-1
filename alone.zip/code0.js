gdjs.Test_32SceneCode = {};
gdjs.Test_32SceneCode.forEachIndex2 = 0;

gdjs.Test_32SceneCode.forEachIndex3 = 0;

gdjs.Test_32SceneCode.forEachIndex4 = 0;

gdjs.Test_32SceneCode.forEachObjects2 = [];

gdjs.Test_32SceneCode.forEachObjects3 = [];

gdjs.Test_32SceneCode.forEachObjects4 = [];

gdjs.Test_32SceneCode.forEachTemporary2 = null;

gdjs.Test_32SceneCode.forEachTemporary3 = null;

gdjs.Test_32SceneCode.forEachTemporary4 = null;

gdjs.Test_32SceneCode.forEachTotalCount2 = 0;

gdjs.Test_32SceneCode.forEachTotalCount3 = 0;

gdjs.Test_32SceneCode.forEachTotalCount4 = 0;

gdjs.Test_32SceneCode.repeatCount5 = 0;

gdjs.Test_32SceneCode.repeatIndex5 = 0;

gdjs.Test_32SceneCode.GDPlayerHeadObjects1= [];
gdjs.Test_32SceneCode.GDPlayerHeadObjects2= [];
gdjs.Test_32SceneCode.GDPlayerHeadObjects3= [];
gdjs.Test_32SceneCode.GDPlayerHeadObjects4= [];
gdjs.Test_32SceneCode.GDPlayerHeadObjects5= [];
gdjs.Test_32SceneCode.GDPlayerHeadObjects6= [];
gdjs.Test_32SceneCode.GDPlayerObjects1= [];
gdjs.Test_32SceneCode.GDPlayerObjects2= [];
gdjs.Test_32SceneCode.GDPlayerObjects3= [];
gdjs.Test_32SceneCode.GDPlayerObjects4= [];
gdjs.Test_32SceneCode.GDPlayerObjects5= [];
gdjs.Test_32SceneCode.GDPlayerObjects6= [];
gdjs.Test_32SceneCode.GDZambamboObjects1= [];
gdjs.Test_32SceneCode.GDZambamboObjects2= [];
gdjs.Test_32SceneCode.GDZambamboObjects3= [];
gdjs.Test_32SceneCode.GDZambamboObjects4= [];
gdjs.Test_32SceneCode.GDZambamboObjects5= [];
gdjs.Test_32SceneCode.GDZambamboObjects6= [];
gdjs.Test_32SceneCode.GDBulletObjects1= [];
gdjs.Test_32SceneCode.GDBulletObjects2= [];
gdjs.Test_32SceneCode.GDBulletObjects3= [];
gdjs.Test_32SceneCode.GDBulletObjects4= [];
gdjs.Test_32SceneCode.GDBulletObjects5= [];
gdjs.Test_32SceneCode.GDBulletObjects6= [];
gdjs.Test_32SceneCode.GDFakewallObjects1= [];
gdjs.Test_32SceneCode.GDFakewallObjects2= [];
gdjs.Test_32SceneCode.GDFakewallObjects3= [];
gdjs.Test_32SceneCode.GDFakewallObjects4= [];
gdjs.Test_32SceneCode.GDFakewallObjects5= [];
gdjs.Test_32SceneCode.GDFakewallObjects6= [];
gdjs.Test_32SceneCode.GDWallObjects1= [];
gdjs.Test_32SceneCode.GDWallObjects2= [];
gdjs.Test_32SceneCode.GDWallObjects3= [];
gdjs.Test_32SceneCode.GDWallObjects4= [];
gdjs.Test_32SceneCode.GDWallObjects5= [];
gdjs.Test_32SceneCode.GDWallObjects6= [];
gdjs.Test_32SceneCode.GDBarricadeShortGhostObjects1= [];
gdjs.Test_32SceneCode.GDBarricadeShortGhostObjects2= [];
gdjs.Test_32SceneCode.GDBarricadeShortGhostObjects3= [];
gdjs.Test_32SceneCode.GDBarricadeShortGhostObjects4= [];
gdjs.Test_32SceneCode.GDBarricadeShortGhostObjects5= [];
gdjs.Test_32SceneCode.GDBarricadeShortGhostObjects6= [];
gdjs.Test_32SceneCode.GDBarricadeShortObjects1= [];
gdjs.Test_32SceneCode.GDBarricadeShortObjects2= [];
gdjs.Test_32SceneCode.GDBarricadeShortObjects3= [];
gdjs.Test_32SceneCode.GDBarricadeShortObjects4= [];
gdjs.Test_32SceneCode.GDBarricadeShortObjects5= [];
gdjs.Test_32SceneCode.GDBarricadeShortObjects6= [];
gdjs.Test_32SceneCode.GDBarricadeSpikesGhostObjects1= [];
gdjs.Test_32SceneCode.GDBarricadeSpikesGhostObjects2= [];
gdjs.Test_32SceneCode.GDBarricadeSpikesGhostObjects3= [];
gdjs.Test_32SceneCode.GDBarricadeSpikesGhostObjects4= [];
gdjs.Test_32SceneCode.GDBarricadeSpikesGhostObjects5= [];
gdjs.Test_32SceneCode.GDBarricadeSpikesGhostObjects6= [];
gdjs.Test_32SceneCode.GDBarricadeSpikesObjects1= [];
gdjs.Test_32SceneCode.GDBarricadeSpikesObjects2= [];
gdjs.Test_32SceneCode.GDBarricadeSpikesObjects3= [];
gdjs.Test_32SceneCode.GDBarricadeSpikesObjects4= [];
gdjs.Test_32SceneCode.GDBarricadeSpikesObjects5= [];
gdjs.Test_32SceneCode.GDBarricadeSpikesObjects6= [];
gdjs.Test_32SceneCode.GDBarricadeGhostObjects1= [];
gdjs.Test_32SceneCode.GDBarricadeGhostObjects2= [];
gdjs.Test_32SceneCode.GDBarricadeGhostObjects3= [];
gdjs.Test_32SceneCode.GDBarricadeGhostObjects4= [];
gdjs.Test_32SceneCode.GDBarricadeGhostObjects5= [];
gdjs.Test_32SceneCode.GDBarricadeGhostObjects6= [];
gdjs.Test_32SceneCode.GDBarricadeObjects1= [];
gdjs.Test_32SceneCode.GDBarricadeObjects2= [];
gdjs.Test_32SceneCode.GDBarricadeObjects3= [];
gdjs.Test_32SceneCode.GDBarricadeObjects4= [];
gdjs.Test_32SceneCode.GDBarricadeObjects5= [];
gdjs.Test_32SceneCode.GDBarricadeObjects6= [];
gdjs.Test_32SceneCode.GDHealthObjects1= [];
gdjs.Test_32SceneCode.GDHealthObjects2= [];
gdjs.Test_32SceneCode.GDHealthObjects3= [];
gdjs.Test_32SceneCode.GDHealthObjects4= [];
gdjs.Test_32SceneCode.GDHealthObjects5= [];
gdjs.Test_32SceneCode.GDHealthObjects6= [];
gdjs.Test_32SceneCode.GDHealthTokenObjects1= [];
gdjs.Test_32SceneCode.GDHealthTokenObjects2= [];
gdjs.Test_32SceneCode.GDHealthTokenObjects3= [];
gdjs.Test_32SceneCode.GDHealthTokenObjects4= [];
gdjs.Test_32SceneCode.GDHealthTokenObjects5= [];
gdjs.Test_32SceneCode.GDHealthTokenObjects6= [];
gdjs.Test_32SceneCode.GDBuildObjects1= [];
gdjs.Test_32SceneCode.GDBuildObjects2= [];
gdjs.Test_32SceneCode.GDBuildObjects3= [];
gdjs.Test_32SceneCode.GDBuildObjects4= [];
gdjs.Test_32SceneCode.GDBuildObjects5= [];
gdjs.Test_32SceneCode.GDBuildObjects6= [];
gdjs.Test_32SceneCode.GDBuildTokenObjects1= [];
gdjs.Test_32SceneCode.GDBuildTokenObjects2= [];
gdjs.Test_32SceneCode.GDBuildTokenObjects3= [];
gdjs.Test_32SceneCode.GDBuildTokenObjects4= [];
gdjs.Test_32SceneCode.GDBuildTokenObjects5= [];
gdjs.Test_32SceneCode.GDBuildTokenObjects6= [];
gdjs.Test_32SceneCode.GDLightObjects1= [];
gdjs.Test_32SceneCode.GDLightObjects2= [];
gdjs.Test_32SceneCode.GDLightObjects3= [];
gdjs.Test_32SceneCode.GDLightObjects4= [];
gdjs.Test_32SceneCode.GDLightObjects5= [];
gdjs.Test_32SceneCode.GDLightObjects6= [];
gdjs.Test_32SceneCode.GDSpawnPointObjects1= [];
gdjs.Test_32SceneCode.GDSpawnPointObjects2= [];
gdjs.Test_32SceneCode.GDSpawnPointObjects3= [];
gdjs.Test_32SceneCode.GDSpawnPointObjects4= [];
gdjs.Test_32SceneCode.GDSpawnPointObjects5= [];
gdjs.Test_32SceneCode.GDSpawnPointObjects6= [];
gdjs.Test_32SceneCode.GDEquipUIObjects1= [];
gdjs.Test_32SceneCode.GDEquipUIObjects2= [];
gdjs.Test_32SceneCode.GDEquipUIObjects3= [];
gdjs.Test_32SceneCode.GDEquipUIObjects4= [];
gdjs.Test_32SceneCode.GDEquipUIObjects5= [];
gdjs.Test_32SceneCode.GDEquipUIObjects6= [];
gdjs.Test_32SceneCode.GDSelectUIObjects1= [];
gdjs.Test_32SceneCode.GDSelectUIObjects2= [];
gdjs.Test_32SceneCode.GDSelectUIObjects3= [];
gdjs.Test_32SceneCode.GDSelectUIObjects4= [];
gdjs.Test_32SceneCode.GDSelectUIObjects5= [];
gdjs.Test_32SceneCode.GDSelectUIObjects6= [];
gdjs.Test_32SceneCode.GDTimeTextObjects1= [];
gdjs.Test_32SceneCode.GDTimeTextObjects2= [];
gdjs.Test_32SceneCode.GDTimeTextObjects3= [];
gdjs.Test_32SceneCode.GDTimeTextObjects4= [];
gdjs.Test_32SceneCode.GDTimeTextObjects5= [];
gdjs.Test_32SceneCode.GDTimeTextObjects6= [];
gdjs.Test_32SceneCode.GDNightTextObjects1= [];
gdjs.Test_32SceneCode.GDNightTextObjects2= [];
gdjs.Test_32SceneCode.GDNightTextObjects3= [];
gdjs.Test_32SceneCode.GDNightTextObjects4= [];
gdjs.Test_32SceneCode.GDNightTextObjects5= [];
gdjs.Test_32SceneCode.GDNightTextObjects6= [];
gdjs.Test_32SceneCode.GDDayTextObjects1= [];
gdjs.Test_32SceneCode.GDDayTextObjects2= [];
gdjs.Test_32SceneCode.GDDayTextObjects3= [];
gdjs.Test_32SceneCode.GDDayTextObjects4= [];
gdjs.Test_32SceneCode.GDDayTextObjects5= [];
gdjs.Test_32SceneCode.GDDayTextObjects6= [];
gdjs.Test_32SceneCode.GDTimeText2Objects1= [];
gdjs.Test_32SceneCode.GDTimeText2Objects2= [];
gdjs.Test_32SceneCode.GDTimeText2Objects3= [];
gdjs.Test_32SceneCode.GDTimeText2Objects4= [];
gdjs.Test_32SceneCode.GDTimeText2Objects5= [];
gdjs.Test_32SceneCode.GDTimeText2Objects6= [];
gdjs.Test_32SceneCode.GDAssaultObjects1= [];
gdjs.Test_32SceneCode.GDAssaultObjects2= [];
gdjs.Test_32SceneCode.GDAssaultObjects3= [];
gdjs.Test_32SceneCode.GDAssaultObjects4= [];
gdjs.Test_32SceneCode.GDAssaultObjects5= [];
gdjs.Test_32SceneCode.GDAssaultObjects6= [];
gdjs.Test_32SceneCode.GDRifleObjects1= [];
gdjs.Test_32SceneCode.GDRifleObjects2= [];
gdjs.Test_32SceneCode.GDRifleObjects3= [];
gdjs.Test_32SceneCode.GDRifleObjects4= [];
gdjs.Test_32SceneCode.GDRifleObjects5= [];
gdjs.Test_32SceneCode.GDRifleObjects6= [];
gdjs.Test_32SceneCode.GDShotgunObjects1= [];
gdjs.Test_32SceneCode.GDShotgunObjects2= [];
gdjs.Test_32SceneCode.GDShotgunObjects3= [];
gdjs.Test_32SceneCode.GDShotgunObjects4= [];
gdjs.Test_32SceneCode.GDShotgunObjects5= [];
gdjs.Test_32SceneCode.GDShotgunObjects6= [];
gdjs.Test_32SceneCode.GDPistolObjects1= [];
gdjs.Test_32SceneCode.GDPistolObjects2= [];
gdjs.Test_32SceneCode.GDPistolObjects3= [];
gdjs.Test_32SceneCode.GDPistolObjects4= [];
gdjs.Test_32SceneCode.GDPistolObjects5= [];
gdjs.Test_32SceneCode.GDPistolObjects6= [];
gdjs.Test_32SceneCode.GDAssaultAmmoObjects1= [];
gdjs.Test_32SceneCode.GDAssaultAmmoObjects2= [];
gdjs.Test_32SceneCode.GDAssaultAmmoObjects3= [];
gdjs.Test_32SceneCode.GDAssaultAmmoObjects4= [];
gdjs.Test_32SceneCode.GDAssaultAmmoObjects5= [];
gdjs.Test_32SceneCode.GDAssaultAmmoObjects6= [];
gdjs.Test_32SceneCode.GDRifleAmmoObjects1= [];
gdjs.Test_32SceneCode.GDRifleAmmoObjects2= [];
gdjs.Test_32SceneCode.GDRifleAmmoObjects3= [];
gdjs.Test_32SceneCode.GDRifleAmmoObjects4= [];
gdjs.Test_32SceneCode.GDRifleAmmoObjects5= [];
gdjs.Test_32SceneCode.GDRifleAmmoObjects6= [];
gdjs.Test_32SceneCode.GDShotgunAmmoObjects1= [];
gdjs.Test_32SceneCode.GDShotgunAmmoObjects2= [];
gdjs.Test_32SceneCode.GDShotgunAmmoObjects3= [];
gdjs.Test_32SceneCode.GDShotgunAmmoObjects4= [];
gdjs.Test_32SceneCode.GDShotgunAmmoObjects5= [];
gdjs.Test_32SceneCode.GDShotgunAmmoObjects6= [];
gdjs.Test_32SceneCode.GDPistolAmmoObjects1= [];
gdjs.Test_32SceneCode.GDPistolAmmoObjects2= [];
gdjs.Test_32SceneCode.GDPistolAmmoObjects3= [];
gdjs.Test_32SceneCode.GDPistolAmmoObjects4= [];
gdjs.Test_32SceneCode.GDPistolAmmoObjects5= [];
gdjs.Test_32SceneCode.GDPistolAmmoObjects6= [];
gdjs.Test_32SceneCode.GDMouseObjectObjects1= [];
gdjs.Test_32SceneCode.GDMouseObjectObjects2= [];
gdjs.Test_32SceneCode.GDMouseObjectObjects3= [];
gdjs.Test_32SceneCode.GDMouseObjectObjects4= [];
gdjs.Test_32SceneCode.GDMouseObjectObjects5= [];
gdjs.Test_32SceneCode.GDMouseObjectObjects6= [];
gdjs.Test_32SceneCode.GDZambamboHealthBackObjects1= [];
gdjs.Test_32SceneCode.GDZambamboHealthBackObjects2= [];
gdjs.Test_32SceneCode.GDZambamboHealthBackObjects3= [];
gdjs.Test_32SceneCode.GDZambamboHealthBackObjects4= [];
gdjs.Test_32SceneCode.GDZambamboHealthBackObjects5= [];
gdjs.Test_32SceneCode.GDZambamboHealthBackObjects6= [];
gdjs.Test_32SceneCode.GDZambamboHealthObjects1= [];
gdjs.Test_32SceneCode.GDZambamboHealthObjects2= [];
gdjs.Test_32SceneCode.GDZambamboHealthObjects3= [];
gdjs.Test_32SceneCode.GDZambamboHealthObjects4= [];
gdjs.Test_32SceneCode.GDZambamboHealthObjects5= [];
gdjs.Test_32SceneCode.GDZambamboHealthObjects6= [];
gdjs.Test_32SceneCode.GDtempwall1Objects1= [];
gdjs.Test_32SceneCode.GDtempwall1Objects2= [];
gdjs.Test_32SceneCode.GDtempwall1Objects3= [];
gdjs.Test_32SceneCode.GDtempwall1Objects4= [];
gdjs.Test_32SceneCode.GDtempwall1Objects5= [];
gdjs.Test_32SceneCode.GDtempwall1Objects6= [];
gdjs.Test_32SceneCode.GDtempwall2Objects1= [];
gdjs.Test_32SceneCode.GDtempwall2Objects2= [];
gdjs.Test_32SceneCode.GDtempwall2Objects3= [];
gdjs.Test_32SceneCode.GDtempwall2Objects4= [];
gdjs.Test_32SceneCode.GDtempwall2Objects5= [];
gdjs.Test_32SceneCode.GDtempwall2Objects6= [];
gdjs.Test_32SceneCode.GDTileCarpetObjects1= [];
gdjs.Test_32SceneCode.GDTileCarpetObjects2= [];
gdjs.Test_32SceneCode.GDTileCarpetObjects3= [];
gdjs.Test_32SceneCode.GDTileCarpetObjects4= [];
gdjs.Test_32SceneCode.GDTileCarpetObjects5= [];
gdjs.Test_32SceneCode.GDTileCarpetObjects6= [];
gdjs.Test_32SceneCode.GDTileWallsObjects1= [];
gdjs.Test_32SceneCode.GDTileWallsObjects2= [];
gdjs.Test_32SceneCode.GDTileWallsObjects3= [];
gdjs.Test_32SceneCode.GDTileWallsObjects4= [];
gdjs.Test_32SceneCode.GDTileWallsObjects5= [];
gdjs.Test_32SceneCode.GDTileWallsObjects6= [];
gdjs.Test_32SceneCode.GDObjectSpawnObjects1= [];
gdjs.Test_32SceneCode.GDObjectSpawnObjects2= [];
gdjs.Test_32SceneCode.GDObjectSpawnObjects3= [];
gdjs.Test_32SceneCode.GDObjectSpawnObjects4= [];
gdjs.Test_32SceneCode.GDObjectSpawnObjects5= [];
gdjs.Test_32SceneCode.GDObjectSpawnObjects6= [];
gdjs.Test_32SceneCode.GDBarricadePropObjects1= [];
gdjs.Test_32SceneCode.GDBarricadePropObjects2= [];
gdjs.Test_32SceneCode.GDBarricadePropObjects3= [];
gdjs.Test_32SceneCode.GDBarricadePropObjects4= [];
gdjs.Test_32SceneCode.GDBarricadePropObjects5= [];
gdjs.Test_32SceneCode.GDBarricadePropObjects6= [];
gdjs.Test_32SceneCode.GDTileG1Objects1= [];
gdjs.Test_32SceneCode.GDTileG1Objects2= [];
gdjs.Test_32SceneCode.GDTileG1Objects3= [];
gdjs.Test_32SceneCode.GDTileG1Objects4= [];
gdjs.Test_32SceneCode.GDTileG1Objects5= [];
gdjs.Test_32SceneCode.GDTileG1Objects6= [];
gdjs.Test_32SceneCode.GDTileG2Objects1= [];
gdjs.Test_32SceneCode.GDTileG2Objects2= [];
gdjs.Test_32SceneCode.GDTileG2Objects3= [];
gdjs.Test_32SceneCode.GDTileG2Objects4= [];
gdjs.Test_32SceneCode.GDTileG2Objects5= [];
gdjs.Test_32SceneCode.GDTileG2Objects6= [];

gdjs.Test_32SceneCode.conditionTrue_0 = {val:false};
gdjs.Test_32SceneCode.condition0IsTrue_0 = {val:false};
gdjs.Test_32SceneCode.condition1IsTrue_0 = {val:false};
gdjs.Test_32SceneCode.condition2IsTrue_0 = {val:false};
gdjs.Test_32SceneCode.condition3IsTrue_0 = {val:false};
gdjs.Test_32SceneCode.condition4IsTrue_0 = {val:false};
gdjs.Test_32SceneCode.condition5IsTrue_0 = {val:false};
gdjs.Test_32SceneCode.condition6IsTrue_0 = {val:false};
gdjs.Test_32SceneCode.condition7IsTrue_0 = {val:false};
gdjs.Test_32SceneCode.conditionTrue_1 = {val:false};
gdjs.Test_32SceneCode.condition0IsTrue_1 = {val:false};
gdjs.Test_32SceneCode.condition1IsTrue_1 = {val:false};
gdjs.Test_32SceneCode.condition2IsTrue_1 = {val:false};
gdjs.Test_32SceneCode.condition3IsTrue_1 = {val:false};
gdjs.Test_32SceneCode.condition4IsTrue_1 = {val:false};
gdjs.Test_32SceneCode.condition5IsTrue_1 = {val:false};
gdjs.Test_32SceneCode.condition6IsTrue_1 = {val:false};
gdjs.Test_32SceneCode.condition7IsTrue_1 = {val:false};


gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDEquipUIObjects2Objects = Hashtable.newFrom({"EquipUI": gdjs.Test_32SceneCode.GDEquipUIObjects2});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDSelectUIObjects2Objects = Hashtable.newFrom({"SelectUI": gdjs.Test_32SceneCode.GDSelectUIObjects2});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDHealthObjects2Objects = Hashtable.newFrom({"Health": gdjs.Test_32SceneCode.GDHealthObjects2});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBuildObjects2Objects = Hashtable.newFrom({"Build": gdjs.Test_32SceneCode.GDBuildObjects2});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDPistolAmmoObjects2Objects = Hashtable.newFrom({"PistolAmmo": gdjs.Test_32SceneCode.GDPistolAmmoObjects2});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDShotgunAmmoObjects2Objects = Hashtable.newFrom({"ShotgunAmmo": gdjs.Test_32SceneCode.GDShotgunAmmoObjects2});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDRifleAmmoObjects2Objects = Hashtable.newFrom({"RifleAmmo": gdjs.Test_32SceneCode.GDRifleAmmoObjects2});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDAssaultAmmoObjects2Objects = Hashtable.newFrom({"AssaultAmmo": gdjs.Test_32SceneCode.GDAssaultAmmoObjects2});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDMouseObjectObjects2Objects = Hashtable.newFrom({"MouseObject": gdjs.Test_32SceneCode.GDMouseObjectObjects2});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDPistolObjects2Objects = Hashtable.newFrom({"Pistol": gdjs.Test_32SceneCode.GDPistolObjects2});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDShotgunObjects2Objects = Hashtable.newFrom({"Shotgun": gdjs.Test_32SceneCode.GDShotgunObjects2});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDRifleObjects2Objects = Hashtable.newFrom({"Rifle": gdjs.Test_32SceneCode.GDRifleObjects2});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDAssaultObjects2Objects = Hashtable.newFrom({"Assault": gdjs.Test_32SceneCode.GDAssaultObjects2});gdjs.Test_32SceneCode.eventsList0 = function(runtimeScene) {

};gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDZambamboHealthObjects3Objects = Hashtable.newFrom({"ZambamboHealth": gdjs.Test_32SceneCode.GDZambamboHealthObjects3});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDZambamboHealthBackObjects3Objects = Hashtable.newFrom({"ZambamboHealthBack": gdjs.Test_32SceneCode.GDZambamboHealthBackObjects3});gdjs.Test_32SceneCode.eventsList1 = function(runtimeScene) {

};gdjs.Test_32SceneCode.eventsList2 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Test_32SceneCode.GDSpawnPointObjects3, gdjs.Test_32SceneCode.GDSpawnPointObjects4);


gdjs.Test_32SceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Test_32SceneCode.GDSpawnPointObjects4.length;i<l;++i) {
    if ( gdjs.Test_32SceneCode.GDSpawnPointObjects4[i].getY() == -(864) ) {
        gdjs.Test_32SceneCode.condition0IsTrue_0.val = true;
        gdjs.Test_32SceneCode.GDSpawnPointObjects4[k] = gdjs.Test_32SceneCode.GDSpawnPointObjects4[i];
        ++k;
    }
}
gdjs.Test_32SceneCode.GDSpawnPointObjects4.length = k;}if (gdjs.Test_32SceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Test_32SceneCode.GDSpawnPointObjects4 */
{for(var i = 0, len = gdjs.Test_32SceneCode.GDSpawnPointObjects4.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDSpawnPointObjects4[i].returnVariable(gdjs.Test_32SceneCode.GDSpawnPointObjects4[i].getVariables().getFromIndex(1)).setNumber(1);
}
}}

}


{

gdjs.copyArray(gdjs.Test_32SceneCode.GDSpawnPointObjects3, gdjs.Test_32SceneCode.GDSpawnPointObjects4);


gdjs.Test_32SceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Test_32SceneCode.GDSpawnPointObjects4.length;i<l;++i) {
    if ( gdjs.Test_32SceneCode.GDSpawnPointObjects4[i].getX() == -(864) ) {
        gdjs.Test_32SceneCode.condition0IsTrue_0.val = true;
        gdjs.Test_32SceneCode.GDSpawnPointObjects4[k] = gdjs.Test_32SceneCode.GDSpawnPointObjects4[i];
        ++k;
    }
}
gdjs.Test_32SceneCode.GDSpawnPointObjects4.length = k;}if (gdjs.Test_32SceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Test_32SceneCode.GDSpawnPointObjects4 */
{for(var i = 0, len = gdjs.Test_32SceneCode.GDSpawnPointObjects4.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDSpawnPointObjects4[i].returnVariable(gdjs.Test_32SceneCode.GDSpawnPointObjects4[i].getVariables().getFromIndex(1)).setNumber(2);
}
}}

}


{

gdjs.copyArray(gdjs.Test_32SceneCode.GDSpawnPointObjects3, gdjs.Test_32SceneCode.GDSpawnPointObjects4);


gdjs.Test_32SceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Test_32SceneCode.GDSpawnPointObjects4.length;i<l;++i) {
    if ( gdjs.Test_32SceneCode.GDSpawnPointObjects4[i].getY() == 4000 ) {
        gdjs.Test_32SceneCode.condition0IsTrue_0.val = true;
        gdjs.Test_32SceneCode.GDSpawnPointObjects4[k] = gdjs.Test_32SceneCode.GDSpawnPointObjects4[i];
        ++k;
    }
}
gdjs.Test_32SceneCode.GDSpawnPointObjects4.length = k;}if (gdjs.Test_32SceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Test_32SceneCode.GDSpawnPointObjects4 */
{for(var i = 0, len = gdjs.Test_32SceneCode.GDSpawnPointObjects4.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDSpawnPointObjects4[i].returnVariable(gdjs.Test_32SceneCode.GDSpawnPointObjects4[i].getVariables().getFromIndex(1)).setNumber(3);
}
}}

}


{

gdjs.copyArray(gdjs.Test_32SceneCode.GDSpawnPointObjects3, gdjs.Test_32SceneCode.GDSpawnPointObjects4);


gdjs.Test_32SceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Test_32SceneCode.GDSpawnPointObjects4.length;i<l;++i) {
    if ( gdjs.Test_32SceneCode.GDSpawnPointObjects4[i].getX() == 4000 ) {
        gdjs.Test_32SceneCode.condition0IsTrue_0.val = true;
        gdjs.Test_32SceneCode.GDSpawnPointObjects4[k] = gdjs.Test_32SceneCode.GDSpawnPointObjects4[i];
        ++k;
    }
}
gdjs.Test_32SceneCode.GDSpawnPointObjects4.length = k;}if (gdjs.Test_32SceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Test_32SceneCode.GDSpawnPointObjects4 */
{for(var i = 0, len = gdjs.Test_32SceneCode.GDSpawnPointObjects4.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDSpawnPointObjects4[i].returnVariable(gdjs.Test_32SceneCode.GDSpawnPointObjects4[i].getVariables().getFromIndex(1)).setNumber(4);
}
}}

}


};gdjs.Test_32SceneCode.eventsList3 = function(runtimeScene) {

{



}


{


{
gdjs.Test_32SceneCode.GDBuildObjects2.length = 0;

gdjs.Test_32SceneCode.GDEquipUIObjects2.length = 0;

gdjs.Test_32SceneCode.GDHealthObjects2.length = 0;

gdjs.Test_32SceneCode.GDSelectUIObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDEquipUIObjects2Objects, 640, 992, "UI");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDSelectUIObjects2Objects, 632, 992, "UI");
}{for(var i = 0, len = gdjs.Test_32SceneCode.GDSelectUIObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDSelectUIObjects2[i].setPosition((( gdjs.Test_32SceneCode.GDEquipUIObjects2.length === 0 ) ? 0 :gdjs.Test_32SceneCode.GDEquipUIObjects2[0].getPointX("")) - 4,(( gdjs.Test_32SceneCode.GDEquipUIObjects2.length === 0 ) ? 0 :gdjs.Test_32SceneCode.GDEquipUIObjects2[0].getPointY("")) - 4);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDHealthObjects2Objects, 0, 0, "UI");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBuildObjects2Objects, 0, 64, "UI");
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("EquipUI"), gdjs.Test_32SceneCode.GDEquipUIObjects2);
gdjs.Test_32SceneCode.GDAssaultAmmoObjects2.length = 0;

gdjs.Test_32SceneCode.GDPistolAmmoObjects2.length = 0;

gdjs.Test_32SceneCode.GDRifleAmmoObjects2.length = 0;

gdjs.Test_32SceneCode.GDShotgunAmmoObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDPistolAmmoObjects2Objects, (( gdjs.Test_32SceneCode.GDEquipUIObjects2.length === 0 ) ? 0 :gdjs.Test_32SceneCode.GDEquipUIObjects2[0].getPointX("")), (( gdjs.Test_32SceneCode.GDEquipUIObjects2.length === 0 ) ? 0 :gdjs.Test_32SceneCode.GDEquipUIObjects2[0].getPointY("")) - 25, "UI");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDShotgunAmmoObjects2Objects, (( gdjs.Test_32SceneCode.GDEquipUIObjects2.length === 0 ) ? 0 :gdjs.Test_32SceneCode.GDEquipUIObjects2[0].getPointX("")) + 64, (( gdjs.Test_32SceneCode.GDEquipUIObjects2.length === 0 ) ? 0 :gdjs.Test_32SceneCode.GDEquipUIObjects2[0].getPointY("")) - 25, "UI");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDRifleAmmoObjects2Objects, (( gdjs.Test_32SceneCode.GDEquipUIObjects2.length === 0 ) ? 0 :gdjs.Test_32SceneCode.GDEquipUIObjects2[0].getPointX("")) + 128, (( gdjs.Test_32SceneCode.GDEquipUIObjects2.length === 0 ) ? 0 :gdjs.Test_32SceneCode.GDEquipUIObjects2[0].getPointY("")) - 25, "UI");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDAssaultAmmoObjects2Objects, (( gdjs.Test_32SceneCode.GDEquipUIObjects2.length === 0 ) ? 0 :gdjs.Test_32SceneCode.GDEquipUIObjects2[0].getPointX("")) + 192, (( gdjs.Test_32SceneCode.GDEquipUIObjects2.length === 0 ) ? 0 :gdjs.Test_32SceneCode.GDEquipUIObjects2[0].getPointY("")) - 25, "UI");
}}

}


{



}


{


{
gdjs.Test_32SceneCode.GDMouseObjectObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDMouseObjectObjects2Objects, gdjs.evtTools.input.getMouseX(runtimeScene, "", 0), gdjs.evtTools.input.getMouseY(runtimeScene, "", 0), "");
}}

}


{



}


{


{
gdjs.Test_32SceneCode.GDAssaultObjects2.length = 0;

gdjs.Test_32SceneCode.GDPistolObjects2.length = 0;

gdjs.Test_32SceneCode.GDRifleObjects2.length = 0;

gdjs.Test_32SceneCode.GDShotgunObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDPistolObjects2Objects, 0, 0, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDShotgunObjects2Objects, 0, 0, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDRifleObjects2Objects, 0, 0, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDAssaultObjects2Objects, 0, 0, "");
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Wall"), gdjs.Test_32SceneCode.GDWallObjects2);

for(gdjs.Test_32SceneCode.forEachIndex3 = 0;gdjs.Test_32SceneCode.forEachIndex3 < gdjs.Test_32SceneCode.GDWallObjects2.length;++gdjs.Test_32SceneCode.forEachIndex3) {
gdjs.Test_32SceneCode.GDWallObjects3.length = 0;


gdjs.Test_32SceneCode.forEachTemporary3 = gdjs.Test_32SceneCode.GDWallObjects2[gdjs.Test_32SceneCode.forEachIndex3];
gdjs.Test_32SceneCode.GDWallObjects3.push(gdjs.Test_32SceneCode.forEachTemporary3);
if (true) {
{for(var i = 0, len = gdjs.Test_32SceneCode.GDWallObjects3.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDWallObjects3[i].setZOrder((gdjs.Test_32SceneCode.GDWallObjects3[i].getY()));
}
}}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Zambambo"), gdjs.Test_32SceneCode.GDZambamboObjects2);

for(gdjs.Test_32SceneCode.forEachIndex3 = 0;gdjs.Test_32SceneCode.forEachIndex3 < gdjs.Test_32SceneCode.GDZambamboObjects2.length;++gdjs.Test_32SceneCode.forEachIndex3) {
gdjs.Test_32SceneCode.GDZambamboHealthObjects3.length = 0;

gdjs.Test_32SceneCode.GDZambamboHealthBackObjects3.length = 0;

gdjs.Test_32SceneCode.GDZambamboObjects3.length = 0;


gdjs.Test_32SceneCode.forEachTemporary3 = gdjs.Test_32SceneCode.GDZambamboObjects2[gdjs.Test_32SceneCode.forEachIndex3];
gdjs.Test_32SceneCode.GDZambamboObjects3.push(gdjs.Test_32SceneCode.forEachTemporary3);
if (true) {
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDZambamboHealthObjects3Objects, (( gdjs.Test_32SceneCode.GDZambamboObjects3.length === 0 ) ? 0 :gdjs.Test_32SceneCode.GDZambamboObjects3[0].getPointX("")), (( gdjs.Test_32SceneCode.GDZambamboObjects3.length === 0 ) ? 0 :gdjs.Test_32SceneCode.GDZambamboObjects3[0].getPointY("")) + 64, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDZambamboHealthBackObjects3Objects, (( gdjs.Test_32SceneCode.GDZambamboObjects3.length === 0 ) ? 0 :gdjs.Test_32SceneCode.GDZambamboObjects3[0].getPointX("")), (( gdjs.Test_32SceneCode.GDZambamboObjects3.length === 0 ) ? 0 :gdjs.Test_32SceneCode.GDZambamboObjects3[0].getPointY("")) + 64, "");
}{gdjs.evtTools.linkedObjects.linkObjects(runtimeScene, (gdjs.Test_32SceneCode.GDZambamboObjects3.length !== 0 ? gdjs.Test_32SceneCode.GDZambamboObjects3[0] : null), (gdjs.Test_32SceneCode.GDZambamboHealthObjects3.length !== 0 ? gdjs.Test_32SceneCode.GDZambamboHealthObjects3[0] : null));
}{gdjs.evtTools.linkedObjects.linkObjects(runtimeScene, (gdjs.Test_32SceneCode.GDZambamboObjects3.length !== 0 ? gdjs.Test_32SceneCode.GDZambamboObjects3[0] : null), (gdjs.Test_32SceneCode.GDZambamboHealthBackObjects3.length !== 0 ? gdjs.Test_32SceneCode.GDZambamboHealthBackObjects3[0] : null));
}}
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("SpawnPoint"), gdjs.Test_32SceneCode.GDSpawnPointObjects2);

for(gdjs.Test_32SceneCode.forEachIndex3 = 0;gdjs.Test_32SceneCode.forEachIndex3 < gdjs.Test_32SceneCode.GDSpawnPointObjects2.length;++gdjs.Test_32SceneCode.forEachIndex3) {
gdjs.Test_32SceneCode.GDSpawnPointObjects3.length = 0;


gdjs.Test_32SceneCode.forEachTemporary3 = gdjs.Test_32SceneCode.GDSpawnPointObjects2[gdjs.Test_32SceneCode.forEachIndex3];
gdjs.Test_32SceneCode.GDSpawnPointObjects3.push(gdjs.Test_32SceneCode.forEachTemporary3);
if (true) {
{for(var i = 0, len = gdjs.Test_32SceneCode.GDSpawnPointObjects3.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDSpawnPointObjects3[i].resetTimer("SpawnTimer");
}
}{for(var i = 0, len = gdjs.Test_32SceneCode.GDSpawnPointObjects3.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDSpawnPointObjects3[i].pauseTimer("SpawnTimer");
}
}
{ //Subevents: 
gdjs.Test_32SceneCode.eventsList2(runtimeScene);} //Subevents end.
}
}

}


{



}


{


{
gdjs.copyArray(runtimeScene.getObjects("DayText"), gdjs.Test_32SceneCode.GDDayTextObjects1);
gdjs.copyArray(runtimeScene.getObjects("NightText"), gdjs.Test_32SceneCode.GDNightTextObjects1);
{for(var i = 0, len = gdjs.Test_32SceneCode.GDDayTextObjects1.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDDayTextObjects1[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.Test_32SceneCode.GDNightTextObjects1.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDNightTextObjects1[i].setOpacity(0);
}
}}

}


};gdjs.Test_32SceneCode.eventsList4 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Test_32SceneCode.GDPlayerObjects1);
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.Test_32SceneCode.GDPlayerObjects1.length !== 0 ? gdjs.Test_32SceneCode.GDPlayerObjects1[0] : null), false, "", 0);
}}

}


};gdjs.Test_32SceneCode.eventsList5 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("BarricadeGhost"), gdjs.Test_32SceneCode.GDBarricadeGhostObjects2);
gdjs.copyArray(runtimeScene.getObjects("BarricadeShortGhost"), gdjs.Test_32SceneCode.GDBarricadeShortGhostObjects2);
gdjs.copyArray(runtimeScene.getObjects("BarricadeSpikesGhost"), gdjs.Test_32SceneCode.GDBarricadeSpikesGhostObjects2);
{for(var i = 0, len = gdjs.Test_32SceneCode.GDBarricadeGhostObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDBarricadeGhostObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Test_32SceneCode.GDBarricadeShortGhostObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDBarricadeShortGhostObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Test_32SceneCode.GDBarricadeSpikesGhostObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDBarricadeSpikesGhostObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.Test_32SceneCode.eventsList6 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("BarricadeGhost"), gdjs.Test_32SceneCode.GDBarricadeGhostObjects2);
gdjs.copyArray(runtimeScene.getObjects("BarricadeShortGhost"), gdjs.Test_32SceneCode.GDBarricadeShortGhostObjects2);
gdjs.copyArray(runtimeScene.getObjects("BarricadeSpikesGhost"), gdjs.Test_32SceneCode.GDBarricadeSpikesGhostObjects2);
{for(var i = 0, len = gdjs.Test_32SceneCode.GDBarricadeGhostObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDBarricadeGhostObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Test_32SceneCode.GDBarricadeShortGhostObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDBarricadeShortGhostObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Test_32SceneCode.GDBarricadeSpikesGhostObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDBarricadeSpikesGhostObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.Test_32SceneCode.eventsList7 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("BarricadeGhost"), gdjs.Test_32SceneCode.GDBarricadeGhostObjects2);
gdjs.copyArray(runtimeScene.getObjects("BarricadeShortGhost"), gdjs.Test_32SceneCode.GDBarricadeShortGhostObjects2);
gdjs.copyArray(runtimeScene.getObjects("BarricadeSpikesGhost"), gdjs.Test_32SceneCode.GDBarricadeSpikesGhostObjects2);
{for(var i = 0, len = gdjs.Test_32SceneCode.GDBarricadeGhostObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDBarricadeGhostObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Test_32SceneCode.GDBarricadeShortGhostObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDBarricadeShortGhostObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Test_32SceneCode.GDBarricadeSpikesGhostObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDBarricadeSpikesGhostObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.Test_32SceneCode.eventsList8 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("BarricadeGhost"), gdjs.Test_32SceneCode.GDBarricadeGhostObjects2);
gdjs.copyArray(runtimeScene.getObjects("BarricadeShortGhost"), gdjs.Test_32SceneCode.GDBarricadeShortGhostObjects2);
gdjs.copyArray(runtimeScene.getObjects("BarricadeSpikesGhost"), gdjs.Test_32SceneCode.GDBarricadeSpikesGhostObjects2);
{for(var i = 0, len = gdjs.Test_32SceneCode.GDBarricadeGhostObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDBarricadeGhostObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Test_32SceneCode.GDBarricadeShortGhostObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDBarricadeShortGhostObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Test_32SceneCode.GDBarricadeSpikesGhostObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDBarricadeSpikesGhostObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.Test_32SceneCode.eventsList9 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("BarricadeGhost"), gdjs.Test_32SceneCode.GDBarricadeGhostObjects2);
gdjs.copyArray(runtimeScene.getObjects("BarricadeShortGhost"), gdjs.Test_32SceneCode.GDBarricadeShortGhostObjects2);
gdjs.copyArray(runtimeScene.getObjects("BarricadeSpikesGhost"), gdjs.Test_32SceneCode.GDBarricadeSpikesGhostObjects2);
{for(var i = 0, len = gdjs.Test_32SceneCode.GDBarricadeGhostObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDBarricadeGhostObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Test_32SceneCode.GDBarricadeShortGhostObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDBarricadeShortGhostObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Test_32SceneCode.GDBarricadeSpikesGhostObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDBarricadeSpikesGhostObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBarricadeGhostObjects2Objects = Hashtable.newFrom({"BarricadeGhost": gdjs.Test_32SceneCode.GDBarricadeGhostObjects2});gdjs.Test_32SceneCode.eventsList10 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("BarricadeGhost"), gdjs.Test_32SceneCode.GDBarricadeGhostObjects2);
gdjs.copyArray(runtimeScene.getObjects("BarricadeShortGhost"), gdjs.Test_32SceneCode.GDBarricadeShortGhostObjects2);
gdjs.copyArray(runtimeScene.getObjects("BarricadeSpikesGhost"), gdjs.Test_32SceneCode.GDBarricadeSpikesGhostObjects2);
{for(var i = 0, len = gdjs.Test_32SceneCode.GDBarricadeGhostObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDBarricadeGhostObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Test_32SceneCode.GDBarricadeShortGhostObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDBarricadeShortGhostObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Test_32SceneCode.GDBarricadeSpikesGhostObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDBarricadeSpikesGhostObjects2[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBarricadeGhostObjects2Objects, gdjs.evtTools.input.getMouseX(runtimeScene, "", 0), gdjs.evtTools.input.getMouseY(runtimeScene, "", 0), "");
}{for(var i = 0, len = gdjs.Test_32SceneCode.GDBarricadeGhostObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDBarricadeGhostObjects2[i].setOpacity(100);
}
}}

}


};gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBarricadeShortGhostObjects2Objects = Hashtable.newFrom({"BarricadeShortGhost": gdjs.Test_32SceneCode.GDBarricadeShortGhostObjects2});gdjs.Test_32SceneCode.eventsList11 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("BarricadeGhost"), gdjs.Test_32SceneCode.GDBarricadeGhostObjects2);
gdjs.copyArray(runtimeScene.getObjects("BarricadeShortGhost"), gdjs.Test_32SceneCode.GDBarricadeShortGhostObjects2);
gdjs.copyArray(runtimeScene.getObjects("BarricadeSpikesGhost"), gdjs.Test_32SceneCode.GDBarricadeSpikesGhostObjects2);
{for(var i = 0, len = gdjs.Test_32SceneCode.GDBarricadeGhostObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDBarricadeGhostObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Test_32SceneCode.GDBarricadeShortGhostObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDBarricadeShortGhostObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Test_32SceneCode.GDBarricadeSpikesGhostObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDBarricadeSpikesGhostObjects2[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBarricadeShortGhostObjects2Objects, gdjs.evtTools.input.getMouseX(runtimeScene, "", 0), gdjs.evtTools.input.getMouseY(runtimeScene, "", 0), "");
}{for(var i = 0, len = gdjs.Test_32SceneCode.GDBarricadeShortGhostObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDBarricadeShortGhostObjects2[i].setOpacity(100);
}
}}

}


};gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBarricadeSpikesGhostObjects2Objects = Hashtable.newFrom({"BarricadeSpikesGhost": gdjs.Test_32SceneCode.GDBarricadeSpikesGhostObjects2});gdjs.Test_32SceneCode.eventsList12 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("BarricadeGhost"), gdjs.Test_32SceneCode.GDBarricadeGhostObjects2);
gdjs.copyArray(runtimeScene.getObjects("BarricadeShortGhost"), gdjs.Test_32SceneCode.GDBarricadeShortGhostObjects2);
gdjs.copyArray(runtimeScene.getObjects("BarricadeSpikesGhost"), gdjs.Test_32SceneCode.GDBarricadeSpikesGhostObjects2);
{for(var i = 0, len = gdjs.Test_32SceneCode.GDBarricadeGhostObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDBarricadeGhostObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Test_32SceneCode.GDBarricadeShortGhostObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDBarricadeShortGhostObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Test_32SceneCode.GDBarricadeSpikesGhostObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDBarricadeSpikesGhostObjects2[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBarricadeSpikesGhostObjects2Objects, gdjs.evtTools.input.getMouseX(runtimeScene, "", 0), gdjs.evtTools.input.getMouseY(runtimeScene, "", 0), "");
}{for(var i = 0, len = gdjs.Test_32SceneCode.GDBarricadeSpikesGhostObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDBarricadeSpikesGhostObjects2[i].setOpacity(100);
}
}}

}


};gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Test_32SceneCode.GDPlayerObjects2});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDMouseObjectObjects2Objects = Hashtable.newFrom({"MouseObject": gdjs.Test_32SceneCode.GDMouseObjectObjects2});gdjs.Test_32SceneCode.eventsList13 = function(runtimeScene) {

{



}


{


gdjs.Test_32SceneCode.condition0IsTrue_0.val = false;
{
gdjs.Test_32SceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Num1");
}if (gdjs.Test_32SceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("EquipUI"), gdjs.Test_32SceneCode.GDEquipUIObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Test_32SceneCode.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("SelectUI"), gdjs.Test_32SceneCode.GDSelectUIObjects2);
{for(var i = 0, len = gdjs.Test_32SceneCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDPlayerObjects2[i].returnVariable(gdjs.Test_32SceneCode.GDPlayerObjects2[i].getVariables().getFromIndex(2)).setString("Pistol");
}
}{for(var i = 0, len = gdjs.Test_32SceneCode.GDSelectUIObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDSelectUIObjects2[i].setPosition((( gdjs.Test_32SceneCode.GDEquipUIObjects2.length === 0 ) ? 0 :gdjs.Test_32SceneCode.GDEquipUIObjects2[0].getPointX("")) - 4,(( gdjs.Test_32SceneCode.GDEquipUIObjects2.length === 0 ) ? 0 :gdjs.Test_32SceneCode.GDEquipUIObjects2[0].getPointY("")) - 4);
}
}
{ //Subevents
gdjs.Test_32SceneCode.eventsList5(runtimeScene);} //End of subevents
}

}


{


gdjs.Test_32SceneCode.condition0IsTrue_0.val = false;
{
gdjs.Test_32SceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Num2");
}if (gdjs.Test_32SceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("EquipUI"), gdjs.Test_32SceneCode.GDEquipUIObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Test_32SceneCode.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("SelectUI"), gdjs.Test_32SceneCode.GDSelectUIObjects2);
{for(var i = 0, len = gdjs.Test_32SceneCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDPlayerObjects2[i].returnVariable(gdjs.Test_32SceneCode.GDPlayerObjects2[i].getVariables().getFromIndex(2)).setString("Shotgun");
}
}{for(var i = 0, len = gdjs.Test_32SceneCode.GDSelectUIObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDSelectUIObjects2[i].setPosition((( gdjs.Test_32SceneCode.GDEquipUIObjects2.length === 0 ) ? 0 :gdjs.Test_32SceneCode.GDEquipUIObjects2[0].getPointX("")) - 4 + 64,(( gdjs.Test_32SceneCode.GDEquipUIObjects2.length === 0 ) ? 0 :gdjs.Test_32SceneCode.GDEquipUIObjects2[0].getPointY("")) - 4);
}
}
{ //Subevents
gdjs.Test_32SceneCode.eventsList6(runtimeScene);} //End of subevents
}

}


{


gdjs.Test_32SceneCode.condition0IsTrue_0.val = false;
{
gdjs.Test_32SceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Num3");
}if (gdjs.Test_32SceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("EquipUI"), gdjs.Test_32SceneCode.GDEquipUIObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Test_32SceneCode.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("SelectUI"), gdjs.Test_32SceneCode.GDSelectUIObjects2);
{for(var i = 0, len = gdjs.Test_32SceneCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDPlayerObjects2[i].returnVariable(gdjs.Test_32SceneCode.GDPlayerObjects2[i].getVariables().getFromIndex(2)).setString("Sniper");
}
}{for(var i = 0, len = gdjs.Test_32SceneCode.GDSelectUIObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDSelectUIObjects2[i].setPosition((( gdjs.Test_32SceneCode.GDEquipUIObjects2.length === 0 ) ? 0 :gdjs.Test_32SceneCode.GDEquipUIObjects2[0].getPointX("")) - 4 + 128,(( gdjs.Test_32SceneCode.GDEquipUIObjects2.length === 0 ) ? 0 :gdjs.Test_32SceneCode.GDEquipUIObjects2[0].getPointY("")) - 4);
}
}
{ //Subevents
gdjs.Test_32SceneCode.eventsList7(runtimeScene);} //End of subevents
}

}


{


gdjs.Test_32SceneCode.condition0IsTrue_0.val = false;
{
gdjs.Test_32SceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Num4");
}if (gdjs.Test_32SceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("EquipUI"), gdjs.Test_32SceneCode.GDEquipUIObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Test_32SceneCode.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("SelectUI"), gdjs.Test_32SceneCode.GDSelectUIObjects2);
{for(var i = 0, len = gdjs.Test_32SceneCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDPlayerObjects2[i].returnVariable(gdjs.Test_32SceneCode.GDPlayerObjects2[i].getVariables().getFromIndex(2)).setString("Assault");
}
}{for(var i = 0, len = gdjs.Test_32SceneCode.GDSelectUIObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDSelectUIObjects2[i].setPosition((( gdjs.Test_32SceneCode.GDEquipUIObjects2.length === 0 ) ? 0 :gdjs.Test_32SceneCode.GDEquipUIObjects2[0].getPointX("")) - 4 + 192,(( gdjs.Test_32SceneCode.GDEquipUIObjects2.length === 0 ) ? 0 :gdjs.Test_32SceneCode.GDEquipUIObjects2[0].getPointY("")) - 4);
}
}
{ //Subevents
gdjs.Test_32SceneCode.eventsList8(runtimeScene);} //End of subevents
}

}


{


gdjs.Test_32SceneCode.condition0IsTrue_0.val = false;
{
gdjs.Test_32SceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Num5");
}if (gdjs.Test_32SceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("EquipUI"), gdjs.Test_32SceneCode.GDEquipUIObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Test_32SceneCode.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("SelectUI"), gdjs.Test_32SceneCode.GDSelectUIObjects2);
{for(var i = 0, len = gdjs.Test_32SceneCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDPlayerObjects2[i].returnVariable(gdjs.Test_32SceneCode.GDPlayerObjects2[i].getVariables().getFromIndex(2)).setString("Grenade");
}
}{for(var i = 0, len = gdjs.Test_32SceneCode.GDSelectUIObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDSelectUIObjects2[i].setPosition((( gdjs.Test_32SceneCode.GDEquipUIObjects2.length === 0 ) ? 0 :gdjs.Test_32SceneCode.GDEquipUIObjects2[0].getPointX("")) - 4 + 256,(( gdjs.Test_32SceneCode.GDEquipUIObjects2.length === 0 ) ? 0 :gdjs.Test_32SceneCode.GDEquipUIObjects2[0].getPointY("")) - 4);
}
}
{ //Subevents
gdjs.Test_32SceneCode.eventsList9(runtimeScene);} //End of subevents
}

}


{


gdjs.Test_32SceneCode.condition0IsTrue_0.val = false;
{
gdjs.Test_32SceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Num6");
}if (gdjs.Test_32SceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("EquipUI"), gdjs.Test_32SceneCode.GDEquipUIObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Test_32SceneCode.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("SelectUI"), gdjs.Test_32SceneCode.GDSelectUIObjects2);
{for(var i = 0, len = gdjs.Test_32SceneCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDPlayerObjects2[i].returnVariable(gdjs.Test_32SceneCode.GDPlayerObjects2[i].getVariables().getFromIndex(2)).setString("Barricade");
}
}{for(var i = 0, len = gdjs.Test_32SceneCode.GDSelectUIObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDSelectUIObjects2[i].setPosition((( gdjs.Test_32SceneCode.GDEquipUIObjects2.length === 0 ) ? 0 :gdjs.Test_32SceneCode.GDEquipUIObjects2[0].getPointX("")) - 4 + 320,(( gdjs.Test_32SceneCode.GDEquipUIObjects2.length === 0 ) ? 0 :gdjs.Test_32SceneCode.GDEquipUIObjects2[0].getPointY("")) - 4);
}
}
{ //Subevents
gdjs.Test_32SceneCode.eventsList10(runtimeScene);} //End of subevents
}

}


{


gdjs.Test_32SceneCode.condition0IsTrue_0.val = false;
{
gdjs.Test_32SceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Num7");
}if (gdjs.Test_32SceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("EquipUI"), gdjs.Test_32SceneCode.GDEquipUIObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Test_32SceneCode.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("SelectUI"), gdjs.Test_32SceneCode.GDSelectUIObjects2);
{for(var i = 0, len = gdjs.Test_32SceneCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDPlayerObjects2[i].returnVariable(gdjs.Test_32SceneCode.GDPlayerObjects2[i].getVariables().getFromIndex(2)).setString("Cover");
}
}{for(var i = 0, len = gdjs.Test_32SceneCode.GDSelectUIObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDSelectUIObjects2[i].setPosition((( gdjs.Test_32SceneCode.GDEquipUIObjects2.length === 0 ) ? 0 :gdjs.Test_32SceneCode.GDEquipUIObjects2[0].getPointX("")) - 4 + 384,(( gdjs.Test_32SceneCode.GDEquipUIObjects2.length === 0 ) ? 0 :gdjs.Test_32SceneCode.GDEquipUIObjects2[0].getPointY("")) - 4);
}
}
{ //Subevents
gdjs.Test_32SceneCode.eventsList11(runtimeScene);} //End of subevents
}

}


{


gdjs.Test_32SceneCode.condition0IsTrue_0.val = false;
{
gdjs.Test_32SceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Num8");
}if (gdjs.Test_32SceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("EquipUI"), gdjs.Test_32SceneCode.GDEquipUIObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Test_32SceneCode.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("SelectUI"), gdjs.Test_32SceneCode.GDSelectUIObjects2);
{for(var i = 0, len = gdjs.Test_32SceneCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDPlayerObjects2[i].returnVariable(gdjs.Test_32SceneCode.GDPlayerObjects2[i].getVariables().getFromIndex(2)).setString("Spikes");
}
}{for(var i = 0, len = gdjs.Test_32SceneCode.GDSelectUIObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDSelectUIObjects2[i].setPosition((( gdjs.Test_32SceneCode.GDEquipUIObjects2.length === 0 ) ? 0 :gdjs.Test_32SceneCode.GDEquipUIObjects2[0].getPointX("")) - 4 + 448,(( gdjs.Test_32SceneCode.GDEquipUIObjects2.length === 0 ) ? 0 :gdjs.Test_32SceneCode.GDEquipUIObjects2[0].getPointY("")) - 4);
}
}
{ //Subevents
gdjs.Test_32SceneCode.eventsList12(runtimeScene);} //End of subevents
}

}


{



}


{


{
gdjs.copyArray(runtimeScene.getObjects("Assault"), gdjs.Test_32SceneCode.GDAssaultObjects2);
gdjs.copyArray(runtimeScene.getObjects("AssaultAmmo"), gdjs.Test_32SceneCode.GDAssaultAmmoObjects2);
gdjs.copyArray(runtimeScene.getObjects("Pistol"), gdjs.Test_32SceneCode.GDPistolObjects2);
gdjs.copyArray(runtimeScene.getObjects("PistolAmmo"), gdjs.Test_32SceneCode.GDPistolAmmoObjects2);
gdjs.copyArray(runtimeScene.getObjects("Rifle"), gdjs.Test_32SceneCode.GDRifleObjects2);
gdjs.copyArray(runtimeScene.getObjects("RifleAmmo"), gdjs.Test_32SceneCode.GDRifleAmmoObjects2);
gdjs.copyArray(runtimeScene.getObjects("Shotgun"), gdjs.Test_32SceneCode.GDShotgunObjects2);
gdjs.copyArray(runtimeScene.getObjects("ShotgunAmmo"), gdjs.Test_32SceneCode.GDShotgunAmmoObjects2);
{for(var i = 0, len = gdjs.Test_32SceneCode.GDPistolAmmoObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDPistolAmmoObjects2[i].setString((gdjs.RuntimeObject.getVariableString(((gdjs.Test_32SceneCode.GDPistolObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Test_32SceneCode.GDPistolObjects2[0].getVariables()).getFromIndex(2))));
}
}{for(var i = 0, len = gdjs.Test_32SceneCode.GDShotgunAmmoObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDShotgunAmmoObjects2[i].setString((gdjs.RuntimeObject.getVariableString(((gdjs.Test_32SceneCode.GDShotgunObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Test_32SceneCode.GDShotgunObjects2[0].getVariables()).getFromIndex(2))));
}
}{for(var i = 0, len = gdjs.Test_32SceneCode.GDRifleAmmoObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDRifleAmmoObjects2[i].setString((gdjs.RuntimeObject.getVariableString(((gdjs.Test_32SceneCode.GDRifleObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Test_32SceneCode.GDRifleObjects2[0].getVariables()).getFromIndex(2))));
}
}{for(var i = 0, len = gdjs.Test_32SceneCode.GDAssaultAmmoObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDAssaultAmmoObjects2[i].setString((gdjs.RuntimeObject.getVariableString(((gdjs.Test_32SceneCode.GDAssaultObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Test_32SceneCode.GDAssaultObjects2[0].getVariables()).getFromIndex(2))));
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("BarricadeGhost"), gdjs.Test_32SceneCode.GDBarricadeGhostObjects2);
gdjs.copyArray(runtimeScene.getObjects("BarricadeShortGhost"), gdjs.Test_32SceneCode.GDBarricadeShortGhostObjects2);
gdjs.copyArray(runtimeScene.getObjects("BarricadeSpikesGhost"), gdjs.Test_32SceneCode.GDBarricadeSpikesGhostObjects2);
gdjs.copyArray(runtimeScene.getObjects("MouseObject"), gdjs.Test_32SceneCode.GDMouseObjectObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Test_32SceneCode.GDPlayerObjects2);

gdjs.Test_32SceneCode.condition0IsTrue_0.val = false;
gdjs.Test_32SceneCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Test_32SceneCode.GDBarricadeGhostObjects2.length;i<l;++i) {
    if ( gdjs.Test_32SceneCode.GDBarricadeGhostObjects2[i].isOnLayer("") ) {
        gdjs.Test_32SceneCode.condition0IsTrue_0.val = true;
        gdjs.Test_32SceneCode.GDBarricadeGhostObjects2[k] = gdjs.Test_32SceneCode.GDBarricadeGhostObjects2[i];
        ++k;
    }
}
gdjs.Test_32SceneCode.GDBarricadeGhostObjects2.length = k;for(var i = 0, k = 0, l = gdjs.Test_32SceneCode.GDBarricadeShortGhostObjects2.length;i<l;++i) {
    if ( gdjs.Test_32SceneCode.GDBarricadeShortGhostObjects2[i].isOnLayer("") ) {
        gdjs.Test_32SceneCode.condition0IsTrue_0.val = true;
        gdjs.Test_32SceneCode.GDBarricadeShortGhostObjects2[k] = gdjs.Test_32SceneCode.GDBarricadeShortGhostObjects2[i];
        ++k;
    }
}
gdjs.Test_32SceneCode.GDBarricadeShortGhostObjects2.length = k;for(var i = 0, k = 0, l = gdjs.Test_32SceneCode.GDBarricadeSpikesGhostObjects2.length;i<l;++i) {
    if ( gdjs.Test_32SceneCode.GDBarricadeSpikesGhostObjects2[i].isOnLayer("") ) {
        gdjs.Test_32SceneCode.condition0IsTrue_0.val = true;
        gdjs.Test_32SceneCode.GDBarricadeSpikesGhostObjects2[k] = gdjs.Test_32SceneCode.GDBarricadeSpikesGhostObjects2[i];
        ++k;
    }
}
gdjs.Test_32SceneCode.GDBarricadeSpikesGhostObjects2.length = k;}if ( gdjs.Test_32SceneCode.condition0IsTrue_0.val ) {
{
gdjs.Test_32SceneCode.condition1IsTrue_0.val = gdjs.evtTools.object.distanceTest(gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDPlayerObjects2Objects, gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDMouseObjectObjects2Objects, (gdjs.RuntimeObject.getVariableNumber(((gdjs.Test_32SceneCode.GDPlayerObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Test_32SceneCode.GDPlayerObjects2[0].getVariables()).getFromIndex(3))), false);
}}
if (gdjs.Test_32SceneCode.condition1IsTrue_0.val) {
/* Reuse gdjs.Test_32SceneCode.GDBarricadeGhostObjects2 */
/* Reuse gdjs.Test_32SceneCode.GDBarricadeShortGhostObjects2 */
/* Reuse gdjs.Test_32SceneCode.GDBarricadeSpikesGhostObjects2 */
{for(var i = 0, len = gdjs.Test_32SceneCode.GDBarricadeGhostObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDBarricadeGhostObjects2[i].setPosition(32 * (Math.round((gdjs.evtTools.input.getMouseX(runtimeScene, "", 0) - 16) / 32)),32 * (Math.round((gdjs.evtTools.input.getMouseY(runtimeScene, "", 0) - 32) / 32)));
}
}{for(var i = 0, len = gdjs.Test_32SceneCode.GDBarricadeShortGhostObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDBarricadeShortGhostObjects2[i].setPosition(32 * (Math.round((gdjs.evtTools.input.getMouseX(runtimeScene, "", 0) - 16) / 32)),32 * (Math.round((gdjs.evtTools.input.getMouseY(runtimeScene, "", 0) - 16) / 32)));
}
}{for(var i = 0, len = gdjs.Test_32SceneCode.GDBarricadeSpikesGhostObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDBarricadeSpikesGhostObjects2[i].setPosition(32 * (Math.round((gdjs.evtTools.input.getMouseX(runtimeScene, "", 0) - 16) / 32)),32 * (Math.round((gdjs.evtTools.input.getMouseY(runtimeScene, "", 0) - 16) / 32)));
}
}}

}


{



}


{


{
gdjs.copyArray(runtimeScene.getObjects("MouseObject"), gdjs.Test_32SceneCode.GDMouseObjectObjects1);
{for(var i = 0, len = gdjs.Test_32SceneCode.GDMouseObjectObjects1.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDMouseObjectObjects1[i].setPosition(gdjs.evtTools.input.getMouseX(runtimeScene, "", 0),gdjs.evtTools.input.getMouseY(runtimeScene, "", 0));
}
}}

}


};gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDZambamboObjects2Objects = Hashtable.newFrom({"Zambambo": gdjs.Test_32SceneCode.GDZambamboObjects2});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDZambamboHealthObjects2Objects = Hashtable.newFrom({"ZambamboHealth": gdjs.Test_32SceneCode.GDZambamboHealthObjects2});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDZambamboHealthBackObjects2Objects = Hashtable.newFrom({"ZambamboHealthBack": gdjs.Test_32SceneCode.GDZambamboHealthBackObjects2});gdjs.Test_32SceneCode.eventsList14 = function(runtimeScene) {

};gdjs.Test_32SceneCode.eventsList15 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("SpawnPoint"), gdjs.Test_32SceneCode.GDSpawnPointObjects1);

for(gdjs.Test_32SceneCode.forEachIndex2 = 0;gdjs.Test_32SceneCode.forEachIndex2 < gdjs.Test_32SceneCode.GDSpawnPointObjects1.length;++gdjs.Test_32SceneCode.forEachIndex2) {
gdjs.Test_32SceneCode.GDZambamboObjects2.length = 0;

gdjs.Test_32SceneCode.GDZambamboHealthObjects2.length = 0;

gdjs.Test_32SceneCode.GDZambamboHealthBackObjects2.length = 0;

gdjs.Test_32SceneCode.GDSpawnPointObjects2.length = 0;


gdjs.Test_32SceneCode.forEachTemporary2 = gdjs.Test_32SceneCode.GDSpawnPointObjects1[gdjs.Test_32SceneCode.forEachIndex2];
gdjs.Test_32SceneCode.GDSpawnPointObjects2.push(gdjs.Test_32SceneCode.forEachTemporary2);
gdjs.Test_32SceneCode.condition0IsTrue_0.val = false;
gdjs.Test_32SceneCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Test_32SceneCode.GDSpawnPointObjects2.length;i<l;++i) {
    if ( gdjs.Test_32SceneCode.GDSpawnPointObjects2[i].getVariableNumber(gdjs.Test_32SceneCode.GDSpawnPointObjects2[i].getVariables().getFromIndex(0)) == 1 ) {
        gdjs.Test_32SceneCode.condition0IsTrue_0.val = true;
        gdjs.Test_32SceneCode.GDSpawnPointObjects2[k] = gdjs.Test_32SceneCode.GDSpawnPointObjects2[i];
        ++k;
    }
}
gdjs.Test_32SceneCode.GDSpawnPointObjects2.length = k;}if ( gdjs.Test_32SceneCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Test_32SceneCode.GDSpawnPointObjects2.length;i<l;++i) {
    if ( gdjs.Test_32SceneCode.GDSpawnPointObjects2[i].getTimerElapsedTimeInSecondsOrNaN("SpawnTimer") > 10 ) {
        gdjs.Test_32SceneCode.condition1IsTrue_0.val = true;
        gdjs.Test_32SceneCode.GDSpawnPointObjects2[k] = gdjs.Test_32SceneCode.GDSpawnPointObjects2[i];
        ++k;
    }
}
gdjs.Test_32SceneCode.GDSpawnPointObjects2.length = k;}}
if (gdjs.Test_32SceneCode.condition1IsTrue_0.val) {
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDZambamboObjects2Objects, (( gdjs.Test_32SceneCode.GDSpawnPointObjects2.length === 0 ) ? 0 :gdjs.Test_32SceneCode.GDSpawnPointObjects2[0].getPointX("")), (( gdjs.Test_32SceneCode.GDSpawnPointObjects2.length === 0 ) ? 0 :gdjs.Test_32SceneCode.GDSpawnPointObjects2[0].getPointY("")), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDZambamboHealthObjects2Objects, (( gdjs.Test_32SceneCode.GDZambamboObjects2.length === 0 ) ? 0 :gdjs.Test_32SceneCode.GDZambamboObjects2[0].getPointX("")), (( gdjs.Test_32SceneCode.GDZambamboObjects2.length === 0 ) ? 0 :gdjs.Test_32SceneCode.GDZambamboObjects2[0].getPointY("")) + 64, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDZambamboHealthBackObjects2Objects, (( gdjs.Test_32SceneCode.GDZambamboObjects2.length === 0 ) ? 0 :gdjs.Test_32SceneCode.GDZambamboObjects2[0].getPointX("")), (( gdjs.Test_32SceneCode.GDZambamboObjects2.length === 0 ) ? 0 :gdjs.Test_32SceneCode.GDZambamboObjects2[0].getPointY("")) + 64, "");
}{gdjs.evtTools.linkedObjects.linkObjects(runtimeScene, (gdjs.Test_32SceneCode.GDZambamboObjects2.length !== 0 ? gdjs.Test_32SceneCode.GDZambamboObjects2[0] : null), (gdjs.Test_32SceneCode.GDZambamboHealthObjects2.length !== 0 ? gdjs.Test_32SceneCode.GDZambamboHealthObjects2[0] : null));
}{gdjs.evtTools.linkedObjects.linkObjects(runtimeScene, (gdjs.Test_32SceneCode.GDZambamboObjects2.length !== 0 ? gdjs.Test_32SceneCode.GDZambamboObjects2[0] : null), (gdjs.Test_32SceneCode.GDZambamboHealthBackObjects2.length !== 0 ? gdjs.Test_32SceneCode.GDZambamboHealthBackObjects2[0] : null));
}{for(var i = 0, len = gdjs.Test_32SceneCode.GDSpawnPointObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDSpawnPointObjects2[i].resetTimer("SpawnTimer");
}
}}
}

}


};gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDZambamboHealthObjects3Objects = Hashtable.newFrom({"ZambamboHealth": gdjs.Test_32SceneCode.GDZambamboHealthObjects3});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDZambamboHealthBackObjects3Objects = Hashtable.newFrom({"ZambamboHealthBack": gdjs.Test_32SceneCode.GDZambamboHealthBackObjects3});gdjs.Test_32SceneCode.eventsList16 = function(runtimeScene) {

};gdjs.Test_32SceneCode.eventsList17 = function(runtimeScene) {

};gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDPlayerObjects3ObjectsGDgdjs_46Test_9532SceneCode_46GDWallObjects3ObjectsGDgdjs_46Test_9532SceneCode_46GDBarricadeObjects3Objects = Hashtable.newFrom({"Player": gdjs.Test_32SceneCode.GDPlayerObjects3, "Wall": gdjs.Test_32SceneCode.GDWallObjects3, "Barricade": gdjs.Test_32SceneCode.GDBarricadeObjects3});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDPlayerObjects4Objects = Hashtable.newFrom({"Player": gdjs.Test_32SceneCode.GDPlayerObjects4});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDPlayerObjects4Objects = Hashtable.newFrom({"Player": gdjs.Test_32SceneCode.GDPlayerObjects4});gdjs.Test_32SceneCode.eventsList18 = function(runtimeScene) {

{



}


{

gdjs.copyArray(gdjs.Test_32SceneCode.GDPlayerObjects3, gdjs.Test_32SceneCode.GDPlayerObjects4);


gdjs.Test_32SceneCode.condition0IsTrue_0.val = false;
{
gdjs.Test_32SceneCode.condition0IsTrue_0.val = gdjs.evtTools.object.pickedObjectsCount(gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDPlayerObjects4Objects) > 0;
}if (gdjs.Test_32SceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.Test_32SceneCode.GDZambamboObjects3, gdjs.Test_32SceneCode.GDZambamboObjects4);

{for(var i = 0, len = gdjs.Test_32SceneCode.GDZambamboObjects4.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDZambamboObjects4[i].returnVariable(gdjs.Test_32SceneCode.GDZambamboObjects4[i].getVariables().getFromIndex(0)).setNumber(1);
}
}}

}


{

gdjs.copyArray(gdjs.Test_32SceneCode.GDPlayerObjects3, gdjs.Test_32SceneCode.GDPlayerObjects4);


gdjs.Test_32SceneCode.condition0IsTrue_0.val = false;
{
gdjs.Test_32SceneCode.condition0IsTrue_0.val = gdjs.evtTools.object.pickedObjectsCount(gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDPlayerObjects4Objects) == 0;
}if (gdjs.Test_32SceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.Test_32SceneCode.GDZambamboObjects3, gdjs.Test_32SceneCode.GDZambamboObjects4);

{for(var i = 0, len = gdjs.Test_32SceneCode.GDZambamboObjects4.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDZambamboObjects4[i].returnVariable(gdjs.Test_32SceneCode.GDZambamboObjects4[i].getVariables().getFromIndex(0)).setNumber(0);
}
}}

}


};gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDZambamboObjects2Objects = Hashtable.newFrom({"Zambambo": gdjs.Test_32SceneCode.GDZambamboObjects2});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBarricadeObjects2Objects = Hashtable.newFrom({"Barricade": gdjs.Test_32SceneCode.GDBarricadeObjects2});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDZambamboObjects2Objects = Hashtable.newFrom({"Zambambo": gdjs.Test_32SceneCode.GDZambamboObjects2});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBarricadeShortObjects2Objects = Hashtable.newFrom({"BarricadeShort": gdjs.Test_32SceneCode.GDBarricadeShortObjects2});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDZambamboObjects2Objects = Hashtable.newFrom({"Zambambo": gdjs.Test_32SceneCode.GDZambamboObjects2});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBarricadeObjects2Objects = Hashtable.newFrom({"Barricade": gdjs.Test_32SceneCode.GDBarricadeObjects2});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDZambamboObjects2Objects = Hashtable.newFrom({"Zambambo": gdjs.Test_32SceneCode.GDZambamboObjects2});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBarricadeShortObjects2Objects = Hashtable.newFrom({"BarricadeShort": gdjs.Test_32SceneCode.GDBarricadeShortObjects2});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDZambamboObjects2Objects = Hashtable.newFrom({"Zambambo": gdjs.Test_32SceneCode.GDZambamboObjects2});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Test_32SceneCode.GDPlayerObjects2});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDZambamboHealthObjects1Objects = Hashtable.newFrom({"ZambamboHealth": gdjs.Test_32SceneCode.GDZambamboHealthObjects1});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDZambamboHealthBackObjects1Objects = Hashtable.newFrom({"ZambamboHealthBack": gdjs.Test_32SceneCode.GDZambamboHealthBackObjects1});gdjs.Test_32SceneCode.eventsList19 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Zambambo"), gdjs.Test_32SceneCode.GDZambamboObjects2);

for(gdjs.Test_32SceneCode.forEachIndex3 = 0;gdjs.Test_32SceneCode.forEachIndex3 < gdjs.Test_32SceneCode.GDZambamboObjects2.length;++gdjs.Test_32SceneCode.forEachIndex3) {
gdjs.copyArray(runtimeScene.getObjects("ZambamboHealth"), gdjs.Test_32SceneCode.GDZambamboHealthObjects3);
gdjs.copyArray(runtimeScene.getObjects("ZambamboHealthBack"), gdjs.Test_32SceneCode.GDZambamboHealthBackObjects3);
gdjs.Test_32SceneCode.GDZambamboObjects3.length = 0;


gdjs.Test_32SceneCode.forEachTemporary3 = gdjs.Test_32SceneCode.GDZambamboObjects2[gdjs.Test_32SceneCode.forEachIndex3];
gdjs.Test_32SceneCode.GDZambamboObjects3.push(gdjs.Test_32SceneCode.forEachTemporary3);
gdjs.Test_32SceneCode.condition0IsTrue_0.val = false;
gdjs.Test_32SceneCode.condition1IsTrue_0.val = false;
{
gdjs.Test_32SceneCode.condition0IsTrue_0.val = gdjs.evtTools.linkedObjects.pickObjectsLinkedTo(runtimeScene, gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDZambamboHealthObjects3Objects, (gdjs.Test_32SceneCode.GDZambamboObjects3.length !== 0 ? gdjs.Test_32SceneCode.GDZambamboObjects3[0] : null), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}if ( gdjs.Test_32SceneCode.condition0IsTrue_0.val ) {
{
gdjs.Test_32SceneCode.condition1IsTrue_0.val = gdjs.evtTools.linkedObjects.pickObjectsLinkedTo(runtimeScene, gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDZambamboHealthBackObjects3Objects, (gdjs.Test_32SceneCode.GDZambamboObjects3.length !== 0 ? gdjs.Test_32SceneCode.GDZambamboObjects3[0] : null), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}
if (gdjs.Test_32SceneCode.condition1IsTrue_0.val) {
{for(var i = 0, len = gdjs.Test_32SceneCode.GDZambamboHealthObjects3.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDZambamboHealthObjects3[i].setPosition((( gdjs.Test_32SceneCode.GDZambamboObjects3.length === 0 ) ? 0 :gdjs.Test_32SceneCode.GDZambamboObjects3[0].getPointX("")),(( gdjs.Test_32SceneCode.GDZambamboObjects3.length === 0 ) ? 0 :gdjs.Test_32SceneCode.GDZambamboObjects3[0].getPointY("")) + 64);
}
}{for(var i = 0, len = gdjs.Test_32SceneCode.GDZambamboHealthBackObjects3.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDZambamboHealthBackObjects3[i].setPosition((( gdjs.Test_32SceneCode.GDZambamboObjects3.length === 0 ) ? 0 :gdjs.Test_32SceneCode.GDZambamboObjects3[0].getPointX("")),(( gdjs.Test_32SceneCode.GDZambamboObjects3.length === 0 ) ? 0 :gdjs.Test_32SceneCode.GDZambamboObjects3[0].getPointY("")) + 64);
}
}}
}

}


{



}


{


{
gdjs.copyArray(runtimeScene.getObjects("Zambambo"), gdjs.Test_32SceneCode.GDZambamboObjects2);
{for(var i = 0, len = gdjs.Test_32SceneCode.GDZambamboObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDZambamboObjects2[i].getBehavior("Pathfinding").setMaxSpeed((255 - gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(2))));
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Zambambo"), gdjs.Test_32SceneCode.GDZambamboObjects2);

for(gdjs.Test_32SceneCode.forEachIndex3 = 0;gdjs.Test_32SceneCode.forEachIndex3 < gdjs.Test_32SceneCode.GDZambamboObjects2.length;++gdjs.Test_32SceneCode.forEachIndex3) {
gdjs.Test_32SceneCode.GDZambamboObjects3.length = 0;


gdjs.Test_32SceneCode.forEachTemporary3 = gdjs.Test_32SceneCode.GDZambamboObjects2[gdjs.Test_32SceneCode.forEachIndex3];
gdjs.Test_32SceneCode.GDZambamboObjects3.push(gdjs.Test_32SceneCode.forEachTemporary3);
if (true) {
{for(var i = 0, len = gdjs.Test_32SceneCode.GDZambamboObjects3.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDZambamboObjects3[i].setZOrder((gdjs.Test_32SceneCode.GDZambamboObjects3[i].getCenterYInScene()));
}
}}
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Zambambo"), gdjs.Test_32SceneCode.GDZambamboObjects2);

for(gdjs.Test_32SceneCode.forEachIndex3 = 0;gdjs.Test_32SceneCode.forEachIndex3 < gdjs.Test_32SceneCode.GDZambamboObjects2.length;++gdjs.Test_32SceneCode.forEachIndex3) {
gdjs.copyArray(runtimeScene.getObjects("Barricade"), gdjs.Test_32SceneCode.GDBarricadeObjects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Test_32SceneCode.GDPlayerObjects3);
gdjs.copyArray(runtimeScene.getObjects("Wall"), gdjs.Test_32SceneCode.GDWallObjects3);
gdjs.Test_32SceneCode.GDZambamboObjects3.length = 0;


gdjs.Test_32SceneCode.forEachTemporary3 = gdjs.Test_32SceneCode.GDZambamboObjects2[gdjs.Test_32SceneCode.forEachIndex3];
gdjs.Test_32SceneCode.GDZambamboObjects3.push(gdjs.Test_32SceneCode.forEachTemporary3);
gdjs.Test_32SceneCode.condition0IsTrue_0.val = false;
{
gdjs.Test_32SceneCode.condition0IsTrue_0.val = gdjs.evtTools.object.raycastObject(gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDPlayerObjects3ObjectsGDgdjs_46Test_9532SceneCode_46GDWallObjects3ObjectsGDgdjs_46Test_9532SceneCode_46GDBarricadeObjects3Objects, (( gdjs.Test_32SceneCode.GDZambamboObjects3.length === 0 ) ? 0 :gdjs.Test_32SceneCode.GDZambamboObjects3[0].getCenterXInScene()), (( gdjs.Test_32SceneCode.GDZambamboObjects3.length === 0 ) ? 0 :gdjs.Test_32SceneCode.GDZambamboObjects3[0].getCenterYInScene()), (( gdjs.Test_32SceneCode.GDZambamboObjects3.length === 0 ) ? 0 :gdjs.Test_32SceneCode.GDZambamboObjects3[0].getAngleToObject((gdjs.Test_32SceneCode.GDPlayerObjects3.length !== 0 ? gdjs.Test_32SceneCode.GDPlayerObjects3[0] : null))), 600, runtimeScene.getVariables().getFromIndex(0), runtimeScene.getVariables().getFromIndex(1), false);
}if (gdjs.Test_32SceneCode.condition0IsTrue_0.val) {

{ //Subevents: 
gdjs.Test_32SceneCode.eventsList18(runtimeScene);} //Subevents end.
}
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Zambambo"), gdjs.Test_32SceneCode.GDZambamboObjects2);

gdjs.Test_32SceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Test_32SceneCode.GDZambamboObjects2.length;i<l;++i) {
    if ( gdjs.Test_32SceneCode.GDZambamboObjects2[i].getVariableNumber(gdjs.Test_32SceneCode.GDZambamboObjects2[i].getVariables().getFromIndex(0)) == 1 ) {
        gdjs.Test_32SceneCode.condition0IsTrue_0.val = true;
        gdjs.Test_32SceneCode.GDZambamboObjects2[k] = gdjs.Test_32SceneCode.GDZambamboObjects2[i];
        ++k;
    }
}
gdjs.Test_32SceneCode.GDZambamboObjects2.length = k;}if (gdjs.Test_32SceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Test_32SceneCode.GDPlayerObjects2);
/* Reuse gdjs.Test_32SceneCode.GDZambamboObjects2 */
{for(var i = 0, len = gdjs.Test_32SceneCode.GDZambamboObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDZambamboObjects2[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.Test_32SceneCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Test_32SceneCode.GDPlayerObjects2[0].getPointX("")) + gdjs.random(60), (( gdjs.Test_32SceneCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Test_32SceneCode.GDPlayerObjects2[0].getPointY("")) + gdjs.random(60));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Barricade"), gdjs.Test_32SceneCode.GDBarricadeObjects2);
gdjs.copyArray(runtimeScene.getObjects("Zambambo"), gdjs.Test_32SceneCode.GDZambamboObjects2);

gdjs.Test_32SceneCode.condition0IsTrue_0.val = false;
{
gdjs.Test_32SceneCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDZambamboObjects2Objects, gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBarricadeObjects2Objects, false, runtimeScene, true);
}if (gdjs.Test_32SceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Test_32SceneCode.GDBarricadeObjects2 */
/* Reuse gdjs.Test_32SceneCode.GDZambamboObjects2 */
{for(var i = 0, len = gdjs.Test_32SceneCode.GDZambamboObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDZambamboObjects2[i].activateBehavior("Pathfinding", false);
}
}{for(var i = 0, len = gdjs.Test_32SceneCode.GDBarricadeObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDBarricadeObjects2[i].getBehavior("Health").Hit((gdjs.RuntimeObject.getVariableNumber(((gdjs.Test_32SceneCode.GDZambamboObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Test_32SceneCode.GDZambamboObjects2[0].getVariables()).getFromIndex(1))), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("BarricadeShort"), gdjs.Test_32SceneCode.GDBarricadeShortObjects2);
gdjs.copyArray(runtimeScene.getObjects("Zambambo"), gdjs.Test_32SceneCode.GDZambamboObjects2);

gdjs.Test_32SceneCode.condition0IsTrue_0.val = false;
{
gdjs.Test_32SceneCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDZambamboObjects2Objects, gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBarricadeShortObjects2Objects, false, runtimeScene, true);
}if (gdjs.Test_32SceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Test_32SceneCode.GDBarricadeShortObjects2 */
/* Reuse gdjs.Test_32SceneCode.GDZambamboObjects2 */
{for(var i = 0, len = gdjs.Test_32SceneCode.GDZambamboObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDZambamboObjects2[i].activateBehavior("Pathfinding", false);
}
}{for(var i = 0, len = gdjs.Test_32SceneCode.GDBarricadeShortObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDBarricadeShortObjects2[i].getBehavior("Health").Hit((gdjs.RuntimeObject.getVariableNumber(((gdjs.Test_32SceneCode.GDZambamboObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Test_32SceneCode.GDZambamboObjects2[0].getVariables()).getFromIndex(1))), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Barricade"), gdjs.Test_32SceneCode.GDBarricadeObjects2);
gdjs.copyArray(runtimeScene.getObjects("BarricadeShort"), gdjs.Test_32SceneCode.GDBarricadeShortObjects2);
gdjs.copyArray(runtimeScene.getObjects("Zambambo"), gdjs.Test_32SceneCode.GDZambamboObjects2);

gdjs.Test_32SceneCode.condition0IsTrue_0.val = false;
gdjs.Test_32SceneCode.condition1IsTrue_0.val = false;
{
gdjs.Test_32SceneCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDZambamboObjects2Objects, gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBarricadeObjects2Objects, true, runtimeScene, false);
}if ( gdjs.Test_32SceneCode.condition0IsTrue_0.val ) {
{
gdjs.Test_32SceneCode.condition1IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDZambamboObjects2Objects, gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBarricadeShortObjects2Objects, true, runtimeScene, false);
}}
if (gdjs.Test_32SceneCode.condition1IsTrue_0.val) {
/* Reuse gdjs.Test_32SceneCode.GDZambamboObjects2 */
{for(var i = 0, len = gdjs.Test_32SceneCode.GDZambamboObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDZambamboObjects2[i].activateBehavior("Pathfinding", true);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Test_32SceneCode.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Zambambo"), gdjs.Test_32SceneCode.GDZambamboObjects2);

gdjs.Test_32SceneCode.condition0IsTrue_0.val = false;
{
gdjs.Test_32SceneCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDZambamboObjects2Objects, gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDPlayerObjects2Objects, false, runtimeScene, false);
}if (gdjs.Test_32SceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Test_32SceneCode.GDPlayerObjects2 */
/* Reuse gdjs.Test_32SceneCode.GDZambamboObjects2 */
{for(var i = 0, len = gdjs.Test_32SceneCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDPlayerObjects2[i].getBehavior("Health").Hit((gdjs.RuntimeObject.getVariableNumber(((gdjs.Test_32SceneCode.GDZambamboObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Test_32SceneCode.GDZambamboObjects2[0].getVariables()).getFromIndex(1))), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Zambambo"), gdjs.Test_32SceneCode.GDZambamboObjects1);
gdjs.copyArray(runtimeScene.getObjects("ZambamboHealth"), gdjs.Test_32SceneCode.GDZambamboHealthObjects1);
gdjs.copyArray(runtimeScene.getObjects("ZambamboHealthBack"), gdjs.Test_32SceneCode.GDZambamboHealthBackObjects1);

gdjs.Test_32SceneCode.condition0IsTrue_0.val = false;
gdjs.Test_32SceneCode.condition1IsTrue_0.val = false;
gdjs.Test_32SceneCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Test_32SceneCode.GDZambamboObjects1.length;i<l;++i) {
    if ( gdjs.Test_32SceneCode.GDZambamboObjects1[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.Test_32SceneCode.condition0IsTrue_0.val = true;
        gdjs.Test_32SceneCode.GDZambamboObjects1[k] = gdjs.Test_32SceneCode.GDZambamboObjects1[i];
        ++k;
    }
}
gdjs.Test_32SceneCode.GDZambamboObjects1.length = k;}if ( gdjs.Test_32SceneCode.condition0IsTrue_0.val ) {
{
gdjs.Test_32SceneCode.condition1IsTrue_0.val = gdjs.evtTools.linkedObjects.pickObjectsLinkedTo(runtimeScene, gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDZambamboHealthObjects1Objects, (gdjs.Test_32SceneCode.GDZambamboObjects1.length !== 0 ? gdjs.Test_32SceneCode.GDZambamboObjects1[0] : null), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}if ( gdjs.Test_32SceneCode.condition1IsTrue_0.val ) {
{
gdjs.Test_32SceneCode.condition2IsTrue_0.val = gdjs.evtTools.linkedObjects.pickObjectsLinkedTo(runtimeScene, gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDZambamboHealthBackObjects1Objects, (gdjs.Test_32SceneCode.GDZambamboObjects1.length !== 0 ? gdjs.Test_32SceneCode.GDZambamboObjects1[0] : null), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}
}
if (gdjs.Test_32SceneCode.condition2IsTrue_0.val) {
/* Reuse gdjs.Test_32SceneCode.GDZambamboObjects1 */
/* Reuse gdjs.Test_32SceneCode.GDZambamboHealthObjects1 */
/* Reuse gdjs.Test_32SceneCode.GDZambamboHealthBackObjects1 */
{for(var i = 0, len = gdjs.Test_32SceneCode.GDZambamboHealthObjects1.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDZambamboHealthObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Test_32SceneCode.GDZambamboHealthBackObjects1.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDZambamboHealthBackObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Test_32SceneCode.GDZambamboObjects1.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDZambamboObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDPlayerHeadObjects2Objects = Hashtable.newFrom({"PlayerHead": gdjs.Test_32SceneCode.GDPlayerHeadObjects2});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDWallObjects2Objects = Hashtable.newFrom({"Wall": gdjs.Test_32SceneCode.GDWallObjects2});gdjs.Test_32SceneCode.eventsList20 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("PlayerHead"), gdjs.Test_32SceneCode.GDPlayerHeadObjects2);
gdjs.copyArray(runtimeScene.getObjects("Wall"), gdjs.Test_32SceneCode.GDWallObjects2);

gdjs.Test_32SceneCode.condition0IsTrue_0.val = false;
{
gdjs.Test_32SceneCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDPlayerHeadObjects2Objects, gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDWallObjects2Objects, false, runtimeScene, true);
}if (gdjs.Test_32SceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Test_32SceneCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.Test_32SceneCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDPlayerObjects2[i].setZOrder(100000);
}
}}

}


};gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Test_32SceneCode.GDPlayerObjects2});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDWallObjects2Objects = Hashtable.newFrom({"Wall": gdjs.Test_32SceneCode.GDWallObjects2});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDWallObjects2Objects = Hashtable.newFrom({"Wall": gdjs.Test_32SceneCode.GDWallObjects2});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Test_32SceneCode.GDPlayerObjects2});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDFakewallObjects2Objects = Hashtable.newFrom({"Fakewall": gdjs.Test_32SceneCode.GDFakewallObjects2});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDFakewallObjects2Objects = Hashtable.newFrom({"Fakewall": gdjs.Test_32SceneCode.GDFakewallObjects2});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Test_32SceneCode.GDPlayerObjects2});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDtempwall1Objects2Objects = Hashtable.newFrom({"tempwall1": gdjs.Test_32SceneCode.GDtempwall1Objects2});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDtempwall1Objects2Objects = Hashtable.newFrom({"tempwall1": gdjs.Test_32SceneCode.GDtempwall1Objects2});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Test_32SceneCode.GDPlayerObjects2});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDtempwall2Objects2Objects = Hashtable.newFrom({"tempwall2": gdjs.Test_32SceneCode.GDtempwall2Objects2});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDtempwall2Objects2Objects = Hashtable.newFrom({"tempwall2": gdjs.Test_32SceneCode.GDtempwall2Objects2});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Test_32SceneCode.GDPlayerObjects2});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBarricadeObjects2Objects = Hashtable.newFrom({"Barricade": gdjs.Test_32SceneCode.GDBarricadeObjects2});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBarricadeObjects2Objects = Hashtable.newFrom({"Barricade": gdjs.Test_32SceneCode.GDBarricadeObjects2});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Test_32SceneCode.GDPlayerObjects1});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBarricadeShortObjects1Objects = Hashtable.newFrom({"BarricadeShort": gdjs.Test_32SceneCode.GDBarricadeShortObjects1});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBarricadeShortObjects1Objects = Hashtable.newFrom({"BarricadeShort": gdjs.Test_32SceneCode.GDBarricadeShortObjects1});gdjs.Test_32SceneCode.eventsList21 = function(runtimeScene) {

{


gdjs.Test_32SceneCode.condition0IsTrue_0.val = false;
{
gdjs.Test_32SceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "w");
}if (gdjs.Test_32SceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Test_32SceneCode.GDPlayerObjects2);
{for(var i = 0, len = gdjs.Test_32SceneCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDPlayerObjects2[i].addForce(0, -((gdjs.RuntimeObject.getVariableNumber(gdjs.Test_32SceneCode.GDPlayerObjects2[i].getVariables().getFromIndex(0)))), 0);
}
}}

}


{


gdjs.Test_32SceneCode.condition0IsTrue_0.val = false;
{
gdjs.Test_32SceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
}if (gdjs.Test_32SceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Test_32SceneCode.GDPlayerObjects2);
{for(var i = 0, len = gdjs.Test_32SceneCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDPlayerObjects2[i].addForce(-((gdjs.RuntimeObject.getVariableNumber(gdjs.Test_32SceneCode.GDPlayerObjects2[i].getVariables().getFromIndex(0)))), 0, 0);
}
}{for(var i = 0, len = gdjs.Test_32SceneCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDPlayerObjects2[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.Test_32SceneCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDPlayerObjects2[i].flipX(true);
}
}}

}


{


gdjs.Test_32SceneCode.condition0IsTrue_0.val = false;
{
gdjs.Test_32SceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "a");
}if (gdjs.Test_32SceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Test_32SceneCode.GDPlayerObjects2);
{for(var i = 0, len = gdjs.Test_32SceneCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDPlayerObjects2[i].setAnimation(0);
}
}}

}


{


gdjs.Test_32SceneCode.condition0IsTrue_0.val = false;
{
gdjs.Test_32SceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "s");
}if (gdjs.Test_32SceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Test_32SceneCode.GDPlayerObjects2);
{for(var i = 0, len = gdjs.Test_32SceneCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDPlayerObjects2[i].addForce(0, (gdjs.RuntimeObject.getVariableNumber(gdjs.Test_32SceneCode.GDPlayerObjects2[i].getVariables().getFromIndex(0))), 0);
}
}}

}


{


gdjs.Test_32SceneCode.condition0IsTrue_0.val = false;
{
gdjs.Test_32SceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
}if (gdjs.Test_32SceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Test_32SceneCode.GDPlayerObjects2);
{for(var i = 0, len = gdjs.Test_32SceneCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDPlayerObjects2[i].addForce((gdjs.RuntimeObject.getVariableNumber(gdjs.Test_32SceneCode.GDPlayerObjects2[i].getVariables().getFromIndex(0))), 0, 0);
}
}{for(var i = 0, len = gdjs.Test_32SceneCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDPlayerObjects2[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.Test_32SceneCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDPlayerObjects2[i].flipX(false);
}
}}

}


{


gdjs.Test_32SceneCode.condition0IsTrue_0.val = false;
{
gdjs.Test_32SceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "d");
}if (gdjs.Test_32SceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Test_32SceneCode.GDPlayerObjects2);
{for(var i = 0, len = gdjs.Test_32SceneCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDPlayerObjects2[i].setAnimation(0);
}
}}

}


{



}


{


{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Test_32SceneCode.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("PlayerHead"), gdjs.Test_32SceneCode.GDPlayerHeadObjects2);
{for(var i = 0, len = gdjs.Test_32SceneCode.GDPlayerHeadObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDPlayerHeadObjects2[i].setPosition((( gdjs.Test_32SceneCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Test_32SceneCode.GDPlayerObjects2[0].getPointX("")),(( gdjs.Test_32SceneCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Test_32SceneCode.GDPlayerObjects2[0].getPointY("")));
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Test_32SceneCode.GDPlayerObjects2);
{for(var i = 0, len = gdjs.Test_32SceneCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDPlayerObjects2[i].setZOrder((gdjs.Test_32SceneCode.GDPlayerObjects2[i].getCenterYInScene()));
}
}
{ //Subevents
gdjs.Test_32SceneCode.eventsList20(runtimeScene);} //End of subevents
}

}


{



}


{


{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Test_32SceneCode.GDPlayerObjects2);
{for(var i = 0, len = gdjs.Test_32SceneCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDPlayerObjects2[i].setAnimationName("Walking" + gdjs.evtTools.common.toString(Math.round((gdjs.Test_32SceneCode.GDPlayerObjects2[i].getAngle()) / 90) * 90));
}
}}

}


{



}


{


{
gdjs.copyArray(runtimeScene.getObjects("Health"), gdjs.Test_32SceneCode.GDHealthObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Test_32SceneCode.GDPlayerObjects2);
{for(var i = 0, len = gdjs.Test_32SceneCode.GDHealthObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDHealthObjects2[i].setWidth(((( gdjs.Test_32SceneCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Test_32SceneCode.GDPlayerObjects2[0].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) * 64) / 10);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Test_32SceneCode.GDPlayerObjects2);

gdjs.Test_32SceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Test_32SceneCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Test_32SceneCode.GDPlayerObjects2[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.Test_32SceneCode.condition0IsTrue_0.val = true;
        gdjs.Test_32SceneCode.GDPlayerObjects2[k] = gdjs.Test_32SceneCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Test_32SceneCode.GDPlayerObjects2.length = k;}if (gdjs.Test_32SceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Test_32SceneCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.Test_32SceneCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDPlayerObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("Build"), gdjs.Test_32SceneCode.GDBuildObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Test_32SceneCode.GDPlayerObjects2);
{for(var i = 0, len = gdjs.Test_32SceneCode.GDBuildObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDBuildObjects2[i].setWidth(((gdjs.RuntimeObject.getVariableNumber(((gdjs.Test_32SceneCode.GDPlayerObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Test_32SceneCode.GDPlayerObjects2[0].getVariables()).getFromIndex(1))) * 64) / 10);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Test_32SceneCode.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Wall"), gdjs.Test_32SceneCode.GDWallObjects2);

gdjs.Test_32SceneCode.condition0IsTrue_0.val = false;
{
gdjs.Test_32SceneCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDPlayerObjects2Objects, gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDWallObjects2Objects, false, runtimeScene, false);
}if (gdjs.Test_32SceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Test_32SceneCode.GDPlayerObjects2 */
/* Reuse gdjs.Test_32SceneCode.GDWallObjects2 */
{for(var i = 0, len = gdjs.Test_32SceneCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDPlayerObjects2[i].separateFromObjectsList(gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDWallObjects2Objects, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Fakewall"), gdjs.Test_32SceneCode.GDFakewallObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Test_32SceneCode.GDPlayerObjects2);

gdjs.Test_32SceneCode.condition0IsTrue_0.val = false;
{
gdjs.Test_32SceneCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDPlayerObjects2Objects, gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDFakewallObjects2Objects, false, runtimeScene, false);
}if (gdjs.Test_32SceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Test_32SceneCode.GDFakewallObjects2 */
/* Reuse gdjs.Test_32SceneCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.Test_32SceneCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDPlayerObjects2[i].separateFromObjectsList(gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDFakewallObjects2Objects, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Test_32SceneCode.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("tempwall1"), gdjs.Test_32SceneCode.GDtempwall1Objects2);

gdjs.Test_32SceneCode.condition0IsTrue_0.val = false;
{
gdjs.Test_32SceneCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDPlayerObjects2Objects, gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDtempwall1Objects2Objects, false, runtimeScene, false);
}if (gdjs.Test_32SceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Test_32SceneCode.GDPlayerObjects2 */
/* Reuse gdjs.Test_32SceneCode.GDtempwall1Objects2 */
{for(var i = 0, len = gdjs.Test_32SceneCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDPlayerObjects2[i].separateFromObjectsList(gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDtempwall1Objects2Objects, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Test_32SceneCode.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("tempwall2"), gdjs.Test_32SceneCode.GDtempwall2Objects2);

gdjs.Test_32SceneCode.condition0IsTrue_0.val = false;
{
gdjs.Test_32SceneCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDPlayerObjects2Objects, gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDtempwall2Objects2Objects, false, runtimeScene, false);
}if (gdjs.Test_32SceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Test_32SceneCode.GDPlayerObjects2 */
/* Reuse gdjs.Test_32SceneCode.GDtempwall2Objects2 */
{for(var i = 0, len = gdjs.Test_32SceneCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDPlayerObjects2[i].separateFromObjectsList(gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDtempwall2Objects2Objects, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Barricade"), gdjs.Test_32SceneCode.GDBarricadeObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Test_32SceneCode.GDPlayerObjects2);

gdjs.Test_32SceneCode.condition0IsTrue_0.val = false;
{
gdjs.Test_32SceneCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDPlayerObjects2Objects, gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBarricadeObjects2Objects, false, runtimeScene, false);
}if (gdjs.Test_32SceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Test_32SceneCode.GDBarricadeObjects2 */
/* Reuse gdjs.Test_32SceneCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.Test_32SceneCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDPlayerObjects2[i].separateFromObjectsList(gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBarricadeObjects2Objects, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("BarricadeShort"), gdjs.Test_32SceneCode.GDBarricadeShortObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Test_32SceneCode.GDPlayerObjects1);

gdjs.Test_32SceneCode.condition0IsTrue_0.val = false;
{
gdjs.Test_32SceneCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDPlayerObjects1Objects, gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBarricadeShortObjects1Objects, false, runtimeScene, false);
}if (gdjs.Test_32SceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Test_32SceneCode.GDBarricadeShortObjects1 */
/* Reuse gdjs.Test_32SceneCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.Test_32SceneCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDPlayerObjects1[i].separateFromObjectsList(gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBarricadeShortObjects1Objects, false);
}
}}

}


};gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBulletObjects3Objects = Hashtable.newFrom({"Bullet": gdjs.Test_32SceneCode.GDBulletObjects3});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDPlayerObjects4Objects = Hashtable.newFrom({"Player": gdjs.Test_32SceneCode.GDPlayerObjects4});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDPlayerObjects5Objects = Hashtable.newFrom({"Player": gdjs.Test_32SceneCode.GDPlayerObjects5});gdjs.Test_32SceneCode.eventsList22 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Test_32SceneCode.GDPlayerObjects4, gdjs.Test_32SceneCode.GDPlayerObjects5);


gdjs.Test_32SceneCode.condition0IsTrue_0.val = false;
{
gdjs.Test_32SceneCode.condition0IsTrue_0.val = gdjs.evtTools.object.pickedObjectsCount(gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDPlayerObjects5Objects) > 0;
}if (gdjs.Test_32SceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.Test_32SceneCode.GDZambamboObjects4, gdjs.Test_32SceneCode.GDZambamboObjects5);

{for(var i = 0, len = gdjs.Test_32SceneCode.GDZambamboObjects5.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDZambamboObjects5[i].returnVariable(gdjs.Test_32SceneCode.GDZambamboObjects5[i].getVariables().getFromIndex(0)).setNumber(1);
}
}}

}


};gdjs.Test_32SceneCode.eventsList23 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Test_32SceneCode.GDPlayerObjects3, gdjs.Test_32SceneCode.GDPlayerObjects4);


gdjs.Test_32SceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Test_32SceneCode.GDPlayerObjects4.length;i<l;++i) {
    if ( gdjs.Test_32SceneCode.GDPlayerObjects4[i].getTimerElapsedTimeInSecondsOrNaN("Ammo") > 0.5 ) {
        gdjs.Test_32SceneCode.condition0IsTrue_0.val = true;
        gdjs.Test_32SceneCode.GDPlayerObjects4[k] = gdjs.Test_32SceneCode.GDPlayerObjects4[i];
        ++k;
    }
}
gdjs.Test_32SceneCode.GDPlayerObjects4.length = k;}if (gdjs.Test_32SceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.Test_32SceneCode.GDPistolObjects3, gdjs.Test_32SceneCode.GDPistolObjects4);

/* Reuse gdjs.Test_32SceneCode.GDPlayerObjects4 */
{for(var i = 0, len = gdjs.Test_32SceneCode.GDPistolObjects4.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDPistolObjects4[i].returnVariable(gdjs.Test_32SceneCode.GDPistolObjects4[i].getVariables().getFromIndex(2)).sub(1);
}
}{for(var i = 0, len = gdjs.Test_32SceneCode.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDPlayerObjects4[i].resetTimer("Ammo");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Zambambo"), gdjs.Test_32SceneCode.GDZambamboObjects3);

for(gdjs.Test_32SceneCode.forEachIndex4 = 0;gdjs.Test_32SceneCode.forEachIndex4 < gdjs.Test_32SceneCode.GDZambamboObjects3.length;++gdjs.Test_32SceneCode.forEachIndex4) {
gdjs.copyArray(gdjs.Test_32SceneCode.GDPistolObjects3, gdjs.Test_32SceneCode.GDPistolObjects4);

gdjs.copyArray(gdjs.Test_32SceneCode.GDPlayerObjects3, gdjs.Test_32SceneCode.GDPlayerObjects4);

gdjs.Test_32SceneCode.GDZambamboObjects4.length = 0;


gdjs.Test_32SceneCode.forEachTemporary4 = gdjs.Test_32SceneCode.GDZambamboObjects3[gdjs.Test_32SceneCode.forEachIndex4];
gdjs.Test_32SceneCode.GDZambamboObjects4.push(gdjs.Test_32SceneCode.forEachTemporary4);
gdjs.Test_32SceneCode.condition0IsTrue_0.val = false;
{
gdjs.Test_32SceneCode.condition0IsTrue_0.val = gdjs.evtTools.object.raycastObject(gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDPlayerObjects4Objects, (( gdjs.Test_32SceneCode.GDZambamboObjects4.length === 0 ) ? 0 :gdjs.Test_32SceneCode.GDZambamboObjects4[0].getCenterXInScene()), (( gdjs.Test_32SceneCode.GDZambamboObjects4.length === 0 ) ? 0 :gdjs.Test_32SceneCode.GDZambamboObjects4[0].getCenterYInScene()), (( gdjs.Test_32SceneCode.GDZambamboObjects4.length === 0 ) ? 0 :gdjs.Test_32SceneCode.GDZambamboObjects4[0].getAngleToObject((gdjs.Test_32SceneCode.GDPlayerObjects4.length !== 0 ? gdjs.Test_32SceneCode.GDPlayerObjects4[0] : null))), (gdjs.RuntimeObject.getVariableNumber(((gdjs.Test_32SceneCode.GDPistolObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Test_32SceneCode.GDPistolObjects4[0].getVariables()).getFromIndex(3))), runtimeScene.getVariables().getFromIndex(0), runtimeScene.getVariables().getFromIndex(1), false);
}if (gdjs.Test_32SceneCode.condition0IsTrue_0.val) {

{ //Subevents: 
gdjs.Test_32SceneCode.eventsList22(runtimeScene);} //Subevents end.
}
}

}


};gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBulletObjects5Objects = Hashtable.newFrom({"Bullet": gdjs.Test_32SceneCode.GDBulletObjects5});gdjs.Test_32SceneCode.eventsList24 = function(runtimeScene) {

};gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDPlayerObjects4Objects = Hashtable.newFrom({"Player": gdjs.Test_32SceneCode.GDPlayerObjects4});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDPlayerObjects5Objects = Hashtable.newFrom({"Player": gdjs.Test_32SceneCode.GDPlayerObjects5});gdjs.Test_32SceneCode.eventsList25 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Test_32SceneCode.GDPlayerObjects4, gdjs.Test_32SceneCode.GDPlayerObjects5);


gdjs.Test_32SceneCode.condition0IsTrue_0.val = false;
{
gdjs.Test_32SceneCode.condition0IsTrue_0.val = gdjs.evtTools.object.pickedObjectsCount(gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDPlayerObjects5Objects) > 0;
}if (gdjs.Test_32SceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.Test_32SceneCode.GDZambamboObjects4, gdjs.Test_32SceneCode.GDZambamboObjects5);

{for(var i = 0, len = gdjs.Test_32SceneCode.GDZambamboObjects5.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDZambamboObjects5[i].returnVariable(gdjs.Test_32SceneCode.GDZambamboObjects5[i].getVariables().getFromIndex(0)).setNumber(1);
}
}}

}


};gdjs.Test_32SceneCode.eventsList26 = function(runtimeScene) {

{


gdjs.Test_32SceneCode.repeatCount5 = 3;
for(gdjs.Test_32SceneCode.repeatIndex5 = 0;gdjs.Test_32SceneCode.repeatIndex5 < gdjs.Test_32SceneCode.repeatCount5;++gdjs.Test_32SceneCode.repeatIndex5) {
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.Test_32SceneCode.GDBulletObjects5);
gdjs.copyArray(gdjs.Test_32SceneCode.GDPlayerObjects3, gdjs.Test_32SceneCode.GDPlayerObjects5);

gdjs.copyArray(gdjs.Test_32SceneCode.GDShotgunObjects3, gdjs.Test_32SceneCode.GDShotgunObjects5);


if (true)
{
{for(var i = 0, len = gdjs.Test_32SceneCode.GDPlayerObjects5.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDPlayerObjects5[i].getBehavior("FireBullet").Fire((gdjs.Test_32SceneCode.GDPlayerObjects5[i].getPointX("")), (gdjs.Test_32SceneCode.GDPlayerObjects5[i].getPointY("")), gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBulletObjects5Objects, gdjs.evtTools.common.angleBetweenPositions((gdjs.Test_32SceneCode.GDPlayerObjects5[i].getCenterXInScene()), (gdjs.Test_32SceneCode.GDPlayerObjects5[i].getCenterYInScene()), gdjs.evtTools.input.getMouseX(runtimeScene, "", 0), gdjs.evtTools.input.getMouseY(runtimeScene, "", 0)) + gdjs.randomFloatInRange(-(20), 20), (gdjs.RuntimeObject.getVariableNumber(((gdjs.Test_32SceneCode.GDShotgunObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Test_32SceneCode.GDShotgunObjects5[0].getVariables()).getFromIndex(1))), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Test_32SceneCode.GDBulletObjects5.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDBulletObjects5[i].returnVariable(gdjs.Test_32SceneCode.GDBulletObjects5[i].getVariables().getFromIndex(0)).setNumber((gdjs.RuntimeObject.getVariableNumber(((gdjs.Test_32SceneCode.GDShotgunObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Test_32SceneCode.GDShotgunObjects5[0].getVariables()).getFromIndex(0))));
}
}}
}

}


{

gdjs.copyArray(gdjs.Test_32SceneCode.GDPlayerObjects3, gdjs.Test_32SceneCode.GDPlayerObjects4);


gdjs.Test_32SceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Test_32SceneCode.GDPlayerObjects4.length;i<l;++i) {
    if ( gdjs.Test_32SceneCode.GDPlayerObjects4[i].getTimerElapsedTimeInSecondsOrNaN("Ammo") > 0.5 ) {
        gdjs.Test_32SceneCode.condition0IsTrue_0.val = true;
        gdjs.Test_32SceneCode.GDPlayerObjects4[k] = gdjs.Test_32SceneCode.GDPlayerObjects4[i];
        ++k;
    }
}
gdjs.Test_32SceneCode.GDPlayerObjects4.length = k;}if (gdjs.Test_32SceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Test_32SceneCode.GDPlayerObjects4 */
gdjs.copyArray(gdjs.Test_32SceneCode.GDShotgunObjects3, gdjs.Test_32SceneCode.GDShotgunObjects4);

{for(var i = 0, len = gdjs.Test_32SceneCode.GDShotgunObjects4.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDShotgunObjects4[i].returnVariable(gdjs.Test_32SceneCode.GDShotgunObjects4[i].getVariables().getFromIndex(2)).sub(1);
}
}{for(var i = 0, len = gdjs.Test_32SceneCode.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDPlayerObjects4[i].resetTimer("Ammo");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Zambambo"), gdjs.Test_32SceneCode.GDZambamboObjects3);

for(gdjs.Test_32SceneCode.forEachIndex4 = 0;gdjs.Test_32SceneCode.forEachIndex4 < gdjs.Test_32SceneCode.GDZambamboObjects3.length;++gdjs.Test_32SceneCode.forEachIndex4) {
gdjs.copyArray(gdjs.Test_32SceneCode.GDPlayerObjects3, gdjs.Test_32SceneCode.GDPlayerObjects4);

gdjs.copyArray(gdjs.Test_32SceneCode.GDShotgunObjects3, gdjs.Test_32SceneCode.GDShotgunObjects4);

gdjs.Test_32SceneCode.GDZambamboObjects4.length = 0;


gdjs.Test_32SceneCode.forEachTemporary4 = gdjs.Test_32SceneCode.GDZambamboObjects3[gdjs.Test_32SceneCode.forEachIndex4];
gdjs.Test_32SceneCode.GDZambamboObjects4.push(gdjs.Test_32SceneCode.forEachTemporary4);
gdjs.Test_32SceneCode.condition0IsTrue_0.val = false;
{
gdjs.Test_32SceneCode.condition0IsTrue_0.val = gdjs.evtTools.object.raycastObject(gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDPlayerObjects4Objects, (( gdjs.Test_32SceneCode.GDZambamboObjects4.length === 0 ) ? 0 :gdjs.Test_32SceneCode.GDZambamboObjects4[0].getCenterXInScene()), (( gdjs.Test_32SceneCode.GDZambamboObjects4.length === 0 ) ? 0 :gdjs.Test_32SceneCode.GDZambamboObjects4[0].getCenterYInScene()), (( gdjs.Test_32SceneCode.GDZambamboObjects4.length === 0 ) ? 0 :gdjs.Test_32SceneCode.GDZambamboObjects4[0].getAngleToObject((gdjs.Test_32SceneCode.GDPlayerObjects4.length !== 0 ? gdjs.Test_32SceneCode.GDPlayerObjects4[0] : null))), (gdjs.RuntimeObject.getVariableNumber(((gdjs.Test_32SceneCode.GDShotgunObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Test_32SceneCode.GDShotgunObjects4[0].getVariables()).getFromIndex(3))), runtimeScene.getVariables().getFromIndex(0), runtimeScene.getVariables().getFromIndex(1), false);
}if (gdjs.Test_32SceneCode.condition0IsTrue_0.val) {

{ //Subevents: 
gdjs.Test_32SceneCode.eventsList25(runtimeScene);} //Subevents end.
}
}

}


};gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBulletObjects3Objects = Hashtable.newFrom({"Bullet": gdjs.Test_32SceneCode.GDBulletObjects3});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDPlayerObjects4Objects = Hashtable.newFrom({"Player": gdjs.Test_32SceneCode.GDPlayerObjects4});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDPlayerObjects5Objects = Hashtable.newFrom({"Player": gdjs.Test_32SceneCode.GDPlayerObjects5});gdjs.Test_32SceneCode.eventsList27 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Test_32SceneCode.GDPlayerObjects4, gdjs.Test_32SceneCode.GDPlayerObjects5);


gdjs.Test_32SceneCode.condition0IsTrue_0.val = false;
{
gdjs.Test_32SceneCode.condition0IsTrue_0.val = gdjs.evtTools.object.pickedObjectsCount(gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDPlayerObjects5Objects) > 0;
}if (gdjs.Test_32SceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.Test_32SceneCode.GDZambamboObjects4, gdjs.Test_32SceneCode.GDZambamboObjects5);

{for(var i = 0, len = gdjs.Test_32SceneCode.GDZambamboObjects5.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDZambamboObjects5[i].returnVariable(gdjs.Test_32SceneCode.GDZambamboObjects5[i].getVariables().getFromIndex(0)).setNumber(1);
}
}}

}


};gdjs.Test_32SceneCode.eventsList28 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Test_32SceneCode.GDPlayerObjects3, gdjs.Test_32SceneCode.GDPlayerObjects4);


gdjs.Test_32SceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Test_32SceneCode.GDPlayerObjects4.length;i<l;++i) {
    if ( gdjs.Test_32SceneCode.GDPlayerObjects4[i].getTimerElapsedTimeInSecondsOrNaN("Ammo") > 0.5 ) {
        gdjs.Test_32SceneCode.condition0IsTrue_0.val = true;
        gdjs.Test_32SceneCode.GDPlayerObjects4[k] = gdjs.Test_32SceneCode.GDPlayerObjects4[i];
        ++k;
    }
}
gdjs.Test_32SceneCode.GDPlayerObjects4.length = k;}if (gdjs.Test_32SceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Test_32SceneCode.GDPlayerObjects4 */
gdjs.copyArray(gdjs.Test_32SceneCode.GDRifleObjects3, gdjs.Test_32SceneCode.GDRifleObjects4);

{for(var i = 0, len = gdjs.Test_32SceneCode.GDRifleObjects4.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDRifleObjects4[i].returnVariable(gdjs.Test_32SceneCode.GDRifleObjects4[i].getVariables().getFromIndex(2)).sub(1);
}
}{for(var i = 0, len = gdjs.Test_32SceneCode.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDPlayerObjects4[i].resetTimer("Ammo");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Zambambo"), gdjs.Test_32SceneCode.GDZambamboObjects3);

for(gdjs.Test_32SceneCode.forEachIndex4 = 0;gdjs.Test_32SceneCode.forEachIndex4 < gdjs.Test_32SceneCode.GDZambamboObjects3.length;++gdjs.Test_32SceneCode.forEachIndex4) {
gdjs.copyArray(gdjs.Test_32SceneCode.GDPlayerObjects3, gdjs.Test_32SceneCode.GDPlayerObjects4);

gdjs.copyArray(gdjs.Test_32SceneCode.GDRifleObjects3, gdjs.Test_32SceneCode.GDRifleObjects4);

gdjs.Test_32SceneCode.GDZambamboObjects4.length = 0;


gdjs.Test_32SceneCode.forEachTemporary4 = gdjs.Test_32SceneCode.GDZambamboObjects3[gdjs.Test_32SceneCode.forEachIndex4];
gdjs.Test_32SceneCode.GDZambamboObjects4.push(gdjs.Test_32SceneCode.forEachTemporary4);
gdjs.Test_32SceneCode.condition0IsTrue_0.val = false;
{
gdjs.Test_32SceneCode.condition0IsTrue_0.val = gdjs.evtTools.object.raycastObject(gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDPlayerObjects4Objects, (( gdjs.Test_32SceneCode.GDZambamboObjects4.length === 0 ) ? 0 :gdjs.Test_32SceneCode.GDZambamboObjects4[0].getCenterXInScene()), (( gdjs.Test_32SceneCode.GDZambamboObjects4.length === 0 ) ? 0 :gdjs.Test_32SceneCode.GDZambamboObjects4[0].getCenterYInScene()), (( gdjs.Test_32SceneCode.GDZambamboObjects4.length === 0 ) ? 0 :gdjs.Test_32SceneCode.GDZambamboObjects4[0].getAngleToObject((gdjs.Test_32SceneCode.GDPlayerObjects4.length !== 0 ? gdjs.Test_32SceneCode.GDPlayerObjects4[0] : null))), (gdjs.RuntimeObject.getVariableNumber(((gdjs.Test_32SceneCode.GDRifleObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Test_32SceneCode.GDRifleObjects4[0].getVariables()).getFromIndex(3))), runtimeScene.getVariables().getFromIndex(0), runtimeScene.getVariables().getFromIndex(1), false);
}if (gdjs.Test_32SceneCode.condition0IsTrue_0.val) {

{ //Subevents: 
gdjs.Test_32SceneCode.eventsList27(runtimeScene);} //Subevents end.
}
}

}


};gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBulletObjects2Objects = Hashtable.newFrom({"Bullet": gdjs.Test_32SceneCode.GDBulletObjects2});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Test_32SceneCode.GDPlayerObjects3});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDPlayerObjects4Objects = Hashtable.newFrom({"Player": gdjs.Test_32SceneCode.GDPlayerObjects4});gdjs.Test_32SceneCode.eventsList29 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Test_32SceneCode.GDPlayerObjects3, gdjs.Test_32SceneCode.GDPlayerObjects4);


gdjs.Test_32SceneCode.condition0IsTrue_0.val = false;
{
gdjs.Test_32SceneCode.condition0IsTrue_0.val = gdjs.evtTools.object.pickedObjectsCount(gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDPlayerObjects4Objects) > 0;
}if (gdjs.Test_32SceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.Test_32SceneCode.GDZambamboObjects3, gdjs.Test_32SceneCode.GDZambamboObjects4);

{for(var i = 0, len = gdjs.Test_32SceneCode.GDZambamboObjects4.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDZambamboObjects4[i].returnVariable(gdjs.Test_32SceneCode.GDZambamboObjects4[i].getVariables().getFromIndex(0)).setNumber(1);
}
}}

}


};gdjs.Test_32SceneCode.eventsList30 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Test_32SceneCode.GDPlayerObjects2, gdjs.Test_32SceneCode.GDPlayerObjects3);


gdjs.Test_32SceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Test_32SceneCode.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.Test_32SceneCode.GDPlayerObjects3[i].getTimerElapsedTimeInSecondsOrNaN("Ammo") > 0.5 ) {
        gdjs.Test_32SceneCode.condition0IsTrue_0.val = true;
        gdjs.Test_32SceneCode.GDPlayerObjects3[k] = gdjs.Test_32SceneCode.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Test_32SceneCode.GDPlayerObjects3.length = k;}if (gdjs.Test_32SceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.Test_32SceneCode.GDAssaultObjects2, gdjs.Test_32SceneCode.GDAssaultObjects3);

/* Reuse gdjs.Test_32SceneCode.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.Test_32SceneCode.GDAssaultObjects3.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDAssaultObjects3[i].returnVariable(gdjs.Test_32SceneCode.GDAssaultObjects3[i].getVariables().getFromIndex(2)).sub(1);
}
}{for(var i = 0, len = gdjs.Test_32SceneCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDPlayerObjects3[i].resetTimer("Ammo");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Zambambo"), gdjs.Test_32SceneCode.GDZambamboObjects2);

for(gdjs.Test_32SceneCode.forEachIndex3 = 0;gdjs.Test_32SceneCode.forEachIndex3 < gdjs.Test_32SceneCode.GDZambamboObjects2.length;++gdjs.Test_32SceneCode.forEachIndex3) {
gdjs.copyArray(gdjs.Test_32SceneCode.GDAssaultObjects2, gdjs.Test_32SceneCode.GDAssaultObjects3);

gdjs.copyArray(gdjs.Test_32SceneCode.GDPlayerObjects2, gdjs.Test_32SceneCode.GDPlayerObjects3);

gdjs.Test_32SceneCode.GDZambamboObjects3.length = 0;


gdjs.Test_32SceneCode.forEachTemporary3 = gdjs.Test_32SceneCode.GDZambamboObjects2[gdjs.Test_32SceneCode.forEachIndex3];
gdjs.Test_32SceneCode.GDZambamboObjects3.push(gdjs.Test_32SceneCode.forEachTemporary3);
gdjs.Test_32SceneCode.condition0IsTrue_0.val = false;
{
gdjs.Test_32SceneCode.condition0IsTrue_0.val = gdjs.evtTools.object.raycastObject(gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDPlayerObjects3Objects, (( gdjs.Test_32SceneCode.GDZambamboObjects3.length === 0 ) ? 0 :gdjs.Test_32SceneCode.GDZambamboObjects3[0].getCenterXInScene()), (( gdjs.Test_32SceneCode.GDZambamboObjects3.length === 0 ) ? 0 :gdjs.Test_32SceneCode.GDZambamboObjects3[0].getCenterYInScene()), (( gdjs.Test_32SceneCode.GDZambamboObjects3.length === 0 ) ? 0 :gdjs.Test_32SceneCode.GDZambamboObjects3[0].getAngleToObject((gdjs.Test_32SceneCode.GDPlayerObjects3.length !== 0 ? gdjs.Test_32SceneCode.GDPlayerObjects3[0] : null))), (gdjs.RuntimeObject.getVariableNumber(((gdjs.Test_32SceneCode.GDAssaultObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Test_32SceneCode.GDAssaultObjects3[0].getVariables()).getFromIndex(3))), runtimeScene.getVariables().getFromIndex(0), runtimeScene.getVariables().getFromIndex(1), false);
}if (gdjs.Test_32SceneCode.condition0IsTrue_0.val) {

{ //Subevents: 
gdjs.Test_32SceneCode.eventsList29(runtimeScene);} //Subevents end.
}
}

}


};gdjs.Test_32SceneCode.eventsList31 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Pistol"), gdjs.Test_32SceneCode.GDPistolObjects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Test_32SceneCode.GDPlayerObjects3);

gdjs.Test_32SceneCode.condition0IsTrue_0.val = false;
gdjs.Test_32SceneCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Test_32SceneCode.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.Test_32SceneCode.GDPlayerObjects3[i].getVariableString(gdjs.Test_32SceneCode.GDPlayerObjects3[i].getVariables().getFromIndex(2)) == "Pistol" ) {
        gdjs.Test_32SceneCode.condition0IsTrue_0.val = true;
        gdjs.Test_32SceneCode.GDPlayerObjects3[k] = gdjs.Test_32SceneCode.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Test_32SceneCode.GDPlayerObjects3.length = k;}if ( gdjs.Test_32SceneCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Test_32SceneCode.GDPistolObjects3.length;i<l;++i) {
    if ( gdjs.Test_32SceneCode.GDPistolObjects3[i].getVariableNumber(gdjs.Test_32SceneCode.GDPistolObjects3[i].getVariables().getFromIndex(2)) > 0 ) {
        gdjs.Test_32SceneCode.condition1IsTrue_0.val = true;
        gdjs.Test_32SceneCode.GDPistolObjects3[k] = gdjs.Test_32SceneCode.GDPistolObjects3[i];
        ++k;
    }
}
gdjs.Test_32SceneCode.GDPistolObjects3.length = k;}}
if (gdjs.Test_32SceneCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.Test_32SceneCode.GDBulletObjects3);
/* Reuse gdjs.Test_32SceneCode.GDPistolObjects3 */
/* Reuse gdjs.Test_32SceneCode.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.Test_32SceneCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDPlayerObjects3[i].getBehavior("FireBullet").Fire((gdjs.Test_32SceneCode.GDPlayerObjects3[i].getPointX("")), (gdjs.Test_32SceneCode.GDPlayerObjects3[i].getPointY("")), gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBulletObjects3Objects, gdjs.evtTools.common.angleBetweenPositions((gdjs.Test_32SceneCode.GDPlayerObjects3[i].getCenterXInScene()), (gdjs.Test_32SceneCode.GDPlayerObjects3[i].getCenterYInScene()), gdjs.evtTools.input.getMouseX(runtimeScene, "", 0), gdjs.evtTools.input.getMouseY(runtimeScene, "", 0)), (gdjs.RuntimeObject.getVariableNumber(((gdjs.Test_32SceneCode.GDPistolObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Test_32SceneCode.GDPistolObjects3[0].getVariables()).getFromIndex(1))), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Test_32SceneCode.GDBulletObjects3.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDBulletObjects3[i].returnVariable(gdjs.Test_32SceneCode.GDBulletObjects3[i].getVariables().getFromIndex(0)).setNumber((gdjs.RuntimeObject.getVariableNumber(((gdjs.Test_32SceneCode.GDPistolObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Test_32SceneCode.GDPistolObjects3[0].getVariables()).getFromIndex(0))));
}
}
{ //Subevents
gdjs.Test_32SceneCode.eventsList23(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Test_32SceneCode.GDPlayerObjects3);
gdjs.copyArray(runtimeScene.getObjects("Shotgun"), gdjs.Test_32SceneCode.GDShotgunObjects3);

gdjs.Test_32SceneCode.condition0IsTrue_0.val = false;
gdjs.Test_32SceneCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Test_32SceneCode.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.Test_32SceneCode.GDPlayerObjects3[i].getVariableString(gdjs.Test_32SceneCode.GDPlayerObjects3[i].getVariables().getFromIndex(2)) == "Shotgun" ) {
        gdjs.Test_32SceneCode.condition0IsTrue_0.val = true;
        gdjs.Test_32SceneCode.GDPlayerObjects3[k] = gdjs.Test_32SceneCode.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Test_32SceneCode.GDPlayerObjects3.length = k;}if ( gdjs.Test_32SceneCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Test_32SceneCode.GDShotgunObjects3.length;i<l;++i) {
    if ( gdjs.Test_32SceneCode.GDShotgunObjects3[i].getVariableNumber(gdjs.Test_32SceneCode.GDShotgunObjects3[i].getVariables().getFromIndex(2)) > 0 ) {
        gdjs.Test_32SceneCode.condition1IsTrue_0.val = true;
        gdjs.Test_32SceneCode.GDShotgunObjects3[k] = gdjs.Test_32SceneCode.GDShotgunObjects3[i];
        ++k;
    }
}
gdjs.Test_32SceneCode.GDShotgunObjects3.length = k;}}
if (gdjs.Test_32SceneCode.condition1IsTrue_0.val) {

{ //Subevents
gdjs.Test_32SceneCode.eventsList26(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Test_32SceneCode.GDPlayerObjects3);
gdjs.copyArray(runtimeScene.getObjects("Rifle"), gdjs.Test_32SceneCode.GDRifleObjects3);

gdjs.Test_32SceneCode.condition0IsTrue_0.val = false;
gdjs.Test_32SceneCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Test_32SceneCode.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.Test_32SceneCode.GDPlayerObjects3[i].getVariableString(gdjs.Test_32SceneCode.GDPlayerObjects3[i].getVariables().getFromIndex(2)) == "Sniper" ) {
        gdjs.Test_32SceneCode.condition0IsTrue_0.val = true;
        gdjs.Test_32SceneCode.GDPlayerObjects3[k] = gdjs.Test_32SceneCode.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Test_32SceneCode.GDPlayerObjects3.length = k;}if ( gdjs.Test_32SceneCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Test_32SceneCode.GDRifleObjects3.length;i<l;++i) {
    if ( gdjs.Test_32SceneCode.GDRifleObjects3[i].getVariableNumber(gdjs.Test_32SceneCode.GDRifleObjects3[i].getVariables().getFromIndex(2)) > 0 ) {
        gdjs.Test_32SceneCode.condition1IsTrue_0.val = true;
        gdjs.Test_32SceneCode.GDRifleObjects3[k] = gdjs.Test_32SceneCode.GDRifleObjects3[i];
        ++k;
    }
}
gdjs.Test_32SceneCode.GDRifleObjects3.length = k;}}
if (gdjs.Test_32SceneCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.Test_32SceneCode.GDBulletObjects3);
/* Reuse gdjs.Test_32SceneCode.GDPlayerObjects3 */
/* Reuse gdjs.Test_32SceneCode.GDRifleObjects3 */
{for(var i = 0, len = gdjs.Test_32SceneCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDPlayerObjects3[i].getBehavior("FireBullet").Fire((gdjs.Test_32SceneCode.GDPlayerObjects3[i].getPointX("")), (gdjs.Test_32SceneCode.GDPlayerObjects3[i].getPointY("")), gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBulletObjects3Objects, gdjs.evtTools.common.angleBetweenPositions((gdjs.Test_32SceneCode.GDPlayerObjects3[i].getCenterXInScene()), (gdjs.Test_32SceneCode.GDPlayerObjects3[i].getCenterYInScene()), gdjs.evtTools.input.getMouseX(runtimeScene, "", 0), gdjs.evtTools.input.getMouseY(runtimeScene, "", 0)), (gdjs.RuntimeObject.getVariableNumber(((gdjs.Test_32SceneCode.GDRifleObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Test_32SceneCode.GDRifleObjects3[0].getVariables()).getFromIndex(1))), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Test_32SceneCode.GDBulletObjects3.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDBulletObjects3[i].returnVariable(gdjs.Test_32SceneCode.GDBulletObjects3[i].getVariables().getFromIndex(0)).setNumber((gdjs.RuntimeObject.getVariableNumber(((gdjs.Test_32SceneCode.GDRifleObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Test_32SceneCode.GDRifleObjects3[0].getVariables()).getFromIndex(0))));
}
}
{ //Subevents
gdjs.Test_32SceneCode.eventsList28(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Assault"), gdjs.Test_32SceneCode.GDAssaultObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Test_32SceneCode.GDPlayerObjects2);

gdjs.Test_32SceneCode.condition0IsTrue_0.val = false;
gdjs.Test_32SceneCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Test_32SceneCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Test_32SceneCode.GDPlayerObjects2[i].getVariableString(gdjs.Test_32SceneCode.GDPlayerObjects2[i].getVariables().getFromIndex(2)) == "Assault" ) {
        gdjs.Test_32SceneCode.condition0IsTrue_0.val = true;
        gdjs.Test_32SceneCode.GDPlayerObjects2[k] = gdjs.Test_32SceneCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Test_32SceneCode.GDPlayerObjects2.length = k;}if ( gdjs.Test_32SceneCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Test_32SceneCode.GDAssaultObjects2.length;i<l;++i) {
    if ( gdjs.Test_32SceneCode.GDAssaultObjects2[i].getVariableNumber(gdjs.Test_32SceneCode.GDAssaultObjects2[i].getVariables().getFromIndex(2)) > 0 ) {
        gdjs.Test_32SceneCode.condition1IsTrue_0.val = true;
        gdjs.Test_32SceneCode.GDAssaultObjects2[k] = gdjs.Test_32SceneCode.GDAssaultObjects2[i];
        ++k;
    }
}
gdjs.Test_32SceneCode.GDAssaultObjects2.length = k;}}
if (gdjs.Test_32SceneCode.condition1IsTrue_0.val) {
/* Reuse gdjs.Test_32SceneCode.GDAssaultObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.Test_32SceneCode.GDBulletObjects2);
/* Reuse gdjs.Test_32SceneCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.Test_32SceneCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDPlayerObjects2[i].getBehavior("FireBullet").Fire((gdjs.Test_32SceneCode.GDPlayerObjects2[i].getPointX("")), (gdjs.Test_32SceneCode.GDPlayerObjects2[i].getPointY("")), gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBulletObjects2Objects, gdjs.evtTools.common.angleBetweenPositions((gdjs.Test_32SceneCode.GDPlayerObjects2[i].getCenterXInScene()), (gdjs.Test_32SceneCode.GDPlayerObjects2[i].getCenterYInScene()), gdjs.evtTools.input.getMouseX(runtimeScene, "", 0), gdjs.evtTools.input.getMouseY(runtimeScene, "", 0)), (gdjs.RuntimeObject.getVariableNumber(((gdjs.Test_32SceneCode.GDAssaultObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Test_32SceneCode.GDAssaultObjects2[0].getVariables()).getFromIndex(1))), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Test_32SceneCode.GDBulletObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDBulletObjects2[i].returnVariable(gdjs.Test_32SceneCode.GDBulletObjects2[i].getVariables().getFromIndex(0)).setNumber((gdjs.RuntimeObject.getVariableNumber(((gdjs.Test_32SceneCode.GDAssaultObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Test_32SceneCode.GDAssaultObjects2[0].getVariables()).getFromIndex(0))));
}
}
{ //Subevents
gdjs.Test_32SceneCode.eventsList30(runtimeScene);} //End of subevents
}

}


};gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBulletObjects2Objects = Hashtable.newFrom({"Bullet": gdjs.Test_32SceneCode.GDBulletObjects2});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBarricadeObjects2Objects = Hashtable.newFrom({"Barricade": gdjs.Test_32SceneCode.GDBarricadeObjects2});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBulletObjects2Objects = Hashtable.newFrom({"Bullet": gdjs.Test_32SceneCode.GDBulletObjects2});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDWallObjects2Objects = Hashtable.newFrom({"Wall": gdjs.Test_32SceneCode.GDWallObjects2});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBulletObjects1Objects = Hashtable.newFrom({"Bullet": gdjs.Test_32SceneCode.GDBulletObjects1});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDZambamboObjects1Objects = Hashtable.newFrom({"Zambambo": gdjs.Test_32SceneCode.GDZambamboObjects1});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDZambamboHealthObjects1Objects = Hashtable.newFrom({"ZambamboHealth": gdjs.Test_32SceneCode.GDZambamboHealthObjects1});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDZambamboHealthBackObjects1Objects = Hashtable.newFrom({"ZambamboHealthBack": gdjs.Test_32SceneCode.GDZambamboHealthBackObjects1});gdjs.Test_32SceneCode.eventsList32 = function(runtimeScene) {

{

/* Reuse gdjs.Test_32SceneCode.GDZambamboObjects1 */
gdjs.copyArray(runtimeScene.getObjects("ZambamboHealth"), gdjs.Test_32SceneCode.GDZambamboHealthObjects1);
gdjs.copyArray(runtimeScene.getObjects("ZambamboHealthBack"), gdjs.Test_32SceneCode.GDZambamboHealthBackObjects1);

gdjs.Test_32SceneCode.condition0IsTrue_0.val = false;
gdjs.Test_32SceneCode.condition1IsTrue_0.val = false;
{
gdjs.Test_32SceneCode.condition0IsTrue_0.val = gdjs.evtTools.linkedObjects.pickObjectsLinkedTo(runtimeScene, gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDZambamboHealthObjects1Objects, (gdjs.Test_32SceneCode.GDZambamboObjects1.length !== 0 ? gdjs.Test_32SceneCode.GDZambamboObjects1[0] : null), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}if ( gdjs.Test_32SceneCode.condition0IsTrue_0.val ) {
{
gdjs.Test_32SceneCode.condition1IsTrue_0.val = gdjs.evtTools.linkedObjects.pickObjectsLinkedTo(runtimeScene, gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDZambamboHealthBackObjects1Objects, (gdjs.Test_32SceneCode.GDZambamboObjects1.length !== 0 ? gdjs.Test_32SceneCode.GDZambamboObjects1[0] : null), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}
if (gdjs.Test_32SceneCode.condition1IsTrue_0.val) {
/* Reuse gdjs.Test_32SceneCode.GDBulletObjects1 */
/* Reuse gdjs.Test_32SceneCode.GDZambamboObjects1 */
/* Reuse gdjs.Test_32SceneCode.GDZambamboHealthObjects1 */
/* Reuse gdjs.Test_32SceneCode.GDZambamboHealthBackObjects1 */
{for(var i = 0, len = gdjs.Test_32SceneCode.GDZambamboHealthObjects1.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDZambamboHealthObjects1[i].setWidth((((gdjs.RuntimeObject.getVariableNumber(((gdjs.Test_32SceneCode.GDZambamboObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Test_32SceneCode.GDZambamboObjects1[0].getVariables()).getFromIndex(3))) - (gdjs.RuntimeObject.getVariableNumber(((gdjs.Test_32SceneCode.GDBulletObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Test_32SceneCode.GDBulletObjects1[0].getVariables()).getFromIndex(0)))) / (gdjs.RuntimeObject.getVariableNumber(((gdjs.Test_32SceneCode.GDZambamboObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Test_32SceneCode.GDZambamboObjects1[0].getVariables()).getFromIndex(2)))) * (( gdjs.Test_32SceneCode.GDZambamboHealthBackObjects1.length === 0 ) ? 0 :gdjs.Test_32SceneCode.GDZambamboHealthBackObjects1[0].getWidth()));
}
}{for(var i = 0, len = gdjs.Test_32SceneCode.GDZambamboObjects1.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDZambamboObjects1[i].returnVariable(gdjs.Test_32SceneCode.GDZambamboObjects1[i].getVariables().getFromIndex(3)).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.Test_32SceneCode.GDBulletObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Test_32SceneCode.GDBulletObjects1[0].getVariables()).getFromIndex(0))));
}
}}

}


};gdjs.Test_32SceneCode.eventsList33 = function(runtimeScene) {

{



}


{



}


{


gdjs.Test_32SceneCode.condition0IsTrue_0.val = false;
{
gdjs.Test_32SceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if (gdjs.Test_32SceneCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Test_32SceneCode.eventsList31(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Barricade"), gdjs.Test_32SceneCode.GDBarricadeObjects2);
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.Test_32SceneCode.GDBulletObjects2);

gdjs.Test_32SceneCode.condition0IsTrue_0.val = false;
{
gdjs.Test_32SceneCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBulletObjects2Objects, gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBarricadeObjects2Objects, false, runtimeScene, false);
}if (gdjs.Test_32SceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Test_32SceneCode.GDBarricadeObjects2 */
/* Reuse gdjs.Test_32SceneCode.GDBulletObjects2 */
{for(var i = 0, len = gdjs.Test_32SceneCode.GDBarricadeObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDBarricadeObjects2[i].getBehavior("Health").Hit((gdjs.RuntimeObject.getVariableNumber(((gdjs.Test_32SceneCode.GDBulletObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Test_32SceneCode.GDBulletObjects2[0].getVariables()).getFromIndex(0))), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Test_32SceneCode.GDBulletObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDBulletObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.Test_32SceneCode.GDBulletObjects2);
gdjs.copyArray(runtimeScene.getObjects("Wall"), gdjs.Test_32SceneCode.GDWallObjects2);

gdjs.Test_32SceneCode.condition0IsTrue_0.val = false;
{
gdjs.Test_32SceneCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBulletObjects2Objects, gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDWallObjects2Objects, false, runtimeScene, false);
}if (gdjs.Test_32SceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Test_32SceneCode.GDBulletObjects2 */
{for(var i = 0, len = gdjs.Test_32SceneCode.GDBulletObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDBulletObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.Test_32SceneCode.GDBulletObjects1);
gdjs.copyArray(runtimeScene.getObjects("Zambambo"), gdjs.Test_32SceneCode.GDZambamboObjects1);

gdjs.Test_32SceneCode.condition0IsTrue_0.val = false;
{
gdjs.Test_32SceneCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBulletObjects1Objects, gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDZambamboObjects1Objects, false, runtimeScene, false);
}if (gdjs.Test_32SceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Test_32SceneCode.GDBulletObjects1 */
/* Reuse gdjs.Test_32SceneCode.GDZambamboObjects1 */
{for(var i = 0, len = gdjs.Test_32SceneCode.GDBulletObjects1.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDBulletObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Test_32SceneCode.GDZambamboObjects1.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDZambamboObjects1[i].getBehavior("Health").Hit((gdjs.RuntimeObject.getVariableNumber(((gdjs.Test_32SceneCode.GDBulletObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Test_32SceneCode.GDBulletObjects1[0].getVariables()).getFromIndex(0))), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.Test_32SceneCode.eventsList32(runtimeScene);} //End of subevents
}

}


};gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Test_32SceneCode.GDPlayerObjects2});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDMouseObjectObjects2Objects = Hashtable.newFrom({"MouseObject": gdjs.Test_32SceneCode.GDMouseObjectObjects2});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBarricadeGhostObjects3Objects = Hashtable.newFrom({"BarricadeGhost": gdjs.Test_32SceneCode.GDBarricadeGhostObjects3});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBarricadeObjects3Objects = Hashtable.newFrom({"Barricade": gdjs.Test_32SceneCode.GDBarricadeObjects3});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBarricadeGhostObjects3Objects = Hashtable.newFrom({"BarricadeGhost": gdjs.Test_32SceneCode.GDBarricadeGhostObjects3});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBarricadeShortObjects3Objects = Hashtable.newFrom({"BarricadeShort": gdjs.Test_32SceneCode.GDBarricadeShortObjects3});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBarricadeGhostObjects3Objects = Hashtable.newFrom({"BarricadeGhost": gdjs.Test_32SceneCode.GDBarricadeGhostObjects3});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBarricadeSpikesObjects3Objects = Hashtable.newFrom({"BarricadeSpikes": gdjs.Test_32SceneCode.GDBarricadeSpikesObjects3});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBarricadeGhostObjects3Objects = Hashtable.newFrom({"BarricadeGhost": gdjs.Test_32SceneCode.GDBarricadeGhostObjects3});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDWallObjects3Objects = Hashtable.newFrom({"Wall": gdjs.Test_32SceneCode.GDWallObjects3});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBarricadeObjects3Objects = Hashtable.newFrom({"Barricade": gdjs.Test_32SceneCode.GDBarricadeObjects3});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBarricadeShortGhostObjects3Objects = Hashtable.newFrom({"BarricadeShortGhost": gdjs.Test_32SceneCode.GDBarricadeShortGhostObjects3});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBarricadeObjects3Objects = Hashtable.newFrom({"Barricade": gdjs.Test_32SceneCode.GDBarricadeObjects3});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBarricadeShortGhostObjects3Objects = Hashtable.newFrom({"BarricadeShortGhost": gdjs.Test_32SceneCode.GDBarricadeShortGhostObjects3});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBarricadeShortObjects3Objects = Hashtable.newFrom({"BarricadeShort": gdjs.Test_32SceneCode.GDBarricadeShortObjects3});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBarricadeShortGhostObjects3Objects = Hashtable.newFrom({"BarricadeShortGhost": gdjs.Test_32SceneCode.GDBarricadeShortGhostObjects3});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBarricadeSpikesObjects3Objects = Hashtable.newFrom({"BarricadeSpikes": gdjs.Test_32SceneCode.GDBarricadeSpikesObjects3});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBarricadeShortGhostObjects3Objects = Hashtable.newFrom({"BarricadeShortGhost": gdjs.Test_32SceneCode.GDBarricadeShortGhostObjects3});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDWallObjects3Objects = Hashtable.newFrom({"Wall": gdjs.Test_32SceneCode.GDWallObjects3});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBarricadeShortObjects3Objects = Hashtable.newFrom({"BarricadeShort": gdjs.Test_32SceneCode.GDBarricadeShortObjects3});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBarricadeSpikesGhostObjects2Objects = Hashtable.newFrom({"BarricadeSpikesGhost": gdjs.Test_32SceneCode.GDBarricadeSpikesGhostObjects2});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBarricadeObjects2Objects = Hashtable.newFrom({"Barricade": gdjs.Test_32SceneCode.GDBarricadeObjects2});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBarricadeSpikesGhostObjects2Objects = Hashtable.newFrom({"BarricadeSpikesGhost": gdjs.Test_32SceneCode.GDBarricadeSpikesGhostObjects2});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBarricadeShortObjects2Objects = Hashtable.newFrom({"BarricadeShort": gdjs.Test_32SceneCode.GDBarricadeShortObjects2});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBarricadeSpikesGhostObjects2Objects = Hashtable.newFrom({"BarricadeSpikesGhost": gdjs.Test_32SceneCode.GDBarricadeSpikesGhostObjects2});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBarricadeSpikesObjects2Objects = Hashtable.newFrom({"BarricadeSpikes": gdjs.Test_32SceneCode.GDBarricadeSpikesObjects2});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBarricadeSpikesGhostObjects2Objects = Hashtable.newFrom({"BarricadeSpikesGhost": gdjs.Test_32SceneCode.GDBarricadeSpikesGhostObjects2});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDWallObjects2Objects = Hashtable.newFrom({"Wall": gdjs.Test_32SceneCode.GDWallObjects2});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBarricadeSpikesObjects2Objects = Hashtable.newFrom({"BarricadeSpikes": gdjs.Test_32SceneCode.GDBarricadeSpikesObjects2});gdjs.Test_32SceneCode.eventsList34 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Barricade"), gdjs.Test_32SceneCode.GDBarricadeObjects3);
gdjs.copyArray(runtimeScene.getObjects("BarricadeGhost"), gdjs.Test_32SceneCode.GDBarricadeGhostObjects3);
gdjs.copyArray(runtimeScene.getObjects("BarricadeShort"), gdjs.Test_32SceneCode.GDBarricadeShortObjects3);
gdjs.copyArray(runtimeScene.getObjects("BarricadeSpikes"), gdjs.Test_32SceneCode.GDBarricadeSpikesObjects3);
gdjs.copyArray(gdjs.Test_32SceneCode.GDPlayerObjects2, gdjs.Test_32SceneCode.GDPlayerObjects3);

gdjs.copyArray(runtimeScene.getObjects("Wall"), gdjs.Test_32SceneCode.GDWallObjects3);

gdjs.Test_32SceneCode.condition0IsTrue_0.val = false;
gdjs.Test_32SceneCode.condition1IsTrue_0.val = false;
gdjs.Test_32SceneCode.condition2IsTrue_0.val = false;
gdjs.Test_32SceneCode.condition3IsTrue_0.val = false;
gdjs.Test_32SceneCode.condition4IsTrue_0.val = false;
gdjs.Test_32SceneCode.condition5IsTrue_0.val = false;
gdjs.Test_32SceneCode.condition6IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Test_32SceneCode.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.Test_32SceneCode.GDPlayerObjects3[i].getVariableString(gdjs.Test_32SceneCode.GDPlayerObjects3[i].getVariables().getFromIndex(2)) == "Barricade" ) {
        gdjs.Test_32SceneCode.condition0IsTrue_0.val = true;
        gdjs.Test_32SceneCode.GDPlayerObjects3[k] = gdjs.Test_32SceneCode.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Test_32SceneCode.GDPlayerObjects3.length = k;}if ( gdjs.Test_32SceneCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Test_32SceneCode.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.Test_32SceneCode.GDPlayerObjects3[i].getVariableNumber(gdjs.Test_32SceneCode.GDPlayerObjects3[i].getVariables().getFromIndex(1)) >= (gdjs.RuntimeObject.getVariableNumber(((gdjs.Test_32SceneCode.GDBarricadeObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Test_32SceneCode.GDBarricadeObjects3[0].getVariables()).getFromIndex(1))) ) {
        gdjs.Test_32SceneCode.condition1IsTrue_0.val = true;
        gdjs.Test_32SceneCode.GDPlayerObjects3[k] = gdjs.Test_32SceneCode.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Test_32SceneCode.GDPlayerObjects3.length = k;}if ( gdjs.Test_32SceneCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Test_32SceneCode.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.Test_32SceneCode.GDPlayerObjects3[i].getTimerElapsedTimeInSecondsOrNaN("BuildTimer") > 0.5 ) {
        gdjs.Test_32SceneCode.condition2IsTrue_0.val = true;
        gdjs.Test_32SceneCode.GDPlayerObjects3[k] = gdjs.Test_32SceneCode.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Test_32SceneCode.GDPlayerObjects3.length = k;}if ( gdjs.Test_32SceneCode.condition2IsTrue_0.val ) {
{
gdjs.Test_32SceneCode.condition3IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBarricadeGhostObjects3Objects, gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBarricadeObjects3Objects, true, runtimeScene, false);
}if ( gdjs.Test_32SceneCode.condition3IsTrue_0.val ) {
{
gdjs.Test_32SceneCode.condition4IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBarricadeGhostObjects3Objects, gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBarricadeShortObjects3Objects, true, runtimeScene, false);
}if ( gdjs.Test_32SceneCode.condition4IsTrue_0.val ) {
{
gdjs.Test_32SceneCode.condition5IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBarricadeGhostObjects3Objects, gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBarricadeSpikesObjects3Objects, true, runtimeScene, false);
}if ( gdjs.Test_32SceneCode.condition5IsTrue_0.val ) {
{
gdjs.Test_32SceneCode.condition6IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBarricadeGhostObjects3Objects, gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDWallObjects3Objects, true, runtimeScene, false);
}}
}
}
}
}
}
if (gdjs.Test_32SceneCode.condition6IsTrue_0.val) {
/* Reuse gdjs.Test_32SceneCode.GDPlayerObjects3 */
/* Reuse gdjs.Test_32SceneCode.GDBarricadeObjects3 */
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBarricadeObjects3Objects, 32 * (Math.round((gdjs.evtTools.input.getMouseX(runtimeScene, "", 0) - 16) / 32)), 32 * (Math.round((gdjs.evtTools.input.getMouseY(runtimeScene, "", 0) - 32) / 32)), "Base Layer");
}{for(var i = 0, len = gdjs.Test_32SceneCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDPlayerObjects3[i].returnVariable(gdjs.Test_32SceneCode.GDPlayerObjects3[i].getVariables().getFromIndex(1)).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.Test_32SceneCode.GDBarricadeObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Test_32SceneCode.GDBarricadeObjects3[0].getVariables()).getFromIndex(1))));
}
}{for(var i = 0, len = gdjs.Test_32SceneCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDPlayerObjects3[i].resetTimer("BuildTimer");
}
}{for(var i = 0, len = gdjs.Test_32SceneCode.GDBarricadeObjects3.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDBarricadeObjects3[i].setZOrder((gdjs.Test_32SceneCode.GDBarricadeObjects3[i].getCenterYInScene()));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Barricade"), gdjs.Test_32SceneCode.GDBarricadeObjects3);
gdjs.copyArray(runtimeScene.getObjects("BarricadeShort"), gdjs.Test_32SceneCode.GDBarricadeShortObjects3);
gdjs.copyArray(runtimeScene.getObjects("BarricadeShortGhost"), gdjs.Test_32SceneCode.GDBarricadeShortGhostObjects3);
gdjs.copyArray(runtimeScene.getObjects("BarricadeSpikes"), gdjs.Test_32SceneCode.GDBarricadeSpikesObjects3);
gdjs.copyArray(gdjs.Test_32SceneCode.GDPlayerObjects2, gdjs.Test_32SceneCode.GDPlayerObjects3);

gdjs.copyArray(runtimeScene.getObjects("Wall"), gdjs.Test_32SceneCode.GDWallObjects3);

gdjs.Test_32SceneCode.condition0IsTrue_0.val = false;
gdjs.Test_32SceneCode.condition1IsTrue_0.val = false;
gdjs.Test_32SceneCode.condition2IsTrue_0.val = false;
gdjs.Test_32SceneCode.condition3IsTrue_0.val = false;
gdjs.Test_32SceneCode.condition4IsTrue_0.val = false;
gdjs.Test_32SceneCode.condition5IsTrue_0.val = false;
gdjs.Test_32SceneCode.condition6IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Test_32SceneCode.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.Test_32SceneCode.GDPlayerObjects3[i].getVariableString(gdjs.Test_32SceneCode.GDPlayerObjects3[i].getVariables().getFromIndex(2)) == "Cover" ) {
        gdjs.Test_32SceneCode.condition0IsTrue_0.val = true;
        gdjs.Test_32SceneCode.GDPlayerObjects3[k] = gdjs.Test_32SceneCode.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Test_32SceneCode.GDPlayerObjects3.length = k;}if ( gdjs.Test_32SceneCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Test_32SceneCode.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.Test_32SceneCode.GDPlayerObjects3[i].getVariableNumber(gdjs.Test_32SceneCode.GDPlayerObjects3[i].getVariables().getFromIndex(1)) >= (gdjs.RuntimeObject.getVariableNumber(((gdjs.Test_32SceneCode.GDBarricadeShortObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Test_32SceneCode.GDBarricadeShortObjects3[0].getVariables()).getFromIndex(1))) ) {
        gdjs.Test_32SceneCode.condition1IsTrue_0.val = true;
        gdjs.Test_32SceneCode.GDPlayerObjects3[k] = gdjs.Test_32SceneCode.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Test_32SceneCode.GDPlayerObjects3.length = k;}if ( gdjs.Test_32SceneCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Test_32SceneCode.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.Test_32SceneCode.GDPlayerObjects3[i].getTimerElapsedTimeInSecondsOrNaN("BuildTimer") > 0.5 ) {
        gdjs.Test_32SceneCode.condition2IsTrue_0.val = true;
        gdjs.Test_32SceneCode.GDPlayerObjects3[k] = gdjs.Test_32SceneCode.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Test_32SceneCode.GDPlayerObjects3.length = k;}if ( gdjs.Test_32SceneCode.condition2IsTrue_0.val ) {
{
gdjs.Test_32SceneCode.condition3IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBarricadeShortGhostObjects3Objects, gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBarricadeObjects3Objects, true, runtimeScene, false);
}if ( gdjs.Test_32SceneCode.condition3IsTrue_0.val ) {
{
gdjs.Test_32SceneCode.condition4IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBarricadeShortGhostObjects3Objects, gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBarricadeShortObjects3Objects, true, runtimeScene, false);
}if ( gdjs.Test_32SceneCode.condition4IsTrue_0.val ) {
{
gdjs.Test_32SceneCode.condition5IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBarricadeShortGhostObjects3Objects, gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBarricadeSpikesObjects3Objects, true, runtimeScene, false);
}if ( gdjs.Test_32SceneCode.condition5IsTrue_0.val ) {
{
gdjs.Test_32SceneCode.condition6IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBarricadeShortGhostObjects3Objects, gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDWallObjects3Objects, true, runtimeScene, false);
}}
}
}
}
}
}
if (gdjs.Test_32SceneCode.condition6IsTrue_0.val) {
/* Reuse gdjs.Test_32SceneCode.GDPlayerObjects3 */
/* Reuse gdjs.Test_32SceneCode.GDBarricadeShortObjects3 */
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBarricadeShortObjects3Objects, 32 * (Math.round((gdjs.evtTools.input.getMouseX(runtimeScene, "", 0) - 16) / 32)), 32 * (Math.round((gdjs.evtTools.input.getMouseY(runtimeScene, "", 0) - 16) / 32)), "Base Layer");
}{for(var i = 0, len = gdjs.Test_32SceneCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDPlayerObjects3[i].returnVariable(gdjs.Test_32SceneCode.GDPlayerObjects3[i].getVariables().getFromIndex(1)).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.Test_32SceneCode.GDBarricadeShortObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Test_32SceneCode.GDBarricadeShortObjects3[0].getVariables()).getFromIndex(1))));
}
}{for(var i = 0, len = gdjs.Test_32SceneCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDPlayerObjects3[i].resetTimer("BuildTimer");
}
}{for(var i = 0, len = gdjs.Test_32SceneCode.GDBarricadeShortObjects3.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDBarricadeShortObjects3[i].setZOrder((gdjs.Test_32SceneCode.GDBarricadeShortObjects3[i].getCenterYInScene()));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Barricade"), gdjs.Test_32SceneCode.GDBarricadeObjects2);
gdjs.copyArray(runtimeScene.getObjects("BarricadeShort"), gdjs.Test_32SceneCode.GDBarricadeShortObjects2);
gdjs.copyArray(runtimeScene.getObjects("BarricadeSpikes"), gdjs.Test_32SceneCode.GDBarricadeSpikesObjects2);
gdjs.copyArray(runtimeScene.getObjects("BarricadeSpikesGhost"), gdjs.Test_32SceneCode.GDBarricadeSpikesGhostObjects2);
/* Reuse gdjs.Test_32SceneCode.GDPlayerObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Wall"), gdjs.Test_32SceneCode.GDWallObjects2);

gdjs.Test_32SceneCode.condition0IsTrue_0.val = false;
gdjs.Test_32SceneCode.condition1IsTrue_0.val = false;
gdjs.Test_32SceneCode.condition2IsTrue_0.val = false;
gdjs.Test_32SceneCode.condition3IsTrue_0.val = false;
gdjs.Test_32SceneCode.condition4IsTrue_0.val = false;
gdjs.Test_32SceneCode.condition5IsTrue_0.val = false;
gdjs.Test_32SceneCode.condition6IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Test_32SceneCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Test_32SceneCode.GDPlayerObjects2[i].getVariableString(gdjs.Test_32SceneCode.GDPlayerObjects2[i].getVariables().getFromIndex(2)) == "Spikes" ) {
        gdjs.Test_32SceneCode.condition0IsTrue_0.val = true;
        gdjs.Test_32SceneCode.GDPlayerObjects2[k] = gdjs.Test_32SceneCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Test_32SceneCode.GDPlayerObjects2.length = k;}if ( gdjs.Test_32SceneCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Test_32SceneCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Test_32SceneCode.GDPlayerObjects2[i].getVariableNumber(gdjs.Test_32SceneCode.GDPlayerObjects2[i].getVariables().getFromIndex(1)) >= (gdjs.RuntimeObject.getVariableNumber(((gdjs.Test_32SceneCode.GDBarricadeSpikesObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Test_32SceneCode.GDBarricadeSpikesObjects2[0].getVariables()).getFromIndex(1))) ) {
        gdjs.Test_32SceneCode.condition1IsTrue_0.val = true;
        gdjs.Test_32SceneCode.GDPlayerObjects2[k] = gdjs.Test_32SceneCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Test_32SceneCode.GDPlayerObjects2.length = k;}if ( gdjs.Test_32SceneCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Test_32SceneCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Test_32SceneCode.GDPlayerObjects2[i].getTimerElapsedTimeInSecondsOrNaN("BuildTimer") > 0.5 ) {
        gdjs.Test_32SceneCode.condition2IsTrue_0.val = true;
        gdjs.Test_32SceneCode.GDPlayerObjects2[k] = gdjs.Test_32SceneCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Test_32SceneCode.GDPlayerObjects2.length = k;}if ( gdjs.Test_32SceneCode.condition2IsTrue_0.val ) {
{
gdjs.Test_32SceneCode.condition3IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBarricadeSpikesGhostObjects2Objects, gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBarricadeObjects2Objects, true, runtimeScene, false);
}if ( gdjs.Test_32SceneCode.condition3IsTrue_0.val ) {
{
gdjs.Test_32SceneCode.condition4IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBarricadeSpikesGhostObjects2Objects, gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBarricadeShortObjects2Objects, true, runtimeScene, false);
}if ( gdjs.Test_32SceneCode.condition4IsTrue_0.val ) {
{
gdjs.Test_32SceneCode.condition5IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBarricadeSpikesGhostObjects2Objects, gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBarricadeSpikesObjects2Objects, true, runtimeScene, false);
}if ( gdjs.Test_32SceneCode.condition5IsTrue_0.val ) {
{
gdjs.Test_32SceneCode.condition6IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBarricadeSpikesGhostObjects2Objects, gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDWallObjects2Objects, true, runtimeScene, false);
}}
}
}
}
}
}
if (gdjs.Test_32SceneCode.condition6IsTrue_0.val) {
/* Reuse gdjs.Test_32SceneCode.GDPlayerObjects2 */
/* Reuse gdjs.Test_32SceneCode.GDBarricadeSpikesObjects2 */
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBarricadeSpikesObjects2Objects, 32 * (Math.round((gdjs.evtTools.input.getMouseX(runtimeScene, "", 0) - 16) / 32)), 32 * (Math.round((gdjs.evtTools.input.getMouseY(runtimeScene, "", 0) - 16) / 32)), "Base Layer");
}{for(var i = 0, len = gdjs.Test_32SceneCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDPlayerObjects2[i].returnVariable(gdjs.Test_32SceneCode.GDPlayerObjects2[i].getVariables().getFromIndex(1)).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.Test_32SceneCode.GDBarricadeSpikesObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Test_32SceneCode.GDBarricadeSpikesObjects2[0].getVariables()).getFromIndex(1))));
}
}{for(var i = 0, len = gdjs.Test_32SceneCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDPlayerObjects2[i].resetTimer("BuildTimer");
}
}{for(var i = 0, len = gdjs.Test_32SceneCode.GDBarricadeSpikesObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDBarricadeSpikesObjects2[i].setZOrder((gdjs.Test_32SceneCode.GDBarricadeSpikesObjects2[i].getPointY("")) - 32);
}
}}

}


};gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDPlayerObjects1ObjectsGDgdjs_46Test_9532SceneCode_46GDZambamboObjects1Objects = Hashtable.newFrom({"Player": gdjs.Test_32SceneCode.GDPlayerObjects1, "Zambambo": gdjs.Test_32SceneCode.GDZambamboObjects1});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBarricadeSpikesObjects1Objects = Hashtable.newFrom({"BarricadeSpikes": gdjs.Test_32SceneCode.GDBarricadeSpikesObjects1});gdjs.Test_32SceneCode.eventsList35 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("MouseObject"), gdjs.Test_32SceneCode.GDMouseObjectObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Test_32SceneCode.GDPlayerObjects2);

gdjs.Test_32SceneCode.condition0IsTrue_0.val = false;
gdjs.Test_32SceneCode.condition1IsTrue_0.val = false;
{
gdjs.Test_32SceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.Test_32SceneCode.condition0IsTrue_0.val ) {
{
gdjs.Test_32SceneCode.condition1IsTrue_0.val = gdjs.evtTools.object.distanceTest(gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDPlayerObjects2Objects, gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDMouseObjectObjects2Objects, (gdjs.RuntimeObject.getVariableNumber(((gdjs.Test_32SceneCode.GDPlayerObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Test_32SceneCode.GDPlayerObjects2[0].getVariables()).getFromIndex(3))), false);
}}
if (gdjs.Test_32SceneCode.condition1IsTrue_0.val) {

{ //Subevents
gdjs.Test_32SceneCode.eventsList34(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Barricade"), gdjs.Test_32SceneCode.GDBarricadeObjects2);

gdjs.Test_32SceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Test_32SceneCode.GDBarricadeObjects2.length;i<l;++i) {
    if ( gdjs.Test_32SceneCode.GDBarricadeObjects2[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.Test_32SceneCode.condition0IsTrue_0.val = true;
        gdjs.Test_32SceneCode.GDBarricadeObjects2[k] = gdjs.Test_32SceneCode.GDBarricadeObjects2[i];
        ++k;
    }
}
gdjs.Test_32SceneCode.GDBarricadeObjects2.length = k;}if (gdjs.Test_32SceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Test_32SceneCode.GDBarricadeObjects2 */
{for(var i = 0, len = gdjs.Test_32SceneCode.GDBarricadeObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDBarricadeObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("BarricadeShort"), gdjs.Test_32SceneCode.GDBarricadeShortObjects2);

gdjs.Test_32SceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Test_32SceneCode.GDBarricadeShortObjects2.length;i<l;++i) {
    if ( gdjs.Test_32SceneCode.GDBarricadeShortObjects2[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.Test_32SceneCode.condition0IsTrue_0.val = true;
        gdjs.Test_32SceneCode.GDBarricadeShortObjects2[k] = gdjs.Test_32SceneCode.GDBarricadeShortObjects2[i];
        ++k;
    }
}
gdjs.Test_32SceneCode.GDBarricadeShortObjects2.length = k;}if (gdjs.Test_32SceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Test_32SceneCode.GDBarricadeShortObjects2 */
{for(var i = 0, len = gdjs.Test_32SceneCode.GDBarricadeShortObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDBarricadeShortObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("BarricadeSpikes"), gdjs.Test_32SceneCode.GDBarricadeSpikesObjects2);

gdjs.Test_32SceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Test_32SceneCode.GDBarricadeSpikesObjects2.length;i<l;++i) {
    if ( gdjs.Test_32SceneCode.GDBarricadeSpikesObjects2[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.Test_32SceneCode.condition0IsTrue_0.val = true;
        gdjs.Test_32SceneCode.GDBarricadeSpikesObjects2[k] = gdjs.Test_32SceneCode.GDBarricadeSpikesObjects2[i];
        ++k;
    }
}
gdjs.Test_32SceneCode.GDBarricadeSpikesObjects2.length = k;}if (gdjs.Test_32SceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Test_32SceneCode.GDBarricadeSpikesObjects2 */
{for(var i = 0, len = gdjs.Test_32SceneCode.GDBarricadeSpikesObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDBarricadeSpikesObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Barricade"), gdjs.Test_32SceneCode.GDBarricadeObjects2);

gdjs.Test_32SceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Test_32SceneCode.GDBarricadeObjects2.length;i<l;++i) {
    if ( gdjs.Test_32SceneCode.GDBarricadeObjects2[i].getBehavior("Health").IsJustDamaged((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.Test_32SceneCode.condition0IsTrue_0.val = true;
        gdjs.Test_32SceneCode.GDBarricadeObjects2[k] = gdjs.Test_32SceneCode.GDBarricadeObjects2[i];
        ++k;
    }
}
gdjs.Test_32SceneCode.GDBarricadeObjects2.length = k;}if (gdjs.Test_32SceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Test_32SceneCode.GDBarricadeObjects2 */
{for(var i = 0, len = gdjs.Test_32SceneCode.GDBarricadeObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDBarricadeObjects2[i].returnVariable(gdjs.Test_32SceneCode.GDBarricadeObjects2[i].getVariables().getFromIndex(0)).add(1);
}
}{for(var i = 0, len = gdjs.Test_32SceneCode.GDBarricadeObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDBarricadeObjects2[i].setAnimationName("BarricadeD" + (gdjs.RuntimeObject.getVariableString(gdjs.Test_32SceneCode.GDBarricadeObjects2[i].getVariables().getFromIndex(0))));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("BarricadeShort"), gdjs.Test_32SceneCode.GDBarricadeShortObjects2);

gdjs.Test_32SceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Test_32SceneCode.GDBarricadeShortObjects2.length;i<l;++i) {
    if ( gdjs.Test_32SceneCode.GDBarricadeShortObjects2[i].getBehavior("Health").IsJustDamaged((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.Test_32SceneCode.condition0IsTrue_0.val = true;
        gdjs.Test_32SceneCode.GDBarricadeShortObjects2[k] = gdjs.Test_32SceneCode.GDBarricadeShortObjects2[i];
        ++k;
    }
}
gdjs.Test_32SceneCode.GDBarricadeShortObjects2.length = k;}if (gdjs.Test_32SceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Test_32SceneCode.GDBarricadeShortObjects2 */
{for(var i = 0, len = gdjs.Test_32SceneCode.GDBarricadeShortObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDBarricadeShortObjects2[i].returnVariable(gdjs.Test_32SceneCode.GDBarricadeShortObjects2[i].getVariables().getFromIndex(0)).add(1);
}
}{for(var i = 0, len = gdjs.Test_32SceneCode.GDBarricadeShortObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDBarricadeShortObjects2[i].setAnimationName("BarricadeD" + (gdjs.RuntimeObject.getVariableString(gdjs.Test_32SceneCode.GDBarricadeShortObjects2[i].getVariables().getFromIndex(0))));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("BarricadeSpikes"), gdjs.Test_32SceneCode.GDBarricadeSpikesObjects2);

gdjs.Test_32SceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Test_32SceneCode.GDBarricadeSpikesObjects2.length;i<l;++i) {
    if ( gdjs.Test_32SceneCode.GDBarricadeSpikesObjects2[i].getBehavior("Health").IsJustDamaged((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.Test_32SceneCode.condition0IsTrue_0.val = true;
        gdjs.Test_32SceneCode.GDBarricadeSpikesObjects2[k] = gdjs.Test_32SceneCode.GDBarricadeSpikesObjects2[i];
        ++k;
    }
}
gdjs.Test_32SceneCode.GDBarricadeSpikesObjects2.length = k;}if (gdjs.Test_32SceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Test_32SceneCode.GDBarricadeSpikesObjects2 */
{for(var i = 0, len = gdjs.Test_32SceneCode.GDBarricadeSpikesObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDBarricadeSpikesObjects2[i].returnVariable(gdjs.Test_32SceneCode.GDBarricadeSpikesObjects2[i].getVariables().getFromIndex(0)).add(1);
}
}{for(var i = 0, len = gdjs.Test_32SceneCode.GDBarricadeSpikesObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDBarricadeSpikesObjects2[i].setAnimationName("BarricadeD" + (gdjs.RuntimeObject.getVariableString(gdjs.Test_32SceneCode.GDBarricadeSpikesObjects2[i].getVariables().getFromIndex(0))));
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("BarricadeSpikes"), gdjs.Test_32SceneCode.GDBarricadeSpikesObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Test_32SceneCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("Zambambo"), gdjs.Test_32SceneCode.GDZambamboObjects1);

gdjs.Test_32SceneCode.condition0IsTrue_0.val = false;
{
gdjs.Test_32SceneCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDPlayerObjects1ObjectsGDgdjs_46Test_9532SceneCode_46GDZambamboObjects1Objects, gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBarricadeSpikesObjects1Objects, false, runtimeScene, false);
}if (gdjs.Test_32SceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Test_32SceneCode.GDBarricadeSpikesObjects1 */
/* Reuse gdjs.Test_32SceneCode.GDPlayerObjects1 */
/* Reuse gdjs.Test_32SceneCode.GDZambamboObjects1 */
{for(var i = 0, len = gdjs.Test_32SceneCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDPlayerObjects1[i].getBehavior("Health").Hit((gdjs.RuntimeObject.getVariableNumber(((gdjs.Test_32SceneCode.GDBarricadeSpikesObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Test_32SceneCode.GDBarricadeSpikesObjects1[0].getVariables()).getFromIndex(2))), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.Test_32SceneCode.GDZambamboObjects1.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDZambamboObjects1[i].getBehavior("Health").Hit((gdjs.RuntimeObject.getVariableNumber(((gdjs.Test_32SceneCode.GDBarricadeSpikesObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Test_32SceneCode.GDBarricadeSpikesObjects1[0].getVariables()).getFromIndex(2))), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Test_32SceneCode.GDBarricadeSpikesObjects1.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDBarricadeSpikesObjects1[i].getBehavior("Health").Hit(1, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


};gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Test_32SceneCode.GDPlayerObjects2});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBuildTokenObjects2Objects = Hashtable.newFrom({"BuildToken": gdjs.Test_32SceneCode.GDBuildTokenObjects2});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Test_32SceneCode.GDPlayerObjects1});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDHealthTokenObjects1Objects = Hashtable.newFrom({"HealthToken": gdjs.Test_32SceneCode.GDHealthTokenObjects1});gdjs.Test_32SceneCode.eventsList36 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("BuildToken"), gdjs.Test_32SceneCode.GDBuildTokenObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Test_32SceneCode.GDPlayerObjects2);

gdjs.Test_32SceneCode.condition0IsTrue_0.val = false;
{
gdjs.Test_32SceneCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDPlayerObjects2Objects, gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBuildTokenObjects2Objects, false, runtimeScene, false);
}if (gdjs.Test_32SceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Assault"), gdjs.Test_32SceneCode.GDAssaultObjects2);
/* Reuse gdjs.Test_32SceneCode.GDBuildTokenObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Pistol"), gdjs.Test_32SceneCode.GDPistolObjects2);
/* Reuse gdjs.Test_32SceneCode.GDPlayerObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Rifle"), gdjs.Test_32SceneCode.GDRifleObjects2);
gdjs.copyArray(runtimeScene.getObjects("Shotgun"), gdjs.Test_32SceneCode.GDShotgunObjects2);
{for(var i = 0, len = gdjs.Test_32SceneCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDPlayerObjects2[i].returnVariable(gdjs.Test_32SceneCode.GDPlayerObjects2[i].getVariables().getFromIndex(1)).add((gdjs.RuntimeObject.getVariableNumber(((gdjs.Test_32SceneCode.GDBuildTokenObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Test_32SceneCode.GDBuildTokenObjects2[0].getVariables()).getFromIndex(0))));
}
}{for(var i = 0, len = gdjs.Test_32SceneCode.GDPistolObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDPistolObjects2[i].returnVariable(gdjs.Test_32SceneCode.GDPistolObjects2[i].getVariables().getFromIndex(2)).add((gdjs.RuntimeObject.getVariableNumber(((gdjs.Test_32SceneCode.GDBuildTokenObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Test_32SceneCode.GDBuildTokenObjects2[0].getVariables()).getFromIndex(1))));
}
}{for(var i = 0, len = gdjs.Test_32SceneCode.GDShotgunObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDShotgunObjects2[i].returnVariable(gdjs.Test_32SceneCode.GDShotgunObjects2[i].getVariables().getFromIndex(2)).add((gdjs.RuntimeObject.getVariableNumber(((gdjs.Test_32SceneCode.GDBuildTokenObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Test_32SceneCode.GDBuildTokenObjects2[0].getVariables()).getFromIndex(2))));
}
}{for(var i = 0, len = gdjs.Test_32SceneCode.GDRifleObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDRifleObjects2[i].returnVariable(gdjs.Test_32SceneCode.GDRifleObjects2[i].getVariables().getFromIndex(2)).add((gdjs.RuntimeObject.getVariableNumber(((gdjs.Test_32SceneCode.GDBuildTokenObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Test_32SceneCode.GDBuildTokenObjects2[0].getVariables()).getFromIndex(3))));
}
}{for(var i = 0, len = gdjs.Test_32SceneCode.GDAssaultObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDAssaultObjects2[i].returnVariable(gdjs.Test_32SceneCode.GDAssaultObjects2[i].getVariables().getFromIndex(2)).add((gdjs.RuntimeObject.getVariableNumber(((gdjs.Test_32SceneCode.GDBuildTokenObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Test_32SceneCode.GDBuildTokenObjects2[0].getVariables()).getFromIndex(4))));
}
}{for(var i = 0, len = gdjs.Test_32SceneCode.GDBuildTokenObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDBuildTokenObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("HealthToken"), gdjs.Test_32SceneCode.GDHealthTokenObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Test_32SceneCode.GDPlayerObjects1);

gdjs.Test_32SceneCode.condition0IsTrue_0.val = false;
{
gdjs.Test_32SceneCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDPlayerObjects1Objects, gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDHealthTokenObjects1Objects, false, runtimeScene, false);
}if (gdjs.Test_32SceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Test_32SceneCode.GDHealthTokenObjects1 */
/* Reuse gdjs.Test_32SceneCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.Test_32SceneCode.GDHealthTokenObjects1.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDHealthTokenObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Test_32SceneCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDPlayerObjects1[i].getBehavior("Health").Heal(10, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


};gdjs.Test_32SceneCode.eventsList37 = function(runtimeScene) {

{



}


{


{
gdjs.copyArray(runtimeScene.getObjects("DayText"), gdjs.Test_32SceneCode.GDDayTextObjects2);
gdjs.copyArray(runtimeScene.getObjects("NightText"), gdjs.Test_32SceneCode.GDNightTextObjects2);
gdjs.copyArray(runtimeScene.getObjects("TimeText"), gdjs.Test_32SceneCode.GDTimeTextObjects2);
gdjs.copyArray(runtimeScene.getObjects("TimeText2"), gdjs.Test_32SceneCode.GDTimeText2Objects2);
{gdjs.evtTools.camera.setLayerAmbientLightColor(runtimeScene, "Lighting", gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().getFromIndex(2)) + ";" + gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().getFromIndex(2)) + ";" + gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().getFromIndex(2)));
}{for(var i = 0, len = gdjs.Test_32SceneCode.GDTimeTextObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDTimeTextObjects2[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().getFromIndex(2)));
}
}{for(var i = 0, len = gdjs.Test_32SceneCode.GDTimeText2Objects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDTimeText2Objects2[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().getFromIndex(3)));
}
}{for(var i = 0, len = gdjs.Test_32SceneCode.GDDayTextObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDDayTextObjects2[i].setString("Day " + gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().getFromIndex(4)));
}
}{for(var i = 0, len = gdjs.Test_32SceneCode.GDNightTextObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDNightTextObjects2[i].setString("Night " + gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().getFromIndex(5)));
}
}}

}


{


gdjs.Test_32SceneCode.condition0IsTrue_0.val = false;
{
gdjs.Test_32SceneCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(3)) == 0;
}if (gdjs.Test_32SceneCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(2).add(gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene));
}}

}


{


gdjs.Test_32SceneCode.condition0IsTrue_0.val = false;
{
gdjs.Test_32SceneCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(2)) > 254;
}if (gdjs.Test_32SceneCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(3).setNumber(1);
}{runtimeScene.getVariables().getFromIndex(6).setNumber(0);
}}

}


{


gdjs.Test_32SceneCode.condition0IsTrue_0.val = false;
{
gdjs.Test_32SceneCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(3)) == 1;
}if (gdjs.Test_32SceneCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(2).sub(gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene));
}}

}


{


gdjs.Test_32SceneCode.condition0IsTrue_0.val = false;
{
gdjs.Test_32SceneCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(2)) < 1;
}if (gdjs.Test_32SceneCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(3).setNumber(0);
}{runtimeScene.getVariables().getFromIndex(7).setNumber(1);
}}

}


};gdjs.Test_32SceneCode.eventsList38 = function(runtimeScene) {

};gdjs.Test_32SceneCode.eventsList39 = function(runtimeScene) {

};gdjs.Test_32SceneCode.eventsList40 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("SpawnPoint"), gdjs.Test_32SceneCode.GDSpawnPointObjects2);

for(gdjs.Test_32SceneCode.forEachIndex3 = 0;gdjs.Test_32SceneCode.forEachIndex3 < gdjs.Test_32SceneCode.GDSpawnPointObjects2.length;++gdjs.Test_32SceneCode.forEachIndex3) {
gdjs.Test_32SceneCode.GDSpawnPointObjects3.length = 0;


gdjs.Test_32SceneCode.forEachTemporary3 = gdjs.Test_32SceneCode.GDSpawnPointObjects2[gdjs.Test_32SceneCode.forEachIndex3];
gdjs.Test_32SceneCode.GDSpawnPointObjects3.push(gdjs.Test_32SceneCode.forEachTemporary3);
gdjs.Test_32SceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Test_32SceneCode.GDSpawnPointObjects3.length;i<l;++i) {
    if ( gdjs.Test_32SceneCode.GDSpawnPointObjects3[i].getVariableNumber(gdjs.Test_32SceneCode.GDSpawnPointObjects3[i].getVariables().getFromIndex(1)) <= gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(8)) ) {
        gdjs.Test_32SceneCode.condition0IsTrue_0.val = true;
        gdjs.Test_32SceneCode.GDSpawnPointObjects3[k] = gdjs.Test_32SceneCode.GDSpawnPointObjects3[i];
        ++k;
    }
}
gdjs.Test_32SceneCode.GDSpawnPointObjects3.length = k;}if (gdjs.Test_32SceneCode.condition0IsTrue_0.val) {
{for(var i = 0, len = gdjs.Test_32SceneCode.GDSpawnPointObjects3.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDSpawnPointObjects3[i].returnVariable(gdjs.Test_32SceneCode.GDSpawnPointObjects3[i].getVariables().getFromIndex(0)).setNumber(1);
}
}}
}

}


};gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDZambamboObjects5Objects = Hashtable.newFrom({"Zambambo": gdjs.Test_32SceneCode.GDZambamboObjects5});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDZambamboHealthObjects5Objects = Hashtable.newFrom({"ZambamboHealth": gdjs.Test_32SceneCode.GDZambamboHealthObjects5});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDZambamboHealthBackObjects5Objects = Hashtable.newFrom({"ZambamboHealthBack": gdjs.Test_32SceneCode.GDZambamboHealthBackObjects5});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBuildTokenObjects5Objects = Hashtable.newFrom({"BuildToken": gdjs.Test_32SceneCode.GDBuildTokenObjects5});gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDHealthTokenObjects5Objects = Hashtable.newFrom({"HealthToken": gdjs.Test_32SceneCode.GDHealthTokenObjects5});gdjs.Test_32SceneCode.eventsList41 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Test_32SceneCode.GDObjectSpawnObjects4, gdjs.Test_32SceneCode.GDObjectSpawnObjects5);


gdjs.Test_32SceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Test_32SceneCode.GDObjectSpawnObjects5.length;i<l;++i) {
    if ( gdjs.Test_32SceneCode.GDObjectSpawnObjects5[i].getVariableNumber(gdjs.Test_32SceneCode.GDObjectSpawnObjects5[i].getVariables().getFromIndex(3)) < 5 ) {
        gdjs.Test_32SceneCode.condition0IsTrue_0.val = true;
        gdjs.Test_32SceneCode.GDObjectSpawnObjects5[k] = gdjs.Test_32SceneCode.GDObjectSpawnObjects5[i];
        ++k;
    }
}
gdjs.Test_32SceneCode.GDObjectSpawnObjects5.length = k;}if (gdjs.Test_32SceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Test_32SceneCode.GDObjectSpawnObjects5 */
gdjs.Test_32SceneCode.GDZambamboObjects5.length = 0;

gdjs.Test_32SceneCode.GDZambamboHealthObjects5.length = 0;

gdjs.Test_32SceneCode.GDZambamboHealthBackObjects5.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDZambamboObjects5Objects, (( gdjs.Test_32SceneCode.GDObjectSpawnObjects5.length === 0 ) ? 0 :gdjs.Test_32SceneCode.GDObjectSpawnObjects5[0].getPointX("")), (( gdjs.Test_32SceneCode.GDObjectSpawnObjects5.length === 0 ) ? 0 :gdjs.Test_32SceneCode.GDObjectSpawnObjects5[0].getPointY("")), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDZambamboHealthObjects5Objects, (( gdjs.Test_32SceneCode.GDZambamboObjects5.length === 0 ) ? 0 :gdjs.Test_32SceneCode.GDZambamboObjects5[0].getPointX("")), (( gdjs.Test_32SceneCode.GDZambamboObjects5.length === 0 ) ? 0 :gdjs.Test_32SceneCode.GDZambamboObjects5[0].getPointY("")) + 64, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDZambamboHealthBackObjects5Objects, (( gdjs.Test_32SceneCode.GDZambamboObjects5.length === 0 ) ? 0 :gdjs.Test_32SceneCode.GDZambamboObjects5[0].getPointX("")), (( gdjs.Test_32SceneCode.GDZambamboObjects5.length === 0 ) ? 0 :gdjs.Test_32SceneCode.GDZambamboObjects5[0].getPointY("")) + 64, "");
}{gdjs.evtTools.linkedObjects.linkObjects(runtimeScene, (gdjs.Test_32SceneCode.GDZambamboObjects5.length !== 0 ? gdjs.Test_32SceneCode.GDZambamboObjects5[0] : null), (gdjs.Test_32SceneCode.GDZambamboHealthObjects5.length !== 0 ? gdjs.Test_32SceneCode.GDZambamboHealthObjects5[0] : null));
}{gdjs.evtTools.linkedObjects.linkObjects(runtimeScene, (gdjs.Test_32SceneCode.GDZambamboObjects5.length !== 0 ? gdjs.Test_32SceneCode.GDZambamboObjects5[0] : null), (gdjs.Test_32SceneCode.GDZambamboHealthBackObjects5.length !== 0 ? gdjs.Test_32SceneCode.GDZambamboHealthBackObjects5[0] : null));
}}

}


{

gdjs.copyArray(gdjs.Test_32SceneCode.GDObjectSpawnObjects4, gdjs.Test_32SceneCode.GDObjectSpawnObjects5);


gdjs.Test_32SceneCode.condition0IsTrue_0.val = false;
gdjs.Test_32SceneCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Test_32SceneCode.GDObjectSpawnObjects5.length;i<l;++i) {
    if ( gdjs.Test_32SceneCode.GDObjectSpawnObjects5[i].getVariableNumber(gdjs.Test_32SceneCode.GDObjectSpawnObjects5[i].getVariables().getFromIndex(3)) < 10 ) {
        gdjs.Test_32SceneCode.condition0IsTrue_0.val = true;
        gdjs.Test_32SceneCode.GDObjectSpawnObjects5[k] = gdjs.Test_32SceneCode.GDObjectSpawnObjects5[i];
        ++k;
    }
}
gdjs.Test_32SceneCode.GDObjectSpawnObjects5.length = k;}if ( gdjs.Test_32SceneCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Test_32SceneCode.GDObjectSpawnObjects5.length;i<l;++i) {
    if ( gdjs.Test_32SceneCode.GDObjectSpawnObjects5[i].getVariableNumber(gdjs.Test_32SceneCode.GDObjectSpawnObjects5[i].getVariables().getFromIndex(3)) > 4 ) {
        gdjs.Test_32SceneCode.condition1IsTrue_0.val = true;
        gdjs.Test_32SceneCode.GDObjectSpawnObjects5[k] = gdjs.Test_32SceneCode.GDObjectSpawnObjects5[i];
        ++k;
    }
}
gdjs.Test_32SceneCode.GDObjectSpawnObjects5.length = k;}}
if (gdjs.Test_32SceneCode.condition1IsTrue_0.val) {
/* Reuse gdjs.Test_32SceneCode.GDObjectSpawnObjects5 */
gdjs.Test_32SceneCode.GDBuildTokenObjects5.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDBuildTokenObjects5Objects, (( gdjs.Test_32SceneCode.GDObjectSpawnObjects5.length === 0 ) ? 0 :gdjs.Test_32SceneCode.GDObjectSpawnObjects5[0].getPointX("")), (( gdjs.Test_32SceneCode.GDObjectSpawnObjects5.length === 0 ) ? 0 :gdjs.Test_32SceneCode.GDObjectSpawnObjects5[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.Test_32SceneCode.GDBuildTokenObjects5.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDBuildTokenObjects5[i].returnVariable(gdjs.Test_32SceneCode.GDBuildTokenObjects5[i].getVariables().getFromIndex(0)).setNumber(gdjs.randomInRange(2, 4) * 5);
}
}{for(var i = 0, len = gdjs.Test_32SceneCode.GDBuildTokenObjects5.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDBuildTokenObjects5[i].returnVariable(gdjs.Test_32SceneCode.GDBuildTokenObjects5[i].getVariables().getFromIndex(1)).setNumber(gdjs.randomInRange(2, 4) * 5);
}
}{for(var i = 0, len = gdjs.Test_32SceneCode.GDBuildTokenObjects5.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDBuildTokenObjects5[i].returnVariable(gdjs.Test_32SceneCode.GDBuildTokenObjects5[i].getVariables().getFromIndex(2)).setNumber(gdjs.randomInRange(2, 4) * 5);
}
}{for(var i = 0, len = gdjs.Test_32SceneCode.GDBuildTokenObjects5.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDBuildTokenObjects5[i].returnVariable(gdjs.Test_32SceneCode.GDBuildTokenObjects5[i].getVariables().getFromIndex(3)).setNumber(gdjs.randomInRange(2, 4) * 5);
}
}{for(var i = 0, len = gdjs.Test_32SceneCode.GDBuildTokenObjects5.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDBuildTokenObjects5[i].returnVariable(gdjs.Test_32SceneCode.GDBuildTokenObjects5[i].getVariables().getFromIndex(4)).setNumber(gdjs.randomInRange(2, 4) * 5);
}
}}

}


{

gdjs.copyArray(gdjs.Test_32SceneCode.GDObjectSpawnObjects4, gdjs.Test_32SceneCode.GDObjectSpawnObjects5);


gdjs.Test_32SceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Test_32SceneCode.GDObjectSpawnObjects5.length;i<l;++i) {
    if ( gdjs.Test_32SceneCode.GDObjectSpawnObjects5[i].getVariableNumber(gdjs.Test_32SceneCode.GDObjectSpawnObjects5[i].getVariables().getFromIndex(3)) == 10 ) {
        gdjs.Test_32SceneCode.condition0IsTrue_0.val = true;
        gdjs.Test_32SceneCode.GDObjectSpawnObjects5[k] = gdjs.Test_32SceneCode.GDObjectSpawnObjects5[i];
        ++k;
    }
}
gdjs.Test_32SceneCode.GDObjectSpawnObjects5.length = k;}if (gdjs.Test_32SceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Test_32SceneCode.GDObjectSpawnObjects5 */
gdjs.Test_32SceneCode.GDHealthTokenObjects5.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Test_32SceneCode.mapOfGDgdjs_46Test_9532SceneCode_46GDHealthTokenObjects5Objects, (( gdjs.Test_32SceneCode.GDObjectSpawnObjects5.length === 0 ) ? 0 :gdjs.Test_32SceneCode.GDObjectSpawnObjects5[0].getPointX("")), (( gdjs.Test_32SceneCode.GDObjectSpawnObjects5.length === 0 ) ? 0 :gdjs.Test_32SceneCode.GDObjectSpawnObjects5[0].getPointY("")), "");
}}

}


};gdjs.Test_32SceneCode.eventsList42 = function(runtimeScene) {

};gdjs.Test_32SceneCode.eventsList43 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("ObjectSpawn"), gdjs.Test_32SceneCode.GDObjectSpawnObjects3);

for(gdjs.Test_32SceneCode.forEachIndex4 = 0;gdjs.Test_32SceneCode.forEachIndex4 < gdjs.Test_32SceneCode.GDObjectSpawnObjects3.length;++gdjs.Test_32SceneCode.forEachIndex4) {
gdjs.Test_32SceneCode.GDObjectSpawnObjects4.length = 0;


gdjs.Test_32SceneCode.forEachTemporary4 = gdjs.Test_32SceneCode.GDObjectSpawnObjects3[gdjs.Test_32SceneCode.forEachIndex4];
gdjs.Test_32SceneCode.GDObjectSpawnObjects4.push(gdjs.Test_32SceneCode.forEachTemporary4);
if (true) {
{for(var i = 0, len = gdjs.Test_32SceneCode.GDObjectSpawnObjects4.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDObjectSpawnObjects4[i].returnVariable(gdjs.Test_32SceneCode.GDObjectSpawnObjects4[i].getVariables().getFromIndex(3)).setNumber(gdjs.randomInRange(1, 10));
}
}
{ //Subevents: 
gdjs.Test_32SceneCode.eventsList41(runtimeScene);} //Subevents end.
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("SpawnPoint"), gdjs.Test_32SceneCode.GDSpawnPointObjects2);

for(gdjs.Test_32SceneCode.forEachIndex3 = 0;gdjs.Test_32SceneCode.forEachIndex3 < gdjs.Test_32SceneCode.GDSpawnPointObjects2.length;++gdjs.Test_32SceneCode.forEachIndex3) {
gdjs.Test_32SceneCode.GDSpawnPointObjects3.length = 0;


gdjs.Test_32SceneCode.forEachTemporary3 = gdjs.Test_32SceneCode.GDSpawnPointObjects2[gdjs.Test_32SceneCode.forEachIndex3];
gdjs.Test_32SceneCode.GDSpawnPointObjects3.push(gdjs.Test_32SceneCode.forEachTemporary3);
if (true) {
{for(var i = 0, len = gdjs.Test_32SceneCode.GDSpawnPointObjects3.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDSpawnPointObjects3[i].returnVariable(gdjs.Test_32SceneCode.GDSpawnPointObjects3[i].getVariables().getFromIndex(0)).setNumber(0);
}
}}
}

}


};gdjs.Test_32SceneCode.eventsList44 = function(runtimeScene) {

{


gdjs.Test_32SceneCode.condition0IsTrue_0.val = false;
{
{gdjs.Test_32SceneCode.conditionTrue_1 = gdjs.Test_32SceneCode.condition0IsTrue_0;
gdjs.Test_32SceneCode.condition0IsTrue_1.val = false;
gdjs.Test_32SceneCode.condition1IsTrue_1.val = false;
gdjs.Test_32SceneCode.condition2IsTrue_1.val = false;
{
gdjs.Test_32SceneCode.condition0IsTrue_1.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(3)) == 1;
}if ( gdjs.Test_32SceneCode.condition0IsTrue_1.val ) {
{
gdjs.Test_32SceneCode.condition1IsTrue_1.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(2)) < 125;
}if ( gdjs.Test_32SceneCode.condition1IsTrue_1.val ) {
{
gdjs.Test_32SceneCode.condition2IsTrue_1.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(7)) == 0;
}}
}
gdjs.Test_32SceneCode.conditionTrue_1.val = true && gdjs.Test_32SceneCode.condition0IsTrue_1.val && gdjs.Test_32SceneCode.condition1IsTrue_1.val && gdjs.Test_32SceneCode.condition2IsTrue_1.val;
}
}if (gdjs.Test_32SceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("NightText"), gdjs.Test_32SceneCode.GDNightTextObjects2);
{runtimeScene.getVariables().getFromIndex(5).add(1);
}{runtimeScene.getVariables().getFromIndex(7).setNumber(1);
}{runtimeScene.getVariables().getFromIndex(8).add(1);
}{runtimeScene.getVariables().getFromIndex(6).setNumber(0);
}{for(var i = 0, len = gdjs.Test_32SceneCode.GDNightTextObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDNightTextObjects2[i].setOpacity(255);
}
}{for(var i = 0, len = gdjs.Test_32SceneCode.GDNightTextObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDNightTextObjects2[i].resetTimer("NightTimer");
}
}
{ //Subevents
gdjs.Test_32SceneCode.eventsList40(runtimeScene);} //End of subevents
}

}


{


{
}

}


{


gdjs.Test_32SceneCode.condition0IsTrue_0.val = false;
{
{gdjs.Test_32SceneCode.conditionTrue_1 = gdjs.Test_32SceneCode.condition0IsTrue_0;
gdjs.Test_32SceneCode.condition0IsTrue_1.val = false;
gdjs.Test_32SceneCode.condition1IsTrue_1.val = false;
gdjs.Test_32SceneCode.condition2IsTrue_1.val = false;
{
gdjs.Test_32SceneCode.condition0IsTrue_1.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(3)) == 0;
}if ( gdjs.Test_32SceneCode.condition0IsTrue_1.val ) {
{
gdjs.Test_32SceneCode.condition1IsTrue_1.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(2)) > 125;
}if ( gdjs.Test_32SceneCode.condition1IsTrue_1.val ) {
{
gdjs.Test_32SceneCode.condition2IsTrue_1.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(6)) == 0;
}}
}
gdjs.Test_32SceneCode.conditionTrue_1.val = true && gdjs.Test_32SceneCode.condition0IsTrue_1.val && gdjs.Test_32SceneCode.condition1IsTrue_1.val && gdjs.Test_32SceneCode.condition2IsTrue_1.val;
}
}if (gdjs.Test_32SceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("DayText"), gdjs.Test_32SceneCode.GDDayTextObjects2);
{runtimeScene.getVariables().getFromIndex(4).add(1);
}{runtimeScene.getVariables().getFromIndex(6).setNumber(1);
}{runtimeScene.getVariables().getFromIndex(7).setNumber(0);
}{for(var i = 0, len = gdjs.Test_32SceneCode.GDDayTextObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDDayTextObjects2[i].setOpacity(255);
}
}{for(var i = 0, len = gdjs.Test_32SceneCode.GDDayTextObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDDayTextObjects2[i].resetTimer("DayTimer");
}
}
{ //Subevents
gdjs.Test_32SceneCode.eventsList43(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("DayText"), gdjs.Test_32SceneCode.GDDayTextObjects2);

gdjs.Test_32SceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Test_32SceneCode.GDDayTextObjects2.length;i<l;++i) {
    if ( gdjs.Test_32SceneCode.GDDayTextObjects2[i].getTimerElapsedTimeInSecondsOrNaN("DayTimer") > 4 ) {
        gdjs.Test_32SceneCode.condition0IsTrue_0.val = true;
        gdjs.Test_32SceneCode.GDDayTextObjects2[k] = gdjs.Test_32SceneCode.GDDayTextObjects2[i];
        ++k;
    }
}
gdjs.Test_32SceneCode.GDDayTextObjects2.length = k;}if (gdjs.Test_32SceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Test_32SceneCode.GDDayTextObjects2 */
{for(var i = 0, len = gdjs.Test_32SceneCode.GDDayTextObjects2.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDDayTextObjects2[i].setOpacity(0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NightText"), gdjs.Test_32SceneCode.GDNightTextObjects1);

gdjs.Test_32SceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Test_32SceneCode.GDNightTextObjects1.length;i<l;++i) {
    if ( gdjs.Test_32SceneCode.GDNightTextObjects1[i].getTimerElapsedTimeInSecondsOrNaN("NightTimer") > 4 ) {
        gdjs.Test_32SceneCode.condition0IsTrue_0.val = true;
        gdjs.Test_32SceneCode.GDNightTextObjects1[k] = gdjs.Test_32SceneCode.GDNightTextObjects1[i];
        ++k;
    }
}
gdjs.Test_32SceneCode.GDNightTextObjects1.length = k;}if (gdjs.Test_32SceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Test_32SceneCode.GDNightTextObjects1 */
{for(var i = 0, len = gdjs.Test_32SceneCode.GDNightTextObjects1.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDNightTextObjects1[i].setOpacity(0);
}
}}

}


};gdjs.Test_32SceneCode.eventsList45 = function(runtimeScene) {

{


gdjs.Test_32SceneCode.condition0IsTrue_0.val = false;
{
gdjs.Test_32SceneCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.Test_32SceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Test_32SceneCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("PlayerHead"), gdjs.Test_32SceneCode.GDPlayerHeadObjects1);
{for(var i = 0, len = gdjs.Test_32SceneCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDPlayerObjects1[i].resetTimer("BuildTimer");
}
}{for(var i = 0, len = gdjs.Test_32SceneCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDPlayerObjects1[i].resetTimer("Ammo");
}
}{for(var i = 0, len = gdjs.Test_32SceneCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDPlayerObjects1[i].setScale(gdjs.Test_32SceneCode.GDPlayerObjects1[i].getScale() * (0.75));
}
}{for(var i = 0, len = gdjs.Test_32SceneCode.GDPlayerHeadObjects1.length ;i < len;++i) {
    gdjs.Test_32SceneCode.GDPlayerHeadObjects1[i].setScale(gdjs.Test_32SceneCode.GDPlayerHeadObjects1[i].getScale() * (0.75));
}
}{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 2, "", 0);
}
{ //Subevents
gdjs.Test_32SceneCode.eventsList3(runtimeScene);} //End of subevents
}

}


{


gdjs.Test_32SceneCode.eventsList4(runtimeScene);
}


{


gdjs.Test_32SceneCode.eventsList13(runtimeScene);
}


{


gdjs.Test_32SceneCode.eventsList15(runtimeScene);
}


{


gdjs.Test_32SceneCode.eventsList19(runtimeScene);
}


{


gdjs.Test_32SceneCode.eventsList21(runtimeScene);
}


{


gdjs.Test_32SceneCode.eventsList33(runtimeScene);
}


{


gdjs.Test_32SceneCode.eventsList35(runtimeScene);
}


{


gdjs.Test_32SceneCode.eventsList36(runtimeScene);
}


{


gdjs.Test_32SceneCode.eventsList37(runtimeScene);
}


{


gdjs.Test_32SceneCode.eventsList38(runtimeScene);
}


{


gdjs.Test_32SceneCode.eventsList44(runtimeScene);
}


};

gdjs.Test_32SceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Test_32SceneCode.GDPlayerHeadObjects1.length = 0;
gdjs.Test_32SceneCode.GDPlayerHeadObjects2.length = 0;
gdjs.Test_32SceneCode.GDPlayerHeadObjects3.length = 0;
gdjs.Test_32SceneCode.GDPlayerHeadObjects4.length = 0;
gdjs.Test_32SceneCode.GDPlayerHeadObjects5.length = 0;
gdjs.Test_32SceneCode.GDPlayerHeadObjects6.length = 0;
gdjs.Test_32SceneCode.GDPlayerObjects1.length = 0;
gdjs.Test_32SceneCode.GDPlayerObjects2.length = 0;
gdjs.Test_32SceneCode.GDPlayerObjects3.length = 0;
gdjs.Test_32SceneCode.GDPlayerObjects4.length = 0;
gdjs.Test_32SceneCode.GDPlayerObjects5.length = 0;
gdjs.Test_32SceneCode.GDPlayerObjects6.length = 0;
gdjs.Test_32SceneCode.GDZambamboObjects1.length = 0;
gdjs.Test_32SceneCode.GDZambamboObjects2.length = 0;
gdjs.Test_32SceneCode.GDZambamboObjects3.length = 0;
gdjs.Test_32SceneCode.GDZambamboObjects4.length = 0;
gdjs.Test_32SceneCode.GDZambamboObjects5.length = 0;
gdjs.Test_32SceneCode.GDZambamboObjects6.length = 0;
gdjs.Test_32SceneCode.GDBulletObjects1.length = 0;
gdjs.Test_32SceneCode.GDBulletObjects2.length = 0;
gdjs.Test_32SceneCode.GDBulletObjects3.length = 0;
gdjs.Test_32SceneCode.GDBulletObjects4.length = 0;
gdjs.Test_32SceneCode.GDBulletObjects5.length = 0;
gdjs.Test_32SceneCode.GDBulletObjects6.length = 0;
gdjs.Test_32SceneCode.GDFakewallObjects1.length = 0;
gdjs.Test_32SceneCode.GDFakewallObjects2.length = 0;
gdjs.Test_32SceneCode.GDFakewallObjects3.length = 0;
gdjs.Test_32SceneCode.GDFakewallObjects4.length = 0;
gdjs.Test_32SceneCode.GDFakewallObjects5.length = 0;
gdjs.Test_32SceneCode.GDFakewallObjects6.length = 0;
gdjs.Test_32SceneCode.GDWallObjects1.length = 0;
gdjs.Test_32SceneCode.GDWallObjects2.length = 0;
gdjs.Test_32SceneCode.GDWallObjects3.length = 0;
gdjs.Test_32SceneCode.GDWallObjects4.length = 0;
gdjs.Test_32SceneCode.GDWallObjects5.length = 0;
gdjs.Test_32SceneCode.GDWallObjects6.length = 0;
gdjs.Test_32SceneCode.GDBarricadeShortGhostObjects1.length = 0;
gdjs.Test_32SceneCode.GDBarricadeShortGhostObjects2.length = 0;
gdjs.Test_32SceneCode.GDBarricadeShortGhostObjects3.length = 0;
gdjs.Test_32SceneCode.GDBarricadeShortGhostObjects4.length = 0;
gdjs.Test_32SceneCode.GDBarricadeShortGhostObjects5.length = 0;
gdjs.Test_32SceneCode.GDBarricadeShortGhostObjects6.length = 0;
gdjs.Test_32SceneCode.GDBarricadeShortObjects1.length = 0;
gdjs.Test_32SceneCode.GDBarricadeShortObjects2.length = 0;
gdjs.Test_32SceneCode.GDBarricadeShortObjects3.length = 0;
gdjs.Test_32SceneCode.GDBarricadeShortObjects4.length = 0;
gdjs.Test_32SceneCode.GDBarricadeShortObjects5.length = 0;
gdjs.Test_32SceneCode.GDBarricadeShortObjects6.length = 0;
gdjs.Test_32SceneCode.GDBarricadeSpikesGhostObjects1.length = 0;
gdjs.Test_32SceneCode.GDBarricadeSpikesGhostObjects2.length = 0;
gdjs.Test_32SceneCode.GDBarricadeSpikesGhostObjects3.length = 0;
gdjs.Test_32SceneCode.GDBarricadeSpikesGhostObjects4.length = 0;
gdjs.Test_32SceneCode.GDBarricadeSpikesGhostObjects5.length = 0;
gdjs.Test_32SceneCode.GDBarricadeSpikesGhostObjects6.length = 0;
gdjs.Test_32SceneCode.GDBarricadeSpikesObjects1.length = 0;
gdjs.Test_32SceneCode.GDBarricadeSpikesObjects2.length = 0;
gdjs.Test_32SceneCode.GDBarricadeSpikesObjects3.length = 0;
gdjs.Test_32SceneCode.GDBarricadeSpikesObjects4.length = 0;
gdjs.Test_32SceneCode.GDBarricadeSpikesObjects5.length = 0;
gdjs.Test_32SceneCode.GDBarricadeSpikesObjects6.length = 0;
gdjs.Test_32SceneCode.GDBarricadeGhostObjects1.length = 0;
gdjs.Test_32SceneCode.GDBarricadeGhostObjects2.length = 0;
gdjs.Test_32SceneCode.GDBarricadeGhostObjects3.length = 0;
gdjs.Test_32SceneCode.GDBarricadeGhostObjects4.length = 0;
gdjs.Test_32SceneCode.GDBarricadeGhostObjects5.length = 0;
gdjs.Test_32SceneCode.GDBarricadeGhostObjects6.length = 0;
gdjs.Test_32SceneCode.GDBarricadeObjects1.length = 0;
gdjs.Test_32SceneCode.GDBarricadeObjects2.length = 0;
gdjs.Test_32SceneCode.GDBarricadeObjects3.length = 0;
gdjs.Test_32SceneCode.GDBarricadeObjects4.length = 0;
gdjs.Test_32SceneCode.GDBarricadeObjects5.length = 0;
gdjs.Test_32SceneCode.GDBarricadeObjects6.length = 0;
gdjs.Test_32SceneCode.GDHealthObjects1.length = 0;
gdjs.Test_32SceneCode.GDHealthObjects2.length = 0;
gdjs.Test_32SceneCode.GDHealthObjects3.length = 0;
gdjs.Test_32SceneCode.GDHealthObjects4.length = 0;
gdjs.Test_32SceneCode.GDHealthObjects5.length = 0;
gdjs.Test_32SceneCode.GDHealthObjects6.length = 0;
gdjs.Test_32SceneCode.GDHealthTokenObjects1.length = 0;
gdjs.Test_32SceneCode.GDHealthTokenObjects2.length = 0;
gdjs.Test_32SceneCode.GDHealthTokenObjects3.length = 0;
gdjs.Test_32SceneCode.GDHealthTokenObjects4.length = 0;
gdjs.Test_32SceneCode.GDHealthTokenObjects5.length = 0;
gdjs.Test_32SceneCode.GDHealthTokenObjects6.length = 0;
gdjs.Test_32SceneCode.GDBuildObjects1.length = 0;
gdjs.Test_32SceneCode.GDBuildObjects2.length = 0;
gdjs.Test_32SceneCode.GDBuildObjects3.length = 0;
gdjs.Test_32SceneCode.GDBuildObjects4.length = 0;
gdjs.Test_32SceneCode.GDBuildObjects5.length = 0;
gdjs.Test_32SceneCode.GDBuildObjects6.length = 0;
gdjs.Test_32SceneCode.GDBuildTokenObjects1.length = 0;
gdjs.Test_32SceneCode.GDBuildTokenObjects2.length = 0;
gdjs.Test_32SceneCode.GDBuildTokenObjects3.length = 0;
gdjs.Test_32SceneCode.GDBuildTokenObjects4.length = 0;
gdjs.Test_32SceneCode.GDBuildTokenObjects5.length = 0;
gdjs.Test_32SceneCode.GDBuildTokenObjects6.length = 0;
gdjs.Test_32SceneCode.GDLightObjects1.length = 0;
gdjs.Test_32SceneCode.GDLightObjects2.length = 0;
gdjs.Test_32SceneCode.GDLightObjects3.length = 0;
gdjs.Test_32SceneCode.GDLightObjects4.length = 0;
gdjs.Test_32SceneCode.GDLightObjects5.length = 0;
gdjs.Test_32SceneCode.GDLightObjects6.length = 0;
gdjs.Test_32SceneCode.GDSpawnPointObjects1.length = 0;
gdjs.Test_32SceneCode.GDSpawnPointObjects2.length = 0;
gdjs.Test_32SceneCode.GDSpawnPointObjects3.length = 0;
gdjs.Test_32SceneCode.GDSpawnPointObjects4.length = 0;
gdjs.Test_32SceneCode.GDSpawnPointObjects5.length = 0;
gdjs.Test_32SceneCode.GDSpawnPointObjects6.length = 0;
gdjs.Test_32SceneCode.GDEquipUIObjects1.length = 0;
gdjs.Test_32SceneCode.GDEquipUIObjects2.length = 0;
gdjs.Test_32SceneCode.GDEquipUIObjects3.length = 0;
gdjs.Test_32SceneCode.GDEquipUIObjects4.length = 0;
gdjs.Test_32SceneCode.GDEquipUIObjects5.length = 0;
gdjs.Test_32SceneCode.GDEquipUIObjects6.length = 0;
gdjs.Test_32SceneCode.GDSelectUIObjects1.length = 0;
gdjs.Test_32SceneCode.GDSelectUIObjects2.length = 0;
gdjs.Test_32SceneCode.GDSelectUIObjects3.length = 0;
gdjs.Test_32SceneCode.GDSelectUIObjects4.length = 0;
gdjs.Test_32SceneCode.GDSelectUIObjects5.length = 0;
gdjs.Test_32SceneCode.GDSelectUIObjects6.length = 0;
gdjs.Test_32SceneCode.GDTimeTextObjects1.length = 0;
gdjs.Test_32SceneCode.GDTimeTextObjects2.length = 0;
gdjs.Test_32SceneCode.GDTimeTextObjects3.length = 0;
gdjs.Test_32SceneCode.GDTimeTextObjects4.length = 0;
gdjs.Test_32SceneCode.GDTimeTextObjects5.length = 0;
gdjs.Test_32SceneCode.GDTimeTextObjects6.length = 0;
gdjs.Test_32SceneCode.GDNightTextObjects1.length = 0;
gdjs.Test_32SceneCode.GDNightTextObjects2.length = 0;
gdjs.Test_32SceneCode.GDNightTextObjects3.length = 0;
gdjs.Test_32SceneCode.GDNightTextObjects4.length = 0;
gdjs.Test_32SceneCode.GDNightTextObjects5.length = 0;
gdjs.Test_32SceneCode.GDNightTextObjects6.length = 0;
gdjs.Test_32SceneCode.GDDayTextObjects1.length = 0;
gdjs.Test_32SceneCode.GDDayTextObjects2.length = 0;
gdjs.Test_32SceneCode.GDDayTextObjects3.length = 0;
gdjs.Test_32SceneCode.GDDayTextObjects4.length = 0;
gdjs.Test_32SceneCode.GDDayTextObjects5.length = 0;
gdjs.Test_32SceneCode.GDDayTextObjects6.length = 0;
gdjs.Test_32SceneCode.GDTimeText2Objects1.length = 0;
gdjs.Test_32SceneCode.GDTimeText2Objects2.length = 0;
gdjs.Test_32SceneCode.GDTimeText2Objects3.length = 0;
gdjs.Test_32SceneCode.GDTimeText2Objects4.length = 0;
gdjs.Test_32SceneCode.GDTimeText2Objects5.length = 0;
gdjs.Test_32SceneCode.GDTimeText2Objects6.length = 0;
gdjs.Test_32SceneCode.GDAssaultObjects1.length = 0;
gdjs.Test_32SceneCode.GDAssaultObjects2.length = 0;
gdjs.Test_32SceneCode.GDAssaultObjects3.length = 0;
gdjs.Test_32SceneCode.GDAssaultObjects4.length = 0;
gdjs.Test_32SceneCode.GDAssaultObjects5.length = 0;
gdjs.Test_32SceneCode.GDAssaultObjects6.length = 0;
gdjs.Test_32SceneCode.GDRifleObjects1.length = 0;
gdjs.Test_32SceneCode.GDRifleObjects2.length = 0;
gdjs.Test_32SceneCode.GDRifleObjects3.length = 0;
gdjs.Test_32SceneCode.GDRifleObjects4.length = 0;
gdjs.Test_32SceneCode.GDRifleObjects5.length = 0;
gdjs.Test_32SceneCode.GDRifleObjects6.length = 0;
gdjs.Test_32SceneCode.GDShotgunObjects1.length = 0;
gdjs.Test_32SceneCode.GDShotgunObjects2.length = 0;
gdjs.Test_32SceneCode.GDShotgunObjects3.length = 0;
gdjs.Test_32SceneCode.GDShotgunObjects4.length = 0;
gdjs.Test_32SceneCode.GDShotgunObjects5.length = 0;
gdjs.Test_32SceneCode.GDShotgunObjects6.length = 0;
gdjs.Test_32SceneCode.GDPistolObjects1.length = 0;
gdjs.Test_32SceneCode.GDPistolObjects2.length = 0;
gdjs.Test_32SceneCode.GDPistolObjects3.length = 0;
gdjs.Test_32SceneCode.GDPistolObjects4.length = 0;
gdjs.Test_32SceneCode.GDPistolObjects5.length = 0;
gdjs.Test_32SceneCode.GDPistolObjects6.length = 0;
gdjs.Test_32SceneCode.GDAssaultAmmoObjects1.length = 0;
gdjs.Test_32SceneCode.GDAssaultAmmoObjects2.length = 0;
gdjs.Test_32SceneCode.GDAssaultAmmoObjects3.length = 0;
gdjs.Test_32SceneCode.GDAssaultAmmoObjects4.length = 0;
gdjs.Test_32SceneCode.GDAssaultAmmoObjects5.length = 0;
gdjs.Test_32SceneCode.GDAssaultAmmoObjects6.length = 0;
gdjs.Test_32SceneCode.GDRifleAmmoObjects1.length = 0;
gdjs.Test_32SceneCode.GDRifleAmmoObjects2.length = 0;
gdjs.Test_32SceneCode.GDRifleAmmoObjects3.length = 0;
gdjs.Test_32SceneCode.GDRifleAmmoObjects4.length = 0;
gdjs.Test_32SceneCode.GDRifleAmmoObjects5.length = 0;
gdjs.Test_32SceneCode.GDRifleAmmoObjects6.length = 0;
gdjs.Test_32SceneCode.GDShotgunAmmoObjects1.length = 0;
gdjs.Test_32SceneCode.GDShotgunAmmoObjects2.length = 0;
gdjs.Test_32SceneCode.GDShotgunAmmoObjects3.length = 0;
gdjs.Test_32SceneCode.GDShotgunAmmoObjects4.length = 0;
gdjs.Test_32SceneCode.GDShotgunAmmoObjects5.length = 0;
gdjs.Test_32SceneCode.GDShotgunAmmoObjects6.length = 0;
gdjs.Test_32SceneCode.GDPistolAmmoObjects1.length = 0;
gdjs.Test_32SceneCode.GDPistolAmmoObjects2.length = 0;
gdjs.Test_32SceneCode.GDPistolAmmoObjects3.length = 0;
gdjs.Test_32SceneCode.GDPistolAmmoObjects4.length = 0;
gdjs.Test_32SceneCode.GDPistolAmmoObjects5.length = 0;
gdjs.Test_32SceneCode.GDPistolAmmoObjects6.length = 0;
gdjs.Test_32SceneCode.GDMouseObjectObjects1.length = 0;
gdjs.Test_32SceneCode.GDMouseObjectObjects2.length = 0;
gdjs.Test_32SceneCode.GDMouseObjectObjects3.length = 0;
gdjs.Test_32SceneCode.GDMouseObjectObjects4.length = 0;
gdjs.Test_32SceneCode.GDMouseObjectObjects5.length = 0;
gdjs.Test_32SceneCode.GDMouseObjectObjects6.length = 0;
gdjs.Test_32SceneCode.GDZambamboHealthBackObjects1.length = 0;
gdjs.Test_32SceneCode.GDZambamboHealthBackObjects2.length = 0;
gdjs.Test_32SceneCode.GDZambamboHealthBackObjects3.length = 0;
gdjs.Test_32SceneCode.GDZambamboHealthBackObjects4.length = 0;
gdjs.Test_32SceneCode.GDZambamboHealthBackObjects5.length = 0;
gdjs.Test_32SceneCode.GDZambamboHealthBackObjects6.length = 0;
gdjs.Test_32SceneCode.GDZambamboHealthObjects1.length = 0;
gdjs.Test_32SceneCode.GDZambamboHealthObjects2.length = 0;
gdjs.Test_32SceneCode.GDZambamboHealthObjects3.length = 0;
gdjs.Test_32SceneCode.GDZambamboHealthObjects4.length = 0;
gdjs.Test_32SceneCode.GDZambamboHealthObjects5.length = 0;
gdjs.Test_32SceneCode.GDZambamboHealthObjects6.length = 0;
gdjs.Test_32SceneCode.GDtempwall1Objects1.length = 0;
gdjs.Test_32SceneCode.GDtempwall1Objects2.length = 0;
gdjs.Test_32SceneCode.GDtempwall1Objects3.length = 0;
gdjs.Test_32SceneCode.GDtempwall1Objects4.length = 0;
gdjs.Test_32SceneCode.GDtempwall1Objects5.length = 0;
gdjs.Test_32SceneCode.GDtempwall1Objects6.length = 0;
gdjs.Test_32SceneCode.GDtempwall2Objects1.length = 0;
gdjs.Test_32SceneCode.GDtempwall2Objects2.length = 0;
gdjs.Test_32SceneCode.GDtempwall2Objects3.length = 0;
gdjs.Test_32SceneCode.GDtempwall2Objects4.length = 0;
gdjs.Test_32SceneCode.GDtempwall2Objects5.length = 0;
gdjs.Test_32SceneCode.GDtempwall2Objects6.length = 0;
gdjs.Test_32SceneCode.GDTileCarpetObjects1.length = 0;
gdjs.Test_32SceneCode.GDTileCarpetObjects2.length = 0;
gdjs.Test_32SceneCode.GDTileCarpetObjects3.length = 0;
gdjs.Test_32SceneCode.GDTileCarpetObjects4.length = 0;
gdjs.Test_32SceneCode.GDTileCarpetObjects5.length = 0;
gdjs.Test_32SceneCode.GDTileCarpetObjects6.length = 0;
gdjs.Test_32SceneCode.GDTileWallsObjects1.length = 0;
gdjs.Test_32SceneCode.GDTileWallsObjects2.length = 0;
gdjs.Test_32SceneCode.GDTileWallsObjects3.length = 0;
gdjs.Test_32SceneCode.GDTileWallsObjects4.length = 0;
gdjs.Test_32SceneCode.GDTileWallsObjects5.length = 0;
gdjs.Test_32SceneCode.GDTileWallsObjects6.length = 0;
gdjs.Test_32SceneCode.GDObjectSpawnObjects1.length = 0;
gdjs.Test_32SceneCode.GDObjectSpawnObjects2.length = 0;
gdjs.Test_32SceneCode.GDObjectSpawnObjects3.length = 0;
gdjs.Test_32SceneCode.GDObjectSpawnObjects4.length = 0;
gdjs.Test_32SceneCode.GDObjectSpawnObjects5.length = 0;
gdjs.Test_32SceneCode.GDObjectSpawnObjects6.length = 0;
gdjs.Test_32SceneCode.GDBarricadePropObjects1.length = 0;
gdjs.Test_32SceneCode.GDBarricadePropObjects2.length = 0;
gdjs.Test_32SceneCode.GDBarricadePropObjects3.length = 0;
gdjs.Test_32SceneCode.GDBarricadePropObjects4.length = 0;
gdjs.Test_32SceneCode.GDBarricadePropObjects5.length = 0;
gdjs.Test_32SceneCode.GDBarricadePropObjects6.length = 0;
gdjs.Test_32SceneCode.GDTileG1Objects1.length = 0;
gdjs.Test_32SceneCode.GDTileG1Objects2.length = 0;
gdjs.Test_32SceneCode.GDTileG1Objects3.length = 0;
gdjs.Test_32SceneCode.GDTileG1Objects4.length = 0;
gdjs.Test_32SceneCode.GDTileG1Objects5.length = 0;
gdjs.Test_32SceneCode.GDTileG1Objects6.length = 0;
gdjs.Test_32SceneCode.GDTileG2Objects1.length = 0;
gdjs.Test_32SceneCode.GDTileG2Objects2.length = 0;
gdjs.Test_32SceneCode.GDTileG2Objects3.length = 0;
gdjs.Test_32SceneCode.GDTileG2Objects4.length = 0;
gdjs.Test_32SceneCode.GDTileG2Objects5.length = 0;
gdjs.Test_32SceneCode.GDTileG2Objects6.length = 0;

gdjs.Test_32SceneCode.eventsList45(runtimeScene);
return;

}

gdjs['Test_32SceneCode'] = gdjs.Test_32SceneCode;
